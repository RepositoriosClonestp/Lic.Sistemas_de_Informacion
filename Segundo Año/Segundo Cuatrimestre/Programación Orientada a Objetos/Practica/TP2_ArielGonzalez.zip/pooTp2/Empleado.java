import java.util.*;
/**
*@author Gonzalez Ariel
*Clase Empleado 2.5
*/
public class Empleado
{
    /**
     * Atributos de la clase
    */
    private long cuil;
    private String apellido;
    private String nombre;
    private double sueldoBasico;
    private int anioIngreso;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param p_cuil
    **@param p_apellido
    *@param p_nombre
    *@param p_importe
    **@param p_anio
    */
    Empleado(long p_cuil,String p_apellido, String p_nombre, double p_importe, int p_anio){
        this.setCuil(p_cuil);
        this.setApellido(p_apellido);
        this.setNombre(p_nombre);
        this.setSueldo(p_importe);
        this.setAnio(p_anio);
    }
    
    /**
    *Setter,recibe un long por parametro y permite modificar el valor de el atributo cuil
    *@param p_cuil
    */
    private void setCuil(long p_cuil){
        this.cuil = p_cuil;
    }
    
    /**
    *Setter,recibe un String por parametro y permite modificar el valor de el atributo apellido
    *@param p_apellido
    */
    private void setApellido(String p_apellido){
        this.apellido = p_apellido;
    }
    
    /**
    *Setter,recibe un String por parametro y permite modificar el valor de el atributo nombre
    *@param p_nombre
    */
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    /**
    *Setter,recibe un double por parametro y permite modificar el valor de el atributo sueldoBasico
    *@param p_importe
    */
    private void setSueldo(double p_importe){
        this.sueldoBasico = p_importe;
    }
    
    /**
    *Setter,recibe un int por parametro y permite modificar el valor de el atributo anio
    *@param p_anio
    */
    private void setAnio(int p_anio){
        this.anioIngreso = p_anio;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo cuil
    *@return devuelve un long
    */
    public long getCuil(){
        return this.cuil;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo apellido
    *@return devuelve un String
    */    
    public String getApellido(){
        return this.apellido;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo nombre
    *@return devuelve un String
    */
    public String getNombre(){
        return this.nombre;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo sueldoBasico
    *@return devuelve un double
    */
    public double getSueldo(){
        return this.sueldoBasico;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo anioIngreso
    *@return devuelve un int
    */
    public int getAnio(){
        return this.anioIngreso;
    }
    
    /**
    *Metodo publico, instancia un objeto de tipo Calendar, utiliza este objeto para obtener el año actual
    *luego, utiliza el metodo getAnio() el cual devuelve el año de ingreso del empleado
    *se realiza una resta para calcular la antiguedad del empleado y se devuelve el resultado
    *@return devuelve un valor double
    */
    public int antiguedad(){
        Calendar añoHoy = new GregorianCalendar();
        return (añoHoy.get(Calendar.YEAR) - this.getAnio());
    }
    
    /**
    *Metodo privado, crea una variable auxiliar, en la cual se le asigna el descuento que se le 
    *realiza al empleado, se utiliza el metodo getSueldo() en dicha operacion
    *@return devuelve un valor double
    */
    private double descuento(){
        double descuento;
        descuento = ((2 * this.getSueldo()) / 100) + 1500;
        return descuento;
    }
    
    /**
    *Metodo privado, crea una variable auxiliar, en la cual se le asigna el valor del adicional
    *que se le pagará al empleado, utiliza el metodo antiguedad() dentro de una estructura condicional
    *para comparar con una cantidad de años especifica y asi de este modo calcular el monto.
    *@return devuelve un valor double
    */
    private double adicional(){
        double adicional  = 0;
        if(antiguedad() < 2){
            adicional = ((2 * this.getSueldo()) / 100);
        }else if(antiguedad() >= 2 && antiguedad() < 10){
            adicional = ((4 * this.getSueldo()) / 100);
        }else if(antiguedad() >= 10){
            adicional = ((6 * this.getSueldo()) / 100);
        }
        return adicional;
    }
    
    /**
    *Metodo publico, crea una variable auxiliar, en la cual se le asigna el valor del sueldo
    *que se le pagará al empleado, utiliza los metodos getSueldo(),adicional(),descuento() para
    *calcular el valor del sueldo
    *@return devuelve un valor double
    */
    public double sueldoNeto(){
        double sueldoNeto;
        sueldoNeto = (this.getSueldo() + this.adicional()) - this.descuento();
        return sueldoNeto;
    }
    
    /**
    *Metodo publico, utiliza los metodos getNombre() y getApellido() para crear una cadena de texto 
    *@return devuelve un String
    */
    public String nomYApe(){
        return (""+this.getNombre()+" "+this.getApellido());
    }
    
    /**
    *Metodo publico, utiliza los metodos getNombre() y getApellido() para crear una cadena de texto 
    *@return devuelve un String
    */
    public String apeYNom(){
        return (""+this.getApellido()+" "+this.getNombre());
    }
    
    /**
    *Metodo publico, utiliza los metodos nomYApe(), getCuil(), antiguedad(),sueldoNeto()
    *para mostrar la informacion del empleado por pantalla
    */
    public void mostrar(){
        System.out.println("Nombre y Apellido: "+this.nomYApe());
        System.out.println("CUIL: "+this.getCuil()+" Antiguedad: "+this.antiguedad()+" años de servicio");
        System.out.println("Sueldo Neto: $"+this.sueldoNeto());
    }
    
    /**
    *Metodo publico, utiliza los metodos getApellido(), getNombre(), getCuil(),sueldoNeto()
    *para mostrar la informacion del empleado por pantalla
    */
    public String mostrarLinea(){
        return (""+this.getCuil()+" "+this.getApellido()+", "+this.getNombre()+" ...............$"+this.sueldoNeto());
    }
}
