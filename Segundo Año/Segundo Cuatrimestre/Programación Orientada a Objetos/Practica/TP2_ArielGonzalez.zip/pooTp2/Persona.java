import java.util.*;
/**
*@author Gonzalez Ariel
*Clase Persona Tp 2.1
*/
public class Persona
{
    /**
    *Atributos de la Clase 
    */
    private int nroDni;
    private String nombre;
    private String apellido;
    private int anioNacimiento;
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param p_dni
    *@param p_nombre
    *@param p_apellido
    *@param p_anio
    */
    Persona(int p_dni,String p_nombre,String p_apellido,int p_anio){
        this.setDni(p_dni);
        this.setNombre(p_nombre);
        this.setApellido(p_apellido);
        this.setAnioNacimiento(p_anio);
    }
    
    /**
    *Setter,recibe un entero y permite modificar el valor de el atributo dni
    *@param p_dni
    */
    private void setDni(int p_dni){
        this.nroDni = p_dni;
    }
    
    /**
    *Setter,recibe un String y permite modificar el valor de el atributo nombre
    *@param p_nombre
    */
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    /**
    *Setter,recibe un String y permite modificar el valor de el atributo apellido
    *@param p_apellido
    */
    private void setApellido(String p_apellido){
        this.apellido = p_apellido;
    }
   
    /**
    *Setter,recibe un entero y permite modificar el valor de el atributo anio
    *@param p_anio
    */
   
    private void setAnioNacimiento(int p_anio){
        this.anioNacimiento = p_anio;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo dni
    *@return devuelve un valor entero
    */
    public int getDni(){
        return this.nroDni;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo nombre
    *@return devuelve un String
    */
    public String getNombre(){
        return this.nombre;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo apellido
    *@return devuelve un String
    */
    public String getApellido(){
        return this.apellido;
    }
    /**
    *Getter, permite obtener el valor de el atributo anioNacimiento
    *@return devuelve una valor entero
    */
    public int getAnioNacimiento(){
        return this.anioNacimiento;
    }
    /**
    *Metodo publico, instancia un objeto de tipo Calendar, el cual se utiliza para asignar
    *a la variable auxiliar anioHoy, el año actual, luego se utiliza el metodo getAnioNacimiento()
    *para calcular la edad de la persona
    *@return devuelve un entero
    */
    public int edad(){
        Calendar fechaHoy = new GregorianCalendar();
        int anioHoy = fechaHoy.get(Calendar.YEAR);
        return (anioHoy - this.getAnioNacimiento());
    }
    
    /**
    *Metodo publico, utiliza los metodos getNombre() y getApellido()
    *para formar una cadena de texto del nombre y apellido
    *@return devuelve un String
    */
    public String nomYApe(){
        return (""+this.getNombre()+" "+this.getApellido());
    }
    
    /**
    *Metodo publico, utiliza los metodos getApellido() y getNombre()
    *para formar una cadena de texto del apellido y el nombre
    *@return devuelve un String
    */
    public String apeYNom(){
        return (""+this.getApellido()+" "+this.getNombre());
    }
    
    /**
    *Metodo publico, utiliza el metodo nomYApe()
    *para formar una cadena de texto del apellido y el nombre
    *y utiliza los metodos, getDni() y edad() para formar una cadena de texto
    *utiliza 2 System.out.println para mostrar por pantalla ambas cadenas de texto
    */
    public void mostrar(){
        System.out.println("Nombre y apellido: "+this.nomYApe());
        System.out.println("Dni:"+this.getDni()+" Edad: "+this.edad()+" años");
    }
}
