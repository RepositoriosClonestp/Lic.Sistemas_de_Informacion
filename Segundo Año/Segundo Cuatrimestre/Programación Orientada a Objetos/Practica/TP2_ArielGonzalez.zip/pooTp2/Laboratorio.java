/**
*@author Gonzalez Ariel
*Clase Laboratorio Tp 2.2
*/
public class Laboratorio
{
    /**
    *Atributos de la Clase 
    */
    private String nombre;
    private String domicilio;
    private String telefono;
    private int compraMinima;
    private int diaEntrega;
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param p_nombre
    *@param p_domicilio
    *@param p_telefono
    *@param p_compraMin
    *@param p_diaEnt
    */
    Laboratorio(String p_nombre,String p_domicilio,String p_telefono,int p_compraMin,int p_diaEnt){
        this.setNombre(p_nombre);
        this.setDomicilio(p_domicilio);
        this.setTelefono(p_telefono);
        this.setCompraMin(p_compraMin);
        this.setDiaEntrega(p_diaEnt);
    }
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param p_nombre
    *@param p_domicilio
    *@param p_telefono
    */
    Laboratorio(String p_nombre,String p_domicilio,String p_telefono){
        this.setNombre(p_nombre);
        this.setDomicilio(p_domicilio);
        this.setTelefono(p_telefono);
        this.setCompraMin(0);
        this.setDiaEntrega(0);
    }
    
    /**
    *Setter,recibe un String y permite modificar el valor de el atributo nombre
    *@param p_nombre
    */
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    /**
    *Setter,recibe un String y permite modificar el valor de el atributo domicilio
    *@param p_domicilio
    */
    private void setDomicilio(String p_domicilio){
        this.domicilio = p_domicilio;
    }
    
    /**
    *Setter,recibe un String y permite modificar el valor de el atributo telefono
    *@param p_telefono
    */
    private void setTelefono(String p_telefono){
        this.telefono = p_telefono;
    }
    
    /**
    *Setter,recibe un entero y permite modificar el valor de el atributo compraMinima
    *@param p_compraMin
    */
    private void setCompraMin(int p_compraMin){
        this.compraMinima = p_compraMin;
    }
    
    /**
    *Setter,recibe un entero y permite modificar el valor de el atributo diaEntrega
    *@param p_apellido
    */
    private void setDiaEntrega(int p_diaEnt){
        this.diaEntrega = p_diaEnt;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo nombre
    *@return devuelve un String
    */
    public String getNombre(){
        return this.nombre;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo domicilio
    *@return devuelve un String
    */
    public String getDomicilio(){
        return this.domicilio;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo telefono
    *@return devuelve un String
    */
    public String getTelefono(){
        return this.telefono;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo compraMinima
    *@return devuelve un valor entero
    */
    public int getCompraMin(){
        return this.compraMinima;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo diaEntrega
    *@return devuelve un valor entero
    */
    public int getDiaEntrega(){
        return this.diaEntrega;
    }
    /**
    *Metodo publico, recibe por parametro un entero y utiliza el metodo setCompramin(int) para
    *asignar el valor recibido por parametro al atributo compraMinima
    *@param p_compraMin
    */
    public void nuevaCompraMinima(int p_compraMin){
        this.setCompraMin(p_compraMin);
    }
    
    /**Metodo publico, recibe por parametro un entero y utiliza el metodo setDiaEntrega(int) para
    *asignar el valor recibido por parametro al atributo diaEntrega
    *@param p_diaEnt
    */
    public void nuevoDiaEntrega(int p_diaEnt){
        this.setDiaEntrega(p_diaEnt);
    }
    
    /**Metodo publico, utiliza los metodos getNombre(),getDomicilio() y getTelefono() para
    *formar una cadena y retornarla
    *@return devuelve un String
    */
    public String mostrar(){
        return("Laboratorio: "+this.getNombre()+"\n"+"Domicilio: "+this.getDomicilio()+" - Telefono: "+this.getTelefono());
    }
}
