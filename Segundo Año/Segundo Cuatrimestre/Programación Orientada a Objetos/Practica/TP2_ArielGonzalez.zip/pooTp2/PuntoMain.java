
public class PuntoMain
{
   public static void main(String[] args){
       Punto unPunto = new Punto(7.5,0.5);
       unPunto.mostrar();
       System.out.println(unPunto.coordenadas());
       unPunto.desplazar(3,4);
       unPunto.mostrar();
       System.out.println(unPunto.coordenadas());
   }
   
}
