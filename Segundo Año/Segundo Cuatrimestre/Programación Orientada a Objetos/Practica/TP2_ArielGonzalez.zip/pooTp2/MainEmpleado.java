
public class MainEmpleado
{
    public static void main(String[] args){
        Empleado unEmpleado = new Empleado(20351234385L,"Perez","Juan",29998500,2001);
        unEmpleado.mostrar();
        System.out.println(unEmpleado.mostrarLinea());
    }
    
}
