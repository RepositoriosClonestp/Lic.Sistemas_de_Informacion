/**
*@author Gonzalez Ariel
*Clase Alumno 2.4
*/
public class Alumno
{
    /**
     * Atributos de la clase
    */
    private int lu;
    private String nombre;
    private String apellido;
    private double nota1;
    private double nota2;
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param p_lu
    *@param p_nombre
    *@param p_apellido
    */
    Alumno(int p_lu,String p_nombre, String p_apellido){
        this.setLu(p_lu);
        this.setNombre(p_nombre);
        this.setApellido(p_apellido);
        this.setNota1(0);
        this.setNota2(0);
    }
    
    /**
    *Setter,recibe un entero por parametro y permite modificar el valor de el atributo lu
    *@param p_lu
    */
    private void setLu(int p_lu){
        this.lu = p_lu;
    }
    
    /**
    *Setter,recibe un String por parametro y permite modificar el valor de el atributo nombre
    *@param p_nombre
    */
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;    
    }
    
    /**
    *Setter,recibe un String por parametro y permite modificar el valor de el atributo apellido
    *@param p_apellido
    */
    private void setApellido(String p_apellido){
        this.apellido = p_apellido;
    }
    
    /**
    *Setter,recibe un double por parametro y permite modificar el valor de el atributo nota1
    *@param p_nota
    */
    public void setNota1(double p_nota){
        this.nota1 = p_nota;
    }
    
    /**
    *Setter,recibe un double por parametro y permite modificar el valor de el atributo nota2
    *@param p_nota2
    */
    public void setNota2(double p_nota){
        this.nota2 = p_nota;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo lu
    *@return devuelve un entero
    */
    public int getLu(){
        return this.lu;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo nombre
    *@return devuelve un String
    */
    public String getNombre(){
        return this.nombre;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo apellido
    *@return devuelve un String
    */
    public String getApellido(){
        return this.apellido;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo nota1
    *@return devuelve un double
    */
    public double getNota1(){
        return this.nota1;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo nota2
    *@return devuelve un double
    */
    public double getNota2(){
        return this.nota2;
    }
    
    /**
     * Metodo publico, utiliza el metodo promedio(), getNota1() y getNota2() para evaluar unas
     * determinadas condiciones, si dicha condicion se cumple la variable auxiliar respuesta, evalua a true
     * en caso contrario evalua a falso
     * @return devuelve un valor boolean
    */
    public boolean aprueba(){
        boolean respuesta;
        if(this.promedio() > 7 && this.getNota1() >= 6 && this.getNota2() >= 6){
            respuesta = true;
        }else{
            respuesta = false;
        }
        return respuesta;
    }
    
    /**
     * Dentro de la estructura condicional if, utiliza el metodo aprueba() para evaluar si el alumno aprueba
     * si el metodo devuelve true, se asigna "Aprobado" a una variable auxiliar, caso contrario se asigna "Desaprueba"
     * @return devuelve un String
    */
    public String leyendaAprueba(){
        String respuesta;
        
        if(aprueba() == true){
            respuesta = "APROBADO";
        }else{
            respuesta = "DESAPROBADO";
        }
        return respuesta;
    }
    
    /**
     * Metodo publico, suma 2 notas utilizando los metodos getNota1() y getNota2(), luego a la suma
     * de esas notas, las divide por 2 para calcular su promedio
     * @return devuelve un valor double
    */
    public double promedio(){
        double sumaNotas = (this.getNota1()+this.getNota2());
        double promedio = sumaNotas / 2;
        return promedio;
    }
    
    /**
     * Metodo publico, utiliza los metodos getNombre() y getApellido() para formar una cadena de texto
     * @return devuelve un String
    */
    public String nomYApe(){
        return (""+this.getNombre()+" "+this.getApellido());
    }
    
    /**
     * Metodo publico, utiliza los metodos getApellido() y getNombre() para formar una cadena de texto
     * @return devuelve un String
    */
    public String apeYNom(){
        return (""+this.getApellido()+" "+this.getNombre());
    }
    
    /**
     * Metodo publico, el cual utiliza los metodos nomYApe(),getLu(),getNota1(),getNota2()
     * leyendaAprueba(),promedio() para armar varias cadenas de texto y mostrarlas por pantalla
    */
    public void mostrar(){
        System.out.println("Nombre y Apellido: "+this.nomYApe());
        System.out.println("LU:"+this.getLu()+" Notas: "+this.getNota1()+" - "+this.getNota2());
        System.out.println("Promedio: "+this.promedio()+" - "+this.leyendaAprueba());
    }
}
