
public class MainLaboratorio
{
    public static void main(String[] args){
        Laboratorio unLaboratorio = new Laboratorio("Colgate S.A.","Junin 5204","54-11 -4239-8447");
        System.out.println(unLaboratorio.mostrar());
    }
    
    
}
