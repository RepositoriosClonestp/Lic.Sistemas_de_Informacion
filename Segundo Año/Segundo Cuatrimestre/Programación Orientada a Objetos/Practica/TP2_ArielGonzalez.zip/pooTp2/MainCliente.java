
public class MainCliente
{
    public static void main(String[] args){
        Cliente unCliente = new Cliente(24444333,"Perez","Juan",200);
        System.out.println("Nombre y apellido: "+unCliente.nomYape()+"("+unCliente.getDni()+")");
        System.out.println("Saldo: "+unCliente.getSaldo());
        unCliente.agregaSaldo(100);
        System.out.println("Nombre y apellido: "+unCliente.nomYape()+"("+unCliente.getDni()+")");
        System.out.println("Saldo: "+unCliente.getSaldo());
        unCliente.nuevoSaldo(20);
        System.out.println("Nombre y apellido: "+unCliente.nomYape()+"("+unCliente.getDni()+")");
        System.out.println("Saldo: "+unCliente.getSaldo());
    }
    
}
