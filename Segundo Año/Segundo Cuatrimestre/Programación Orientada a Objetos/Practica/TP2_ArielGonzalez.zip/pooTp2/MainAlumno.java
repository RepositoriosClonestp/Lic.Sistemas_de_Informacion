

public class MainAlumno
{
   public static void main(String[] args){
       Alumno unAlumno = new Alumno(2020,"Juan","Perez");
       unAlumno.setNota1(5.99);
       unAlumno.setNota2(10.0);
       unAlumno.mostrar();
       Alumno otroAlumno = new Alumno(2051,"Maria","Gomez");
       otroAlumno.setNota1(7.85);
       otroAlumno.setNota2(8.5);
       otroAlumno.mostrar();
   }
}
