/**
*@author Gonzalez Ariel
*Clase Punto 2.6
*/
public class Punto
{
   /**
   * Atributos de la clase
   */
   private double x;
   private double y;
   
   /**
   * Constructor Vacio, Instancia un objeto
   */
   Punto(){
   }
   
   /**
   * Constructor con parametros, Instancia un objeto
   * @param p_x
   * @param p_y
   */
   Punto(double p_x, double p_y){
       this.setX(p_x);
       this.setY(p_y);
   }
   
   /**
    *Setter,recibe un double por parametro y permite modificar el valor de el atributo y
    *@param p_y
    */
   private void setY(double p_y){
       this.y = p_y;
   }
   
   /**
    *Setter,recibe un double por parametro y permite modificar el valor de el atributo x
    *@param p_x
    */
   private void setX(double p_x){
       this.x= p_x;
   }
   
   /**
    *Getter, permite obtener el valor de el atributo x
    *@return devuelve un double
    */
   public double getX(){
       return this.x;
   }
   
   /**
    *Getter, permite obtener el valor de el atributo y
    *@return devuelve un double
    */
   public double getY(){
        return this.y;
   }   
   
   /**
    *Metodo publico, recibe 2 parametros de tipo double
    *utiliza los metodos getX() y getY() para realizar la suma con los parametros recibidos
    *y asigna los resultados con los metodos set para actualizar los valores de los atributos x e y
    *@param p_dx
    **@param p_dy
    */
   public void desplazar(double p_dx,double p_dy){
       this.setX(this.getX() + p_dx);
       this.setY(this.getY() + p_dy);
   }
   
   /**
    *Metodo publico, utiliza los metodos getX() y getY() para formar una cadena con las coordenadas del punto
    *@return devuelve un String
    */
   public String coordenadas(){
       return ("("+this.getX()+", "+this.getY()+")");
   }
   
   /**
    *Metodo publico, utiliza los metodos getX() y getY() para mostrar por pantalla las coordenadas del punto
    */
   public void mostrar(){
       System.out.println("Punto. X: "+this.getX()+" Y: "+this.getY());
   }
}
