
public class MainPersona
{
    public static void main(String[] args){
        Persona unaPersona = new Persona(35123456,"Juan","Perez",2001);
        unaPersona.mostrar();
        
    }
}
