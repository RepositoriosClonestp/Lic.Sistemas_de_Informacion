import java.util.Scanner;
public class CircunferenciaTeclado
{
    public static void main(String[] args){
        String respuesta = "s";
        Scanner leer = new Scanner(System.in);
        while(respuesta.equals( "s")){
            System.out.println("Ingrese el radio: ");
            int radio = leer.nextInt();
            double circunferencia = Math.PI * radio * 2;
            System.out.println("Circunferencia: "+circunferencia);
            System.out.println("Desea seguir calculando?: ");
            respuesta = leer.next();
        }
      
    }
    
}
