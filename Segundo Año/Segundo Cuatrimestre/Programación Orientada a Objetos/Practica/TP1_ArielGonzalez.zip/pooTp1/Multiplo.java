/**
 * Clase Multiplo Tp 1.2
*/
public class Multiplo
{
   public static void main(String[] args){
    /**
    * inicializa la variable auxiliar en 0
    */
        int i = 0;
        for(i = 10;i < 38;i++){
            System.out.println(""+(4*i));
        }
    }
}
