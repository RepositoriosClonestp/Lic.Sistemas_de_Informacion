import java.util.Scanner;
public class OrdenVector
{
    public static void main(String[] args){
        //Crea un array de tipo double
        double [] arrayValores = new double[4];
        //Crea un objeto de la clase Scanner
        Scanner leer = new Scanner(System.in);
        int i, j;
        double aux;
        double valorMenor = 999;
        //Ingresa los valores
        for (i = 0; i < arrayValores.length - 1; i++) {
            System.out.println("Ingrese el valor: ");
            String aux2 = leer.next();
            arrayValores[i] = Double.parseDouble(aux2);
        }
        //Calcula el valor menor
        for (i = 0; i < arrayValores.length - 1; i++) {
            if(arrayValores[i] < valorMenor){
                valorMenor = arrayValores[i];
            }
        }
        System.out.println("Valor menor: "+valorMenor);
        //Utiliza un auxiliar para cambiar los valores y ordenar el array
        for (i = 0; i < arrayValores.length - 1; i++) {
            for (j = 0; j < arrayValores.length - i - 1; j++) {                                                              
                if (arrayValores[j + 1] < arrayValores[j]) {
                    aux = arrayValores[j + 1];
                    arrayValores[j + 1] = arrayValores[j];
                    arrayValores[j] = aux;
                }
            }
        }
        //Muestra el array ordenado
        for (i = 1; i < arrayValores.length; i++) {
            System.out.print(""+arrayValores[i]);
            System.out.print("  ");
        }
    }
    
}
