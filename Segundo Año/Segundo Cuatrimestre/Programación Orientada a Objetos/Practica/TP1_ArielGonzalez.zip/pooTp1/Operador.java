/**
 * Clase Operador Tp 1.1
*/
public class Operador
{
    public static void main(String[] args){
        /**
         * Inicializa las variables a y b
        */
        int a = 8;
        int b = 3;
        
        /**
         * Muestra por pantalla los resultados de las operaciones
         * suma,resta,multiplicacion y division realizados entre a y b
        */
        System.out.println("Resultado resta: "+(a-b));
        System.out.println("Resultado suma: "+(a+b));
        System.out.println("Resultado multiplicacion: "+(a*b));
        System.out.println("Resultado division: "+(a/b));
    }

}
