import java.util.Scanner;
public class OperarVector
{
    public static void main(String[] args){
        Scanner leer = new Scanner(System.in);//Crea un objeto de la clase Scanner
        int[] notas = new int[5];//Crea un array de enteros
        double promedio = 0;
        int sumaNotas = 0;
        int notaMayor = 0;
        
        for(int i = 0;i < 5;i++){
            //Ingresa las notas
            System.out.println("Ingrese la nota");
            notas[i] = leer.nextInt();
            //suma las notas
            sumaNotas += notas[i];
            //compara la nota actual con el mayor
            if(notas[i] > notaMayor){
                notaMayor = notas[i];
            }
        }
        //calcula el promedio de las notas
        promedio = sumaNotas / 5;
        //Muestra por pantalla
        System.out.println("El promedio es: "+promedio);
        System.out.println("La mayor nota es: "+notaMayor);
        
    }

       
}
