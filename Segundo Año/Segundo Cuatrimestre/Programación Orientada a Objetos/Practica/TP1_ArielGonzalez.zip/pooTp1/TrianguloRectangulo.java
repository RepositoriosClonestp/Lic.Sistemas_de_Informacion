public class TrianguloRectangulo
{
    public static void main(String[] args ){
        //Convierte a entero los strings y los asigna
        int hipotenusa = Integer.parseInt(args[0]);
        int cateto1 = Integer.parseInt(args[1]);
        int cateto2 = Integer.parseInt(args[2]);
        //Calcula el triangulo
        int triangulo = ((cateto1 * cateto1)+(cateto2 * cateto2));
        if((hipotenusa * hipotenusa) == triangulo){
            System.out.println("Es triangulo rectangulo");
        }else{
            System.out.println("No es triangulo rectangulo");
        }
    }
}
