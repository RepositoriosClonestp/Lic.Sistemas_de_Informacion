public class Triangulo
{
    public static void main(String[] args){
        //Convierte los strings a double
        double a = Double.parseDouble(args[0]);
        double b = Double.parseDouble(args[1]);
        double c = Double.parseDouble(args[2]);
        //calcula el semiperimetro
        double semiperimetro = (a+b+c) / 2;
        //Calcula el area
        double area = Math.sqrt(semiperimetro *(semiperimetro-a) *(semiperimetro-b)*(semiperimetro-c));
        System.out.println("Semiperimetro: "+semiperimetro);
        System.out.println("Area: "+area);
    }
}
