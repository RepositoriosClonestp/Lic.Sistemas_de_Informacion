public class Circunferencia
{
    public static void main(String args){
        int radio = Integer.parseInt(args);
        
        double circunferencia = Math.PI * radio * 2;
        System.out.println("Circunferencia: "+circunferencia);
    }
}
