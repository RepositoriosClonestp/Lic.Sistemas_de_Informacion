/**
*@author Gonzalez Ariel
*Clase Rectangulo Tp 5.3
*/
public class Rectangulo extends FiguraGeometrica
{
   /**
    *Atributos de la Clase 
   */
   private Punto origen;
   private double ancho;
   private double alto;
   
   /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param Punto p_origen
    *@param double p_ancho
    *@param double p_alto
   */
   public Rectangulo(Punto p_origen,double p_ancho,double p_alto){
       super(p_origen);
       this.setAncho(p_ancho);
       this.setAlto(p_alto);
   }
   
   /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param double p_ancho
    *@param double p_alto
    */
   public Rectangulo(double p_ancho,double p_alto){
       super(new Punto(0,0));
       this.setAncho(p_ancho);
       this.setAlto(p_alto);
   }
   
   /**
    *Metodo publico,devuelve la palabra "Rectangulo"
    *@return devuelve un String
   */
   public String nombreFigura(){
       return "Rectangulo";
   }
   
   /**
    *Setter,recibe un double y permite modificar el valor de el atributo ancho
    *@param double p_ancho
   */
   private void setAncho(double p_ancho){
       this.ancho = p_ancho;
   }
   
   /**
    *Setter,recibe un double y permite modificar el valor de el atributo alto
    *@param double p_alto
    */
   private void setAlto(double p_alto){
       this.alto = p_alto;
   }
   
   /**
    *Setter,recibe un Punto y permite modificar el valor de el atributo origen
    *@param Punto p_origen
   */
   private void setOrigen(Punto p_origen){
       this.origen = p_origen;
   }
   
   /**
    *Getter, permite obtener el valor de el atributo ancho
    *@return devuelve un double
   */
   public double getAncho(){
       return this.ancho;
   }
   
   /**
    *Getter, permite obtener el valor de el atributo alto
    *@return devuelve un double
   */
   public double getAlto(){
       return this.alto;
   }
   
   /**
    *Getter, permite obtener el valor de el atributo origen
    *@return devuelve un Punto
   */
   public Punto getOrigen(){
       return this.origen;
   }
   
   /**
    *Metodo publico,recibe 2 parametros y los utiliza para desplazar las coordenadas del origen del rectangulo
   */
   public void desplazar(double p_dx, double p_dy){
       this.getOrigen().desplazar(p_dx,p_dy);
   }
   
   /**
    *Metodo publico,muestra por pantalla las caracteristicas del rectangulo
   */
   public void caracteristicas(){
       System.out.println("******"+this.nombreFigura()+"******");
       System.out.println("Origen("+this.getOrigen().getX()+","+this.getOrigen().getY()+") - Alto:"+this.getAlto()+" - Ancho:"+this.getAncho());
       System.out.println("Superficie:"+this.superficie()+" - Perimetro:"+this.perimetro());
   }
   
   /**
    *Metodo publico,calcula el perimetro del rectangulo
    *@return devuelve un double
   */
   public double perimetro(){
       return (2 * (this.getAncho() + this.getAlto()));
   }
   
   /**
    *Metodo publico,calcula la superficie del rectangulo
    *@return devuelve un double
   */
   public double superficie(){
       return (this.getAncho() * this.getAlto());
   }
   
   /**
    *Metodo publico,calcula la distancia entre 2 rectangulos
    *@param Rectangulo otroRectangulo
    *@return devuelve un double
    */
    public double distanciaA(Rectangulo otroRectangulo){
        return this.getOrigen().distanciaA(otroRectangulo.getOrigen());
    }
   
   /**
    * Metodo publico,calcula cual es el rectangulo mayor
    * @param Rectangulo otroRectangulo
    * @return devuelve un Rectangulo
   */
   public Rectangulo elMayor(Rectangulo otroRectangulo){
       Rectangulo mayor;
       if(this.superficie() > otroRectangulo.superficie()){
            mayor = new Rectangulo(new Punto(this.getOrigen().getX(),this.getOrigen().getY()),this.getAncho(),this.getAlto());
       }else{
            mayor = new Rectangulo(new Punto(otroRectangulo.getOrigen().getX(),otroRectangulo.getOrigen().getY()),otroRectangulo.getAncho(),otroRectangulo.getAlto());
       }
       return mayor;
   }
}
