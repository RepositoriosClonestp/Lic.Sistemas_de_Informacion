import java.util.ArrayList;
/**
*@author Gonzalez Ariel
*Clase Pedido Tp 5.11
*/
public class Pedido
{
    /**
    *Atributos de la Clase 
    */
    private ArrayList<Renglon> renglones;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param ArrayList<Renglon> p_renglones
    */
    public Pedido(ArrayList<Renglon> p_renglones){
        this.setRenglones(p_renglones);
    }
        
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param Renglon p_renglon
    */
    public Pedido(Renglon p_renglon){
        this.agregarRenglon(p_renglon);
    }
    
    /**
    *Setter,recibe un ArrayList y permite modificar el valor de el atributo renglones
    *@param ArrayList<Renglon> p_renglones
    */
    private void setRenglones(ArrayList<Renglon> p_renglones){
        this.renglones = p_renglones;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo renglones
    *@return devuelve un ArrayList
    */
    public ArrayList<Renglon> getRenglones(){
        return this.renglones;
    }
    
    /**
     * Metodo publico, permite agregar un renglon a la lista de renglones
     * @param Renglon p_renglon
     * @return devuelve un boolean
    */
    public boolean agregarRenglon(Renglon p_renglon){
        return this.getRenglones().add(p_renglon);
    }
    
    /**
     * Metodo publico, permite quitar un renglon de la lista de renglones
     * @param Renglon p_renglon
     * @return devuelve un boolean
    */
    public boolean quitarRenglon(Renglon p_renglon){
        if(this.cantidadRenglones() > 1){
            return this.getRenglones().remove(p_renglon);
        }
        return false;
    }
    
    /**
     * Metodo publico, devuelve el tamaño de la lista
     * @return devuelve un int
    */
    public int cantidadRenglones(){
        return this.getRenglones().size();
    }
    
    /**
     * Metodo publico, muestra por pantalla los datos del pedido
    */
    public void mostrar(){
        int totalEtiquetas = 0;
        double totalPedido = 0;
        System.out.println("Pedido:");
        System.out.println("Cantidad de items:"+this.cantidadRenglones());
        for(Renglon unRenglon: this.getRenglones()){
            System.out.print("Item "+this.getRenglones().indexOf(unRenglon)+": ");
            unRenglon.mostrar();
            System.out.println("Precio: $"+unRenglon.getItem().precio(unRenglon.getCantidad()));
            System.out.println("");
            totalEtiquetas += unRenglon.getCantidad();
            totalPedido += unRenglon.getItem().precio(unRenglon.getCantidad());
        }
        System.out.println("--Total pedido:"+totalEtiquetas+" Etiquetas por un importe de:$"+totalPedido);
    }
}
