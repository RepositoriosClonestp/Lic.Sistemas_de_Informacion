/**
*@author Gonzalez Ariel
*Clase Triangulo Tp 5.7
*/
public class Triangulo extends FiguraGeometrica
{
    /**
    *Atributos de la Clase 
    */
    private double base;
    private double altura;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param Punto p_centro
    *@param double p_base
    *@param double p_altura
    */
    public Triangulo(Punto p_centro,double p_base,double p_altura){
        super(p_centro);
        this.setBase(p_base);
        this.setAltura(p_altura);
    }
    
    /**
    *Setter,recibe un double y permite modificar el valor de el atributo base
    *@param double p_base
    */
    private void setBase(double p_base){
        this.base = p_base;
    }
    
    /**
    *Setter,recibe un double y permite modificar el valor de el atributo altura
    *@param double p_altura
    */
    private void setAltura(double p_altura){
        this.altura = p_altura;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo altura
    *@return devuelve un double
    */
    public double getAltura(){
        return this.altura;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo base
    *@return devuelve un double
    */
    public double getBase(){
        return this.altura;
    }
    
    /**
    *Metodo publico,devuelve la palabra "Triangulo"
    *@return devuelve un String
    */
    public String nombreFigura(){
        return "Triangulo";
    }
    
    /**
    *Metodo publico,calcula la superficie del triangulo
    *@return devuelve un double
    */
    public double superficie(){
        return ((base * altura) / 2);
    }
    
    /**
    *Metodo publico,muestra por pantalla la superficie del triangulo
    */
    public void mostrarSuperficie(){
        System.out.println("***"+this.nombreFigura()+"***");
        System.out.println("Superficie:"+this.superficie());
    }
}