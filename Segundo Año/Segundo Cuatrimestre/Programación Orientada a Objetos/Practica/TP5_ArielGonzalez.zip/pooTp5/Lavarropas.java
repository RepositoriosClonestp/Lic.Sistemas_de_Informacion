/**
*@author Gonzalez Ariel
*Clase Lavarropas Tp 5.8
*/
public class Lavarropas extends ArtefactoHogar
{
    /**
    *Atributos de la Clase 
    */
    private int programas;
    private float kilos;
    private boolean automatico;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_marca
    *@param float p_precio
    *@param float p_stock
    *@param int p_programas
    *@param float p_kilos
    *@param boolean p_automatica
    */
    public Lavarropas(String p_marca,float p_precio,int p_stock,int p_programas,float p_kilos,boolean p_automatico){
        super(p_marca,p_precio,p_stock);
        this.setProgramas(p_programas);
        this.setKilos(p_kilos);
        this.setAutomatico(p_automatico);
    }
    
    /**
    *Setter,recibe un int y permite modificar el valor de el atributo programas
    *@param int p_programas
    */
    private void setProgramas(int p_programas){
        this.programas = p_programas;
    }
    
    /**
    *Setter,recibe un float y permite modificar el valor de el atributo kilos
    *@param float p_kilos
    */
    private void setKilos(float p_kilos){
        this.kilos = p_kilos;
    }
    
    /**
    *Setter,recibe un boolean y permite modificar el valor de el atributo automatico
    *@param boolean p_automatico
    */
    private void setAutomatico(boolean p_automatico){
        this.automatico = p_automatico;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo programas
    *@return devuelve un int
    */
    public int getProgramas(){
        return this.programas;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo kilos
    *@return devuelve un float
    */
    public float getKilos(){
        return this.kilos;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo automatico
    *@return devuelve un boolean
    */
    public boolean getAutomatico(){
        return this.automatico;
    }
    
    /**
     * Metodo publico, muestra por pantalla los datos del lavarropa
    */
    public void imprimir(){
        System.out.println("***Lavarropa***");
        super.imprimir();
        System.out.println("Programas:"+this.getProgramas());
        System.out.println("Kilos:"+this.getKilos());
        if(this.getAutomatico()){
            System.out.println("Automatico:Si");    
        }else{
            System.out.println("Automatico:No");    
        }
        
    }
    
    /**
     * Metodo publico, calcula el valor de la cuota con el adicional
     * @param int p_cuotas
     * @param float p_interes
     * @return devuelve un float
    */
    public float creditoConAdicional(int p_cuotas,float p_interes){
       float valorCuota = super.cuotaCredito(p_cuotas,p_interes);
       if(this.getAutomatico()){
           valorCuota -= (valorCuota * 0.02);
       }
       return valorCuota;
    }
}
