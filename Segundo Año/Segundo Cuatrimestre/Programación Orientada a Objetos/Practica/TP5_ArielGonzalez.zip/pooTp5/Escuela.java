public class Escuela
{
    public static void main(String[] args){
        Alumno unAlumno = new Alumno(42735725,1,"Ariel","Gonzalez",2000);
        unAlumno.setNota1(7);
        unAlumno.setNota2(8);
        unAlumno.mostrar();    
    }
}
