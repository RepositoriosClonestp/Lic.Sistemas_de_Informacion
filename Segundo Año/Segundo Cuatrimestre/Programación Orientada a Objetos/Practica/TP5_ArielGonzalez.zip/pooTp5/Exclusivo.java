/**
*@author Gonzalez Ariel
*Clase Exclusivo Tp 5.5
*/
public class Exclusivo extends Cargo
{
    /**
    *Atributos de la Clase 
    */
    private int horasDeInvestigacion;
    private int horasDeExtension;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombreCargo
    *@param double p_importe
    *@param int p_anio
    *@param int p_horasDocencia
    *@param int p_horasInvestigacion
    *@param int p_horasExtension
    */
    public Exclusivo(String p_nombreCargo,double p_importe,int p_anio,int p_horasDocencia,int p_horasInvestigacion,int p_horasExtension){
        super(p_nombreCargo,p_importe,p_anio,p_horasDocencia);
        this.setHorasDeInvestigacion(p_horasInvestigacion);
        this.setHorasDeExtension(p_horasExtension);
    }
    
    /**
    *Setter,recibe un int y permite modificar el valor de el atributo horasDeInvestigacion
    *@param int p_horasInvestigacion
    */
    private void setHorasDeInvestigacion(int p_horasInvestigacion){
        this.horasDeInvestigacion = p_horasInvestigacion;
    }
    
    /**
    *Setter,recibe un int y permite modificar el valor de el atributo horasExtension
    *@param int p_horasExtension
    */
    private void setHorasDeExtension(int p_horasExtension){
        this.horasDeExtension = p_horasExtension;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo horasDeInvestigacion
    *@return devuelve un int
    */
    public int getHorasDeInvestigacion(){
        return this.horasDeInvestigacion;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo horasDeExtension
    *@return devuelve un int
    */
    public int getHorasDeExtension(){
        return this.horasDeExtension;
    }
    
    /**
     * Metodo Publico,muestra por pantalla los datos del cargo
    */
    public void mostrarCargo(){
        super.mostrarCargo();
        System.out.println("----Cargo de caracter Exclusivo----");
        System.out.println("Horas de Investigacion: "+this.getHorasDeInvestigacion());
        System.out.println("Horas de Extension: "+this.getHorasDeExtension());
    }
}
