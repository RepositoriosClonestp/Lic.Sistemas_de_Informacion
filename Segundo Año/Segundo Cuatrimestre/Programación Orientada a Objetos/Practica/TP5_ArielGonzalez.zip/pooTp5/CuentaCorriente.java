/**
*@author Gonzalez Ariel
*Clase CuentaCorriente Tp 5.6
*/
public class CuentaCorriente extends CuentaBancaria
{
    /**
     * Atributos de la clase
    */
    private double limiteDescubierto;
    
    /**
    *Constructor con parametros, instancia un objeto
    *@param int p_nroCuenta
    *@param Persona p_titular
    */
    public CuentaCorriente(int p_nroCuenta, Persona p_titular){
        super(p_nroCuenta,p_titular);
        this.setLimiteDescubierto(500);
    }
    
    /**
    *Constructor con parametros, instancia un objeto
    *@param int p_nroCuenta
    *@param Persona p_titular
    *@param double p_saldo
    */
    public CuentaCorriente(int p_nroCuenta,Persona p_titular, double p_saldo){
        super(p_nroCuenta,p_titular,p_saldo);
        this.setLimiteDescubierto(500);
    }
    
    /**
    *Getter, retorna el valor del atributo limiteDescubierto
    *@return devuelve un double
    */
    public double getLimiteDescubierto(){
        return this.limiteDescubierto;
    }
    
    /**
    *Setter, recibe un double y permite modificar el valor del atributo limiteDescubierto
    *@param double p_limite
    */
    private void setLimiteDescubierto(double p_limite){
        this.limiteDescubierto = p_limite;
    }
    
    /**
     * Metodo privado, comprueba si el cliente puede realizar extracciones
     *@param double p_importe
     *@return devuelve un booleano
    */
    private boolean puedeExtraer(double p_importe){
        return ((this.getSaldo() + this.getLimiteDescubierto() > p_importe));
    }
    
    /**
     * Metodo privado, realiza la extraccion
     * @param double p_importe
    */
    public boolean extraer(double p_importe){
        if(this.puedeExtraer(p_importe)){
            return super.extraer(p_importe);    
        }
        return false;
    }
    
    /**
     * Metodo publico, cordina la operacion extraccion
     * @param double p_importe
    */
    public String xQNoPuedeExtraer(double p_importe){
        return "El importe a extraccion sobrepasa el limite de descubierto!";
    }
    
    /**
     * Metodo publico, recibe un importe por parametro para depositar
     * @param double p_importe
    */
    public void depositar(double p_importe){
        super.depositar(p_importe);
    }
    
    /**
     * Metodo publico, muestra por pantalla los datos de la caja de ahorro y de su titular
    */
    public void mostrar(){
        System.out.println("-Cuenta Corriente-");
        super.mostrar();
        System.out.println("Descubierto: "+this.getLimiteDescubierto());
    }
}
