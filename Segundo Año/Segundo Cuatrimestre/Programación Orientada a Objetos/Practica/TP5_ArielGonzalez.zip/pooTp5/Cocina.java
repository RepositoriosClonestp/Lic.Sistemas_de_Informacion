/**
*@author Gonzalez Ariel
*Clase Cocina Tp 5.8
*/
public class Cocina extends ArtefactoHogar
{
    /**
    *Atributos de la Clase 
    */
    private int hornallas;
    private int calorias;
    private String dimensiones;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_marca
    *@param float p_precio
    *@param int p_stock
    *@param int p_hornallas
    *@param int p_calorias
    *@param String p_dimensiones
    */
    public Cocina(String p_marca,float p_precio,int p_stock,int p_hornallas,int p_calorias,String p_dimensiones){
        super(p_marca,p_precio,p_stock);
        this.setHornallas(p_hornallas);
        this.setCalorias(p_calorias);
        this.setDimensiones(p_dimensiones);
    }
    
    /**
    *Setter,recibe un int y permite modificar el valor de el atributo hornallas
    *@param int p_hornallas
    */
    private void setHornallas(int p_hornallas){
        this.hornallas = p_hornallas;
    }
    
    /**
    *Setter,recibe un int y permite modificar el valor de el atributo calorias
    *@param int p_calorias
    */
    private void setCalorias(int p_calorias){
        this.calorias = p_calorias;
    }
    
    /**
    *Setter,recibe un String y permite modificar el valor de el atributo dimensiones
    *@param String p_dimensiones
    */
    private void setDimensiones(String p_dimensiones){
        this.dimensiones = p_dimensiones;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo hornallas
    *@return devuelve un int
    */
    public int getHornallas(){
        return this.hornallas;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo calorias
    *@return devuelve un int
    */
    public int getCalorias(){
        return this.calorias;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo dimensiones
    *@return devuelve un String
    */
    public String getDimensiones(){
        return this.dimensiones;
    }
    
    /**
     *Muestra por pantalla los datos de la cocina
    */
    public void imprimir(){
        System.out.println("***Cocina***");
        super.imprimir();
        System.out.println("Honallas:"+this.getHornallas());
        System.out.println("Calorias:"+this.getCalorias());
        System.out.println("Dimensiones:"+this.getDimensiones());
    }
    
    /**
     *Metodo publico, devuelve el valor de la cuota con el adicional
     *@param int p_cuotas
     *@param float p_interes
     *@return devuelve un float
    */
    public float creditoConAdicional(int p_cuotas,float p_interes){
        return super.cuotaCredito(p_cuotas,p_interes);
    }
}
