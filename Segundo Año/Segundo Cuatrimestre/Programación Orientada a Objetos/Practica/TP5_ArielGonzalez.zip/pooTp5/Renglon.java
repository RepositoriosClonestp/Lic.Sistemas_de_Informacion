/**
*@author Gonzalez Ariel
*Clase Renglon Tp 5.11
*/
public class Renglon
{
    /**
     * Atributos de la Clase
    */
    private int cantidad;
    private double importe;
    private Etiqueta item;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param int p_cantidad
    *@param double p_importe
    *@param Etiqueta p_item
    */
    public Renglon(int p_cantidad,double p_importe,Etiqueta p_item){
        this.setCantidad(p_cantidad);
        this.setImporte(p_importe);
        this.setItem(p_item);
    }
    
    /**
    *Setter,recibe un int y permite modificar el valor de el atributo cantidad
    *@param int p_cantidad
    */
    private void setCantidad(int p_cantidad){
        this.cantidad = p_cantidad;
    }
    
    /**
    *Setter,recibe un double y permite modificar el valor de el atributo importe
    *@param double p_importe
    */
    private void setImporte(double p_importe){
        this.importe = p_importe;
    }
    
    /**
    *Setter,recibe un Etiqueta y permite modificar el valor de el atributo item
    *@param Etiqueta p_item
    */
    private void setItem(Etiqueta p_item){
        this.item = p_item;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo cantidad
    *@return devuelve un int
    */
    public int getCantidad(){
        return this.cantidad;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo importe
    *@return devuelve un double
    */
    public double geTimporte(){
        return this.importe;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo item
    *@return devuelve una Etiqueta
    */
    public Etiqueta getItem(){
        return this.item;
    }
    
    /**
     * Metodo publico, muestra por pantalla los datos de la etiqueta
    */
    public void mostrar(){
        System.out.println(""+this.getCantidad()+" Etiquetas de "+this.getItem().toString());
    }
}
