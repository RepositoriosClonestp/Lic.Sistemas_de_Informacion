/**
*@author Gonzalez Ariel
*Clase Comun Tp 5.11
*/
public class Comun extends Etiqueta
{
    /**
     * Atributos de la Clase
    */
    private double plus;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param double p_costo
    *@param double p_plus
    */
    public Comun(double p_costo,double p_plus){
        super(p_costo);
        this.setPlus(p_plus);
    }
    
    /**
    *Setter,recibe un double y permite modificar el valor de el atributo plus
    *@param double p_plus
    */
    private void setPlus(double p_plus){
        this.plus = p_plus;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo plus
    *@return devuelve un double
    */
    public double getPlus(){
        return this.plus;
    }
    
    /**
     * Metodo privado, calcula el precio de la etiqueta
     * @return devuelve un double
    */
    public double precio(int q){
        return (((super.getCosto() * q) - this.descuento(q))+ this.getPlus());
    }
    
    /**
     * Metodo privado, calcula el descuento del precio
     * @return devuelve un double
    */
    private double descuento(int q){
        if(q <= 10){
            return 0;
        }else if(q <= 51){
            return ((super.getCosto() * q) * 0.02);
        }else if(q <= 100){
            return ( (0.05 * this.getCosto()) * q);
        }
        return ((super.getCosto() * q * 1* (q / 10)));
    }
    
    /**
     * Metodo publico, devuelve una cadena con los datos de la etiqueta
     * @return devuelve un String
    */
    public String toString(){
        return (super.toString()+" - Diseño:$100");
    }
    
    /**
     * Metodo publico, devuelve una cadena con el tipo de la etiqueta
     * @return devuelve un String
    */
    protected String tipo(){
        return "Comun";
    }
}
