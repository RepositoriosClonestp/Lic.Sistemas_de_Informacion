/**
*@author Gonzalez Ariel
*Clase Elipse Tp 5.4
*/
public class Elipse extends FiguraGeometrica
{
    /**
    *Atributos de la Clase 
    */
    private double sEjeMayor;
    private double sEjeMenor;
    private Punto centro;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param Punto p_centro
    *@param double p_sEjeMayor
    *@param double p_sEjeMenor
    */
    public Elipse(Punto p_centro,double p_sEjeMayor,double p_sEjeMenor){
        super(p_centro);
        this.setEjeMayor(p_sEjeMayor);
        this.setEjeMenor(p_sEjeMenor);
    }
    
    /**
    *Setter,recibe un double y permite modificar el valor de el atributo sEjeMayor
    *@param double p_sEjeMayor
    */
    private void setEjeMayor(double p_sEjeMayor){
        this.sEjeMayor = p_sEjeMayor;
    }
    
    /**
    *Setter,recibe un double y permite modificar el valor de el atributo sEjeMenor
    *@param double p_sEjeMenor
    */
    private void setEjeMenor(double p_sEjeMenor){
        this.sEjeMenor = p_sEjeMenor;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo sEjeMayor
    *@return devuelve un double
    */
    public double getEjeMayor(){
        return this.sEjeMayor;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo sEjeMenor
    *@return devuelve un double
    */
    public double getEjeMenor(){
        return this.sEjeMenor;
    }
    
    /**
    *Metodo publico,devuelve la palabra "Elipse"
    *@return devuelve un String
    */
    public String nombreFigura(){
        return "Elipse";
    }
    
    /**
    *Metodo publico,recibe 2 parametros y los utiliza para desplazar las coordenadas del origen de la elipse
    */
    public void desplazar(double p_dx, double p_dy){
        super.getCentro().desplazar(p_dx,p_dy);    
    }
    
    /**
    *Metodo publico,calcula la superficie de la elipse
    *@return devuelve un double
    */
    public double superficie(){
        return (Math.PI * this.getEjeMayor() * this.getEjeMenor());
    }
    
    /**
    *Metodo publico,calcula la distancia entre 2 elipses
    *@param Elipse otraElipse
    *@return devuelve un double
    */
    public double distanciaA(Elipse otraElipse){
        return super.getCentro().distanciaA(otraElipse.getCentro());
    }
    
    /**
    * Metodo publico,calcula cual es el rectangulo mayor
    * @param Rectangulo otroRectangulo
    * @return devuelve un Rectangulo
    */
    public Elipse elMayor(Elipse otraElipse){
        Elipse mayor;
        if(this.superficie() > otraElipse.superficie()){
            mayor = new Elipse(new Punto(super.getCentro().getX(),super.getCentro().getY()),this.getEjeMayor(),this.getEjeMenor());
        }else{
            mayor = new Elipse(new Punto(otraElipse.getCentro().getX(),otraElipse.getCentro().getY()),otraElipse.getEjeMayor(),otraElipse.getEjeMenor());
        }
        return mayor;
    }
    
    /**
    *Metodo publico,muestra por pantalla las caracteristicas de la elipse
    */
    public void caracteristicas(){
        System.out.println("******"+this.nombreFigura()+"******");
        System.out.println("Centro: ("+super.getCentro().getX()+", "+super.getCentro().getY()+") - Semieje Mayor: "+this.getEjeMayor()+" - SemiejeMenor:"+this.getEjeMenor());
        System.out.println("Superficie:"+this.superficie());
    }
    
    /**
    *Metodo publico,muestra por pantalla la superficie de la elipse
    */
    public void mostrarSuperficie(){
        System.out.println("***"+this.nombreFigura()+"***");
        System.out.println("Superficie:"+this.superficie());
    }
}
