/**
*@author Gonzalez Ariel
*Clase Premium Tp 5.11
/**
*@author Gonzalez Ariel
*Clase Premium Tp 5.11
*/
public class Premium extends Etiqueta
{
    /**
     * Atributos de la Clase
    */
    private int colores;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param double p_costo
    *@param int p_colores
    */
    public Premium(double p_costo,int p_colores){
        super(p_costo);
        this.setColores(p_colores);
    }
    
    /**
    *Setter,recibe un int y permite modificar el valor de el atributo colores
    *@param int p_colores
    */
    private void setColores(int p_colores){
        this.colores = p_colores;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo colores
    *@return devuelve un int
    */
    public int getColores(){
        return this.colores;
    }
    
    /**
     * Metodo publico, calcula el precio de la etiqueta
     * @return devuelve un double
    */
    public double precio(int q){
        return((this.getCosto() + this.adicional())* q);
    }
    
    /**
     * Metodo privado, calcula el adicional del precio
     * @return devuelve un double
    */
    private double adicional(){
        if(this.getColores() == 2){
            return (super.getCosto() * 0.05 * this.getColores());
        }else if(this.getColores() == 3){
            return (super.getCosto() * 0.07 * this.getColores());
        }else if(this.getColores() > 3){
            return (super.getCosto() * 0.03 * this.getColores());
        }
        return 0;
    }
    
    /**
     * Metodo publico, devuelve una cadena con los datos de la etiqueta
     * @return devuelve un String
    */
    public String toString(){
        return (super.toString()+" - Colores:"+this.getColores());
    }
    
    /**
     * Metodo publico, devuelve una cadena con el tipo de la etiqueta
     * @return devuelve un String
    */
    protected String tipo(){
        return "Premium";
    }
}
