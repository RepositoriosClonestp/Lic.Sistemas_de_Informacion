import java.util.Scanner;
import java.util.ArrayList;

public class Comercio
{
    public static void main(String[] args){
        Scanner leer = new Scanner(System.in);
        int opcion = 0;
        ArrayList<ArtefactoHogar> listaArtefactos = new ArrayList();
        do{
            System.out.println("Ingrese la opcion que desea realizar");
            System.out.println("1-Crear cocina, 2-Crear lavarropa,3-Crear Heladera,4-Mostrar artefactos");
            opcion = leer.nextInt();
            System.out.println("Ingrese la cantidad de cuotas:");
            int cuotas = leer.nextInt();
            float interes = (float)2.53;
            switch(opcion){
                case 1:
                    System.out.println("Ingrese la marca:");
                    String marca = leer.next(); 
                    System.out.println("Ingrese la cant de hornallas:");
                    int hornallas = leer.nextInt();
                    System.out.println("Ingrese las calorias:");
                    int calorias = leer.nextInt();
                    System.out.println("Ingrese las dimensiones:");
                    String dimensiones = leer.next();
                    listaArtefactos.add(new Cocina(marca,600,15,hornallas,calorias,dimensiones));
                    break;
                case 2:
                    System.out.println("Ingrese la marca:");
                    String marcaLavarropa = leer.next();
                    System.out.println("Ingrese la cant de programas:");
                    int programas = leer.nextInt();                  
                    listaArtefactos.add(new Lavarropas(marcaLavarropa,2000,10,programas,40,true));
                    break;
                case 3:
                    listaArtefactos.add(new Heladera("Gafa",1200,8,11,2,true));
                    break;
                case 4:
                    for(ArtefactoHogar unArtefacto: listaArtefactos){
                        unArtefacto.imprimir();
                        System.out.println("Cuotas:"+cuotas+" - Interes:"+interes+"%");
                        System.out.println("Valor Cuota:"+unArtefacto.cuotaCredito(cuotas,interes));
                        System.out.println("Valor Cuota con adicionales:"+unArtefacto.creditoConAdicional(cuotas,interes));
                    }
                    break;
            }
        }while(opcion != 0);
    }
}
