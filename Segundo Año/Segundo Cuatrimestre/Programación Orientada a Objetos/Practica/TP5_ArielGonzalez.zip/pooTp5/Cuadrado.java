/**
*@author Gonzalez Ariel
*Clase Cuadrado Tp 5.3
*/
public class Cuadrado extends Rectangulo
{
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param Punto p_origen
    *@param double p_lado
    */
    public Cuadrado(Punto p_origen,double p_lado){
        super(p_origen,p_lado,p_lado);
    }
    
    public String nombreFigura(){
        return "Cuadrado";
    }
    
    /**
    *Metodo publico,muestra por pantalla las caracteristicas del Cuadrado
    */
    public void caracteristicas(){
       System.out.println("******"+this.nombreFigura()+"******");
       System.out.println("Origen("+super.getOrigen().getX()+","+super.getOrigen().getY()+") - Lado:"+super.getAlto());
       System.out.println("Superficie:"+super.superficie()+" - Perimetro:"+super.perimetro());
    }
    
    /**
    *Metodo publico,muestra por pantalla las superficie del cuadrado
    */
    public void mostrarSuperficie(){
        System.out.println("***"+this.nombreFigura()+"***");
        System.out.println("Superficie:"+super.superficie());
    }
}
