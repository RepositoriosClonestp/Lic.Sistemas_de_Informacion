import java.util.ArrayList;
/**
*@author Gonzalez Ariel
*Clase Hotel Tp 5.9
*/
public class Hotel extends Alojamiento
{
    /**
    *Atributos de la Clase 
    */
    private String tipoHabitacion;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombre
    *@param double p_precioBase
    *@param int p_diasAlquiler
    *@param ArrayList<Cargo> p_servicos
    *@param String  p_tipoHabitacion
    */
    public Hotel(String p_nombre,double p_precioBase,int p_diasAlquiler,ArrayList<Servicio> p_servicios,String p_tipoHabitacion){
        super(p_nombre,p_precioBase,p_diasAlquiler,p_servicios);
        this.setTipoHabitacion(p_tipoHabitacion);
    }
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombre
    *@param double p_precioBase
    *@param int p_diasAlquiler
    *@param String  p_tipoHabitacion
    */
    public Hotel(String p_nombre,double p_precioBase,int p_diasAlquiler,String p_tipoHabitacion){
        super(p_nombre,p_precioBase,p_diasAlquiler);
        this.setTipoHabitacion(p_tipoHabitacion);
    }
    
    /**
     * Metodo publico, agrega un servicio a la lista 
    */
    public boolean agregarServicio(Servicio p_servicio){
        return super.agregarServicio(p_servicio);
    }
    
    /**
     * Metodo publico, quita un servicio de la lista 
    */
    public boolean quitarServicio(Servicio p_servicio){
        return super.quitarServicio(p_servicio);
    }
    
    /**
    *Setter,recibe un String y permite modificar el valor de el atributo tipoHabitacion
    *@param String p_tipoHabitacion
    */
    private void setTipoHabitacion(String p_tipoHabitacion){
        this.tipoHabitacion = p_tipoHabitacion;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo tipoHabitacion
    *@return devuelve un String
    */
    public String getTipoHabitacion(){
        return this.tipoHabitacion;
    }
    
    /**
     * Metodo publico, devuelve el costo de el alquiler de la habitacion
    */
    public double costo(){
        if(this.getTipoHabitacion().contains("Single")){
            return (super.costo() + (super.getDiasAlquiler() * 20));    
        }else{
            return (super.costo() + (super.getDiasAlquiler() * 35));    
        }
    }
    
    /**
     * Metodo publico, cuenta un alojamiento
    */
    public int contar(String p_alojamiento){
        if(p_alojamiento.contains("Hotel")){
            return 1;
        }
        return 0;
    }
    
    /**
     * Metodo publico, muestra por pantalla los datos del alquiler
    */
    public void liquidar(){
        super.liquidar();
        System.out.println("Habitacion "+this.getTipoHabitacion());
        System.out.println("Total:------>$"+(this.costo() + super.costoServicios()));
    }
}
