import java.util.ArrayList;
/**
*@author Gonzalez Ariel
*Clase Jardin Tp 5.7
*/
public class Jardin
{
    /**
    *Atributos de la Clase 
    */
    private String nombre;
    private ArrayList<FiguraGeometrica> figuras;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombre
    *@param FiguraGeometrica p_figura
    */
    public Jardin(String p_nombre,FiguraGeometrica p_figura){
        this.agregarFigura(p_figura);
        this.setNombre(p_nombre);
    }
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombre
    */
    public Jardin(String p_nombre){
        this.setFiguras(new ArrayList<FiguraGeometrica>());
        this.setNombre(p_nombre);
    }
    
    /**
    *Setter,recibe un ArrayList y permite modificar el valor de el atributo figuras
    *@param String p_figuras
    */
    private void setFiguras(ArrayList<FiguraGeometrica> p_figuras){
        this.figuras = p_figuras;
    }
    
    /**
    *Setter,recibe un String y permite modificar el valor de el atributo nombre
    *@param String p_nombre
    */
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    /**
     * Metodo publico, permite agregar una figura a la lista de figuras
     * @param FiguraGeometrica p_figura
     * @return devuelve un boolean
    */
    public boolean agregarFigura(FiguraGeometrica p_figura){
        return this.figuras.add(p_figura);
    }
    
    /**
     * Metodo publico, permite quitar una figura a la lista de figuras
     * @param FiguraGeometrica p_figura
     * @return devuelve un boolean
    */
    public boolean quitarFigura(FiguraGeometrica p_figura){
        return this.figuras.remove(p_figura);
    }
    
    /**
    *Getter, permite obtener el valor de el atributo figuras
    *@return devuelve un ArrayList
    */
    public ArrayList<FiguraGeometrica> getListaFiguras(){
        return this.figuras;
    }
    
    /**
     * Metodo privado, calcula la cantidad de litros necesarios
     * @return devuelve un double
    */
    private double cuantosLitros(){
        return (this.cuantasLatas() * 4);
    }
    
    /**
     * Metodo publico, calcula la cantidad de latas necesarias
     * @return devuelve un int
    */
    public int cuantasLatas(){
        int cantLatas = (int)Math.ceil(this.cuantosMetros() / 20);
        return cantLatas;
    }
    
    /**
     * Metodo publico, calcula la cantidad de metros a cubrir
     * @return devuelve un double
    */
    public double cuantosMetros(){
        double totalSuperficie = 0;
        for(FiguraGeometrica figura: this.getListaFiguras()){
            totalSuperficie += figura.superficie();
        }
        return totalSuperficie;
    }
    
    /**
     * Metodo publico, muestra por pantalla los datos del presupuesto
    */
    public void detalleFiguras(){
        System.out.println("Presupuesto Bichito de Luz");
        for(FiguraGeometrica figura: this.getListaFiguras()){
            figura.mostrarSuperficie();
        }
        System.out.println("-----------------");
        System.out.println("Total a cubrir:"+this.cuantosMetros());
        System.out.println("Comprar "+this.cuantasLatas()+" latas");
    }
}
