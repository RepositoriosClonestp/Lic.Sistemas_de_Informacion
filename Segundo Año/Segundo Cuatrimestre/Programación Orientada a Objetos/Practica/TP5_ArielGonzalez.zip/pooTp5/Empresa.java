public class Empresa
{
    public static void main(String[] args){
        Persona unaPersona = new Persona(42325764,"Ariel","Gonzalez",2000);
        unaPersona.mostrar();
        Empleado unEmpleado = new Empleado(42325764,3572985L,"Ariel","Gonzalez",325265,2000);
        unEmpleado.mostrar();
    }
}
