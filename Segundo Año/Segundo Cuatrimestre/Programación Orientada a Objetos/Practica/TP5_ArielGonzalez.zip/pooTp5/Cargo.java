import java.util.Calendar;
import java.util.GregorianCalendar;
/**
*@author Gonzalez Ariel
*Clase Cargo Tp 5.5
*/
public class Cargo
{
    /**
    *Atributos de la Clase 
    */
    private String nombreCargo;
    private double sueldoBasico;
    private int anioIngreso;
    private int horasDeDocencia;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombreCargo
    *@param double p_importe
    *@param int p_anio
    *@param int p_horas
    */
    public Cargo(String p_nombreCargo,double p_importe,int p_anio,int p_horas){
        this.setNombreCargo(p_nombreCargo);
        this.setSueldoBasico(p_importe);
        this.setAnioIngreso(p_anio);
        this.setHorasDocencia(p_horas);
    }
    
    /**
    *Setter,recibe un String y permite modificar el valor de el atributo nombreCargo
    *@param String p_nombreCargo
    */
    private void setNombreCargo(String p_nombreCargo){
        this.nombreCargo = p_nombreCargo;
    }
    
    /**
    *Setter,recibe un int y permite modificar el valor de el atributo anio
    *@param int p_anio
    */
    private void setAnioIngreso(int p_anio){
        this.anioIngreso = p_anio;
    }
    
    /**
    *Setter,recibe un double por parametro y permite modificar el valor de el atributo sueldoBasico
    *@param double p_importe
    */
    private void setSueldoBasico(double p_importe){
        this.sueldoBasico = p_importe;
    }
    
    /**
    *Setter,recibe un int y permite modificar el valor de el atributo horasDeDocencia
    *@param int p_horas
    */
    private void setHorasDocencia(int p_horas){
        this.horasDeDocencia = p_horas;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo nombreCargo
    *@return devuelve un String
    */
    public String getNombreCargo(){
        return this.nombreCargo;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo sueldoBasico
    *@return devuelve un double
    */
    public double getSueldoBasico(){
        return this.sueldoBasico;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo fechaIngreso
    *@return devuelve un int
    */
    public int getAnio(){
        return this.anioIngreso;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo horasDeDocencia
    *@return devuelve un int
    */
    public int getHorasDocencia(){
        return this.horasDeDocencia;
    }
    
    /**
    *Metodo publico, calcula la antiguedad
    *@return devuelve un int
    */
    public int antiguedad(){
        Calendar añoHoy = new GregorianCalendar();
        return (añoHoy.get(Calendar.YEAR) - this.getAnio());
    }
    
    /**
    *Metodo publico, calcula el adicional con respecto a la antiguedad
    *@return devuelve un double
    */
    private double adicionalXAntiguedad(){
        return ((1 * this.getSueldoBasico()) / 100);
    }
    
    /**
    *Metodo publico, calcula el sueldo del cargo
    *@return devuelve un double
    */
    public double sueldoDelCargo(){
        return (this.getSueldoBasico() + adicionalXAntiguedad());
    }
    
    /**
    *Metodo publico, muestrar por pantalla las caracteristicas del cargo
    */
    public void mostrarCargo(){
        System.out.println(""+this.getNombreCargo()+" - Sueldo Basico:"+this.getSueldoBasico()+" - Sueldo Cargo:"+this.sueldoDelCargo()+" - Antiguedad:"+this.antiguedad()+" años");
        System.out.println("Horas Docencia:"+this.getHorasDocencia());
    }
}
