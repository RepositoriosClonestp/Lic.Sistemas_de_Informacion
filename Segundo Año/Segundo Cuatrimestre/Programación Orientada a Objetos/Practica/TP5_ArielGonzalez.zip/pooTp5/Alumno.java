import java.util.Calendar;
/**
*@author Gonzalez Ariel
*Clase Alumno 5.1
*/
public class Alumno extends Persona
{
    /**
     * Atributos de la clase
    */
    private int lu;
    private double nota1;
    private double nota2;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param int p_lu
    *@param String p_nombre
    *@param String p_apellido
    *@param int p_dni
    *@param int p_anio
    */
    Alumno(int p_dni,int p_lu,String p_nombre, String p_apellido,int p_anio){
        super(p_dni,p_nombre,p_apellido,p_anio);
        this.setLu(p_lu);
        this.setNota1(0);
        this.setNota2(0);
    }
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param int p_lu
    *@param String p_nombre
    *@param String p_apellido
    *@param int p_dni
    *@param Calendar p_anio
    */
    public Alumno(int p_dni,int p_lu,String p_nombre,String p_apellido,Calendar p_fecha){
        super(p_dni,p_nombre,p_apellido,p_fecha);
        this.setLu(p_lu);
        this.setNota1(0);
        this.setNota2(0);
    }
    
    /**
    *Setter,recibe un entero por parametro y permite modificar el valor de el atributo lu
    *@param int p_lu
    */
    private void setLu(int p_lu){
        this.lu = p_lu;
    }
    
    /**
    *Setter,recibe un double por parametro y permite modificar el valor de el atributo nota1
    *@param double p_nota
    */
    public void setNota1(double p_nota){
        this.nota1 = p_nota;
    }
    
    /**
    *Setter,recibe un double por parametro y permite modificar el valor de el atributo nota2
    *@param double p_nota2
    */
    public void setNota2(double p_nota){
        this.nota2 = p_nota;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo lu
    *@return devuelve un entero
    */
    public int getLu(){
        return this.lu;
    }

    /**
    *Getter, permite obtener el valor de el atributo nota1
    *@return devuelve un double
    */
    public double getNota1(){
        return this.nota1;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo nota2
    *@return devuelve un double
    */
    public double getNota2(){
        return this.nota2;
    }
    
    /**
     * Metodo publico, devuelve si el alumno aprueba o no
     * @return devuelve un valor boolean
    */
    public boolean aprueba(){
        boolean respuesta;
        if(this.promedio() > 7 && this.getNota1() >= 6 && this.getNota2() >= 6){
            respuesta = true;
        }else{
            respuesta = false;
        }
        return respuesta;
    }
    
    /**
     * Metodo publico, devuelve la situacion del alumno
     * @return devuelve un String
    */
    public String leyendaAprueba(){
        String respuesta;
        
        if(aprueba() == true){
            respuesta = "APROBADO";
        }else{
            respuesta = "DESAPROBADO";
        }
        return respuesta;
    }
    
    /**
     * Metodo publico, devuelve el promedio del alumno
     * @return devuelve un valor double
    */
    public double promedio(){
        double sumaNotas = (this.getNota1()+this.getNota2());
        double promedio = sumaNotas / 2;
        return promedio;
    }
    
    /**
     * Metodo publico, utiliza los metodos getNombre() y getApellido() para formar una cadena de texto
     * @return devuelve un String
    */
    public String nomYApe(){
        return (""+this.getNombre()+" "+this.getApellido());
    }
    
    /**
     * Metodo publico, utiliza los metodos getApellido() y getNombre() para formar una cadena de texto
     * @return devuelve un String
    */
    public String apeYNom(){
        return (""+this.getApellido()+" "+this.getNombre());
    }
    
    /**
     * Metodo publico, muestra por pantalla los datos del alumno
    */
    public void mostrar(){
        super.mostrar();
        System.out.println("LU:"+this.getLu()+" Notas: "+this.getNota1()+" - "+this.getNota2());
        System.out.println("Promedio: "+this.promedio()+" - "+this.leyendaAprueba());
    }
}
