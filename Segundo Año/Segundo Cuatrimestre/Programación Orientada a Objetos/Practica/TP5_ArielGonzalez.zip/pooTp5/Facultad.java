import java.util.ArrayList;
/**
*@author Gonzalez Ariel
*Clase Facultad Tp 5.5
*/
public class Facultad
{
    /**
    *Atributos de la Clase 
    */
    private String nombre;
    private ArrayList<Profesor> profesores;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombre
    *@param Profesor p_profesor
    */
    public Facultad(String p_nombre,Profesor p_profesor){
        this.setNombre(p_nombre);
        this.agregarProfesor(p_profesor);
    }
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombre
    *@param ArrayList<Profesor> p_profesores
    */
    public Facultad(String p_nombre,ArrayList<Profesor> p_profesores){
        this.setNombre(p_nombre);
        this.setListaProfesores(p_profesores);
    }
    
    /**
    *Setter,recibe un ArrayList y permite modificar el valor de el atributo profesores
    *@param ArrayList<Profesor> p_profesores
    */
    private void setListaProfesores(ArrayList<Profesor> p_profesores){
        this.profesores = p_profesores;
    }
    
    /**
    *Setter,recibe un String y permite modificar el valor de el atributo nombre
    *@param String p_nombre
    */
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo profesores
    *@return devuelve un ArrayList
    */
    public ArrayList<Profesor> getListaProfesores(){
        return this.profesores;
    }
    
    /**
     * Metodo publico, permite agregar un profesor a la lista
     * @param Profesor p_profesor
     * @return devuelve un boolean
    */
    public boolean agregarProfesor(Profesor p_profesor){
        return this.getListaProfesores().add(p_profesor);
    }
    
    /**
     * Metodo publico, permite quitar un profesor a la lista
     * @param Profesor p_profesor
     * @return devuelve un boolean
    */
    public boolean quitarProfesor(Profesor p_profesor){
        if(this.getListaProfesores().size() > 1){
            return this.getListaProfesores().remove(p_profesor);
        }else{
            return false;
        }
    }
    
    /**
     * Metodo publico, muestra por pantalla la nomina de profesores de la facultad
    */
    public void nominaProfesores(){
        System.out.println("****Nomina Facultad:FaCENA****");
        System.out.println("------------------------------");
        for(Profesor unProfesor: this.getListaProfesores()){
            System.out.println(unProfesor.mostrarLinea());
        }
        System.out.println("------------------------------");
    }
    
    /**
     * Metodo publico, muestra por pantalla los datos de los profesores
    */
    public void listarProfesorCargos(){
        System.out.println("*****Detalle de Profesores y cargos de Facultad:FaCENA*****");
        for(Profesor unProfesor: this.getListaProfesores()){
            unProfesor.mostrar();
            System.out.println(" ");
        }
        System.out.println("Hay "+this.getListaProfesores().size()+" profesores");
    }
}
