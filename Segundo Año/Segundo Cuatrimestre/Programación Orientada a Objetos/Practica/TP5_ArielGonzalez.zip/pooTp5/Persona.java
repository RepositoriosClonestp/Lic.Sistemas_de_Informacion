import java.util.*;
/**
*@author Gonzalez Ariel
*Clase Persona Tp 5.1
*/
public class Persona
{
    /**
    *Atributos de la Clase 
    */
    private int nroDni;
    private String nombre;
    private String apellido;
    private Calendar fechaNacimiento;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param int p_dni
    *@param String p_nombre
    *@param String p_apellido
    *@param int p_anio
    */
    public Persona(int p_dni,String p_nombre,String p_apellido,int p_anio){
        this.setDni(p_dni);
        this.setNombre(p_nombre);
        this.setApellido(p_apellido);
        this.setAnioNacimiento(p_anio);
    }
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param int p_dni
    *@param String p_nombre
    *@param String p_apellido
    *@param Calendar p_fecha
    */
    public Persona(int p_dni,String p_nombre,String p_apellido,Calendar p_fecha){
        this.setDni(p_dni);
        this.setNombre(p_nombre);
        this.setApellido(p_apellido);
        this.setFechaNacimiento(p_fecha);
    }
    
    /**
    *Setter,recibe un entero y permite modificar el valor de el atributo dni
    *@param int p_dni
    */
    private void setDni(int p_dni){
        this.nroDni = p_dni;
    }
    
    /**
    *Setter,recibe un String y permite modificar el valor de el atributo nombre
    *@param String p_nombre
    */
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    /**
    *Setter,recibe un String y permite modificar el valor de el atributo apellido
    *@param String p_apellido
    */
    private void setApellido(String p_apellido){
        this.apellido = p_apellido;
    }
   
    /**
    *Setter,recibe un entero y permite modificar el valor de el atributo anio
    *@param int p_anio
    */
    
    private void setAnioNacimiento(int p_anio){
        Calendar anioNacimiento = Calendar.getInstance();
        anioNacimiento.set(p_anio,1,1);
        this.fechaNacimiento = anioNacimiento;  
    }

    /**
    *Setter,recibe un entero y permite modificar el valor de el atributo fechaNacimiento
    *@param Calendar p_fecha
    */
    private void setFechaNacimiento(Calendar p_fecha){
        this.fechaNacimiento = p_fecha;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo dni
    *@return devuelve un valor entero
    */
    public int getDni(){
        return this.nroDni;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo nombre
    *@return devuelve un String
    */
    public String getNombre(){
        return this.nombre;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo apellido
    *@return devuelve un String
    */
    public String getApellido(){
        return this.apellido;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo anioNacimiento
    *@return devuelve una valor entero
    */
    public int getAnioNacimiento(){
        return this.getFechaNacimiento().get(Calendar.YEAR);
    }
    
    /**
    *Getter, permite obtener el valor de el atributo fechaNacimiento
    *@return devuelve una valor calendar
    */
    public Calendar getFechaNacimiento(){
        return this.fechaNacimiento;
    }
    
    /**
    *Metodo publico, calcula la edad de la persona
    *@return devuelve un entero
    */
    
    public int edad(){
        Calendar fechaHoy = new GregorianCalendar();
        int anioHoy = fechaHoy.get(Calendar.YEAR);
        return (anioHoy - this.getAnioNacimiento());
    }
    
    /**
    *Metodo publico, devuelve una cadena formada por el nombre y el apellido de la persona
    *@return devuelve un String
    */
    public String nomYApe(){
        return (""+this.getNombre()+" "+this.getApellido());
    }
    
    /**
    *Metodo publico, devuelve una cadena formada por el apellido y el nombre de la persona
    *@return devuelve un String
    */
    public String apeYNom(){
        return (""+this.getApellido()+" "+this.getNombre());
    }
    
    /**
    *Metodo publico, muestra por pantalla los datos de la persona
    */
    public void mostrar(){
        System.out.println("Nombre y apellido: "+this.nomYApe());
        System.out.println("Dni:"+this.getDni()+" Edad: "+this.edad()+" años");
    }
    
    /**
     *Comprueba si el dia actual es el cumpleaños de la persona
     *@return devuelve un booleano
    */
    public boolean esCumpleaños(){
        Calendar fechaActual = new GregorianCalendar();
        int mesHoy = fechaActual.get(Calendar.MONTH)+1;
        int diaHoy = fechaActual.get(Calendar.DATE);
        
        int diaNacimiento = this.getFechaNacimiento().get(Calendar.DATE);
        int mesNacimiento = this.getFechaNacimiento().get(Calendar.MONTH);
        
        return ((diaNacimiento == diaHoy) && (mesHoy == mesNacimiento));
    }
}
