/**
*@author Gonzalez Ariel
*Clase Etiqueta Tp 5.11
*/
public abstract class Etiqueta
{
    /**
     * Atributos de la Clase
    */
    private double costo;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param double p_costo
    */
    public Etiqueta(double p_costo){
        this.setCosto(p_costo);
    }
    
    /**
    *Setter,recibe un double y permite modificar el valor de el atributo costo
    *@param double p_costo
    */
    private void setCosto(double p_costo){
        this.costo = p_costo;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo costo
    *@return devuelve un double
    */
    public double getCosto(){
        return this.costo;
    }
    
    /**
     * Metodo publico,devuelve una cadena con los datos de la etiqueta
     * @return devuelve un String
    */
    public String toString(){
        return ("tipo "+this.tipo()+" - Costo:$"+this.getCosto());
    }
    
    /**
     * Metodos Abstractos
    */
    public abstract double precio(int q);
    protected abstract String tipo();
}
