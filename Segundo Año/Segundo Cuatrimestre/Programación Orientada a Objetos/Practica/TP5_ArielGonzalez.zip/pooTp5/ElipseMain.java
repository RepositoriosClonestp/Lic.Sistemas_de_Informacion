public class ElipseMain
{
    public static void main(String[] args){
        Punto unPunto = new Punto(5,0);
        Circulo unCirculo = new Circulo(unPunto,2);
        Elipse unaElipse = new Elipse(unPunto,20.44,46.86);
        
        unCirculo.caracteristicas();
        unaElipse.caracteristicas();
        
    }
}
