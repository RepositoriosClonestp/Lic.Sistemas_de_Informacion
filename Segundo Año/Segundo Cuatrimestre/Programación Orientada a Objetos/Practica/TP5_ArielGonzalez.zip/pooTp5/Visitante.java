import java.util.Calendar;
/**
*@author Gonzalez Ariel
*Clase Visitante Tp 5.10
*/
public abstract class Visitante
{
    /**
    *Atributos de la Clase 
    */
    private String nombre;
    private Calendar fechaVisita;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombre
    *@param Calendar p_fecha
    */
    public Visitante(String p_nombre,Calendar p_fecha){
        this.setNombre(p_nombre);
        this.setFecha(p_fecha);
    }
    
    /**
    *Setter,recibe un String y permite modificar el valor de el atributo nombre
    *@param String p_nombre
    */
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    /**
    *Setter,recibe un Calendar y permite modificar el valor de el atributo fechaVisita
    *@param Calendar p_fecha
    */
    private void setFecha(Calendar p_fecha){
        this.fechaVisita = p_fecha;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo nombre
    *@return devuelve un String
    */
    public String getNombre(){
        return this.nombre;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo fechaVisita
    *@return devuelve un Calendar
    */
    public Calendar getFechaVisita(){
        return this.fechaVisita;
    }
    
    /**
     * Metodos abstractos
    */
    public abstract void mostrar();
    public abstract double entrada();
    public abstract void listarPorFecha(Calendar p_fecha,String p_visitante);
    public abstract String tipoVisitante();
}
