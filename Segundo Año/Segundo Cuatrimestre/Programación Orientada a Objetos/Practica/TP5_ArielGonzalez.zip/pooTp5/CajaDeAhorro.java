/**
*@author Gonzalez Ariel
*Clase CajaDeAhorro Tp 5.6
*/
public class CajaDeAhorro extends CuentaBancaria
{
    /**
     * Atributos de la clase
    */
    private int extraccionesPosibles;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param int p_nroCuenta
    *@param Persona p_titular
    */
    public CajaDeAhorro(int p_nroCuenta,Persona p_titular){
        super(p_nroCuenta,p_titular);
        this.setExtraccionesPosibles(10);
    }
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param int p_nroCuenta
    *@param Persona p_titular
    *@param double p_saldo
    */
    public CajaDeAhorro(int p_nroCuenta,Persona p_titular, double p_saldo){
        super(p_nroCuenta,p_titular,p_saldo);
        this.setExtraccionesPosibles(10);
    }
    
    /**
    *Getter, permite obtener el valor de el atributo extraccionesPosibles
    *@return devuelve un valor entero
    */
    public int getExtraccionesPosibles(){
        return this.extraccionesPosibles;
    }
    
    /**
    *Setter,recibe un entero y permite modificar el valor de el atributo extracciones
    *@param int p_extracciones
    */
    private void setExtraccionesPosibles(int p_extracciones){
        this.extraccionesPosibles = p_extracciones;
    }
    
    /**
     * Metodo privado,comprueba si el cliente puede realizar extracciones
     *@param double p_importe
     *@return devuelve un booleano
    */
    private boolean puedeExtraer(double p_importe){
        return (this.getExtraccionesPosibles() > 0);
    }
    
    /**
     * Metodo publico, cordina la operacion extraccion
     * @param double p_importe
    */
    public boolean extraer(double p_importe){
        if(this.puedeExtraer(p_importe)){
            boolean respuesta = super.extraer(p_importe);
            this.setExtraccionesPosibles(this.getExtraccionesPosibles() - 1);
            return respuesta;
        }
        return false;
    }
    
    /**
     * Metodo publico, recibe un importe por parametro para depositar
     * @param double p_importe
    */
    public void depositar(double p_importe){
        super.depositar(p_importe);
    }
    
    public String xQNoPuedeExtraer(double p_importe){
        if(this.puedeExtraer(p_importe)){
            return "No hay suficiente saldo";
        }
        return "No hay mas extracciones posibles";
    }
    
    /**
     * Metodo publico, muestra por pantalla los datos de la caja de ahorro y de su titular
    */
    public void mostrar(){
        System.out.println("-Caja de ahorro-");
        super.mostrar();
        System.out.println("Extracciones posibles: "+this.getExtraccionesPosibles());
    }
}
