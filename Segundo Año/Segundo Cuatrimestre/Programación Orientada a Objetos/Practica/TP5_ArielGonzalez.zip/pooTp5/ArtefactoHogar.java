/**
*@author Gonzalez Ariel
*Clase ArtefactoHogar Tp 5.8
*/
public abstract class ArtefactoHogar
{
    /**
    *Atributos de la Clase 
    */
    private String marca;
    private float precio;
    private int stock;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_marca
    *@param float p_precio
    *@param int p_stock
    */
    public ArtefactoHogar(String p_marca,float p_precio,int p_stock){
        this.setMarca(p_marca);
        this.setPrecio(p_precio);
        this.setStock(p_stock);
    }
    
    /**
    *Setter,recibe un String y permite modificar el valor de el atributo marca
    *@param String p_marca
    */
    private void setMarca(String p_marca){
        this.marca = p_marca;
    }
    
    /**
    *Setter,recibe un float y permite modificar el valor de el atributo precio
    *@param float p_precio
    */
    private void setPrecio(float p_precio){
        this.precio = p_precio;
    }
    
    /**
    *Setter,recibe un int y permite modificar el valor de el atributo stock
    *@param String p_stock
    */
    private void setStock(int p_stock){
        this.stock = p_stock;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo stock
    *@return devuelve un int
    */
    public int getStock(){
        return this.stock;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo precio
    *@return devuelve un float
    */
    public float getPrecio(){
        return this.precio;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo marca
    *@return devuelve un String
    */
    public String getMarca(){
        return this.marca;
    }
    
    /**
     * Metodo publico, muestra por pantalla los datos de el artefacto
    */
    public void imprimir(){
        System.out.println("Marca:"+this.getMarca()+" - Precio:"+this.getPrecio()+" - Stock:"+this.getStock());
    }
    
    /**
     * Metodo publico, calcula el valor de la cuota
     * @return devuelve un float
    */
    public float cuotaCredito(int p_cuotas,float p_interes){
        return (this.getPrecio() + (this.getPrecio() * p_interes)) / p_cuotas;
    }
    
    /**
     * Metodo abstracto
    */
    public abstract float creditoConAdicional(int p_cuotas,float p_interes);
}
