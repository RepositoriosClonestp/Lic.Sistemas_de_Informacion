public class Administracion
{   
    public static void main(String[] args){
        Elipse unaElipse = new Elipse(new Punto(1,2),2,3);
        Cuadrado unCuadrado = new Cuadrado(new Punto(3,7),2);
        Triangulo unTriangulo = new Triangulo(new Punto(2,5),4,6);
        Jardin unJardin = new Jardin("Bichito de luz");
        unJardin.agregarFigura(unCuadrado);
        unJardin.agregarFigura(unaElipse);
        unJardin.agregarFigura(unTriangulo);
        unJardin.detalleFiguras();
    }
}
