import java.util.ArrayList;
/**
*@author Gonzalez Ariel
*Clase Gerencia Tp 5.9
*/
public class Gerencia
{
    /**
    *Atributos de la Clase 
    */
    private String nombre;
    private ArrayList<Alojamiento> alojamientosAlquilados;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombre
    */
    public Gerencia(String p_nombre){
        this.setNombre(p_nombre);
        this.setAlojamientos(new ArrayList<Alojamiento>());
    }
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombre
    *@param ArrayList<Alojamiento> p_alojamientosAlquilados
    */
    public Gerencia(String p_nombre,ArrayList<Alojamiento> p_alojamientosAlquilados){
        this.setNombre(p_nombre);
        this.setAlojamientos(p_alojamientosAlquilados);
    }
    
    /**
    *Setter,recibe un String y permite modificar el valor de el atributo nombre
    *@param String p_nombre
    */
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    /**
    *Setter,recibe un int y permite modificar el valor de el atributo alojamientosAlquilados
    *@param ArrayList<Alojamiento> p_alojamientosAlquilados
    */
    private void setAlojamientos(ArrayList<Alojamiento> p_alojamientosAlquilados){
        this.alojamientosAlquilados = p_alojamientosAlquilados;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo alojamientosAlquilados
    *@return devuelve un ArrayList
    */
    public ArrayList<Alojamiento> getAlojamientosAlquilados(){
        return this.alojamientosAlquilados;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo nombre
    *@return devuelve un String
    */
    public String getNombre(){
        return this.nombre;
    }
    
    /**
     * Metodo publico, agrega un alojamiento a la lista
     * @return devuelve un boolean
    */
    public boolean agregarAlojamiento(Alojamiento p_alojamiento){
        return this.getAlojamientosAlquilados().add(p_alojamiento);
    }
    
    /**
     * Metodo publico, quita un alojamiento de la lista
     * @return devuelve un boolean
    */
    public boolean quitarAlojamiento(Alojamiento p_alojamiento){
        return this.getAlojamientosAlquilados().remove(p_alojamiento);
    }
    
    /**
     * Metodo publico, devuelve la cantidad de alojamientos
     * @param String p_tipoAlojamiento
     * @return devuelve un int
    */
    public int contarAlojamiento(String p_tipoAlojamiento){
        int cantAlojamientos = 0;
        for(Alojamiento unAlojamiento: this.getAlojamientosAlquilados()){
            cantAlojamientos += unAlojamiento.contar(p_tipoAlojamiento);
        }
        return cantAlojamientos;
    }
    
    /**
     * Metodo publico, muestra por pantalla los datos del alojamiento
    */
    public void liquidar(){
        for(Alojamiento unAlojamiento: this.getAlojamientosAlquilados()){
           unAlojamiento.liquidar();
           System.out.println("");
       }
    }
    
    /**
     * Metodo publico, muestra la liquidacion
    */
    public void mostrarLiquidacion(){
       System.out.println("Gerencia "+this.getNombre());
       System.out.println("Liquidacion--------------------");
       this.liquidar();
       System.out.println("Alojamiento tipo Cabaña ---->"+this.contarAlojamiento("Cabaña"));
       System.out.println("Alojamiento tipo Hotel ---->"+this.contarAlojamiento("Hotel"));
    }
}
