/**
*@author Gonzalez Ariel
*Clase CuentaBanco Tp 5.6
*/

public class CuentaBancaria
{
    /**
    *Atributos de la Clase 
    */
    private int nroCuenta;
    private double saldo;
    private Persona titular;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param int p_nroCuenta
    *@param Persona p_titular
    */
    public CuentaBancaria(int p_nroCuenta, Persona p_titular){
        this.setNroCuenta(p_nroCuenta);
        this.setTitular(p_titular);
        this.setSaldo(0);
    }
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param int p_nroCuenta
    *@param Persona p_titular
    *@param double p_saldo
    */
    public CuentaBancaria(int p_nroCuenta,Persona p_titular, double p_saldo){
        this.setNroCuenta(p_nroCuenta);
        this.setTitular(p_titular);
        this.setSaldo(p_saldo);
    }
    
    /**
    *Getter, retorna el valor del atributo nroCuenta
    *@return devuelve un entero
    */
    public int getNroCuenta(){
        return this.nroCuenta;
    }
    
    /**
    *Setter, recibe un int y permite modificar el valor del atributo nroCuenta
    *@param int p_nroCuenta
    */
    private void setNroCuenta(int p_nroCuenta){
        this.nroCuenta = p_nroCuenta;
    }
    
    /**
    *Getter, retorna el valor del atributo saldo
    *@return devuelve un double
    */
    public double getSaldo(){
        return this.saldo;
    }
    
    /**
    *Setter, recibe un double y permite modificar el valor del atributo saldo
    *@param double p_saldo
    */
    private void setSaldo(double p_saldo){
        this.saldo = p_saldo;
    }
    
    /**
    *Getter, retorna el valor del atributo titular
    *@return devuelve una Persona
    */
    public Persona getTitular(){
        return this.titular;
    }
    
    /**
    *Setter, recibe una Persona y permite modificar el valor del atributo titular
    *@param Persona p_titular
    */
    private void setTitular(Persona p_titular){
        this.titular = p_titular;
    }
    
    /**
     * Metodo publico, deposita el importe recibido por parametro
     * @param double p_importe
    */
    public void depositar(double p_importe){
        this.setSaldo(this.getSaldo() + p_importe);
    }

    /**
     * Metodo publico, extrae el importe recibido por parametro
     * @param double p_importe
     * @return devuelve un boolean
    */
    public boolean extraer(double p_importe){
        if(this.getSaldo() > p_importe){
            this.setSaldo(this.getSaldo() - p_importe);    
            return true;
        }
        return false;
    }
    
    /**
     * Metodo publico, muestra por pantalla los datos de la cuenta
    */
    public void mostrar(){
        System.out.println("Nro.Cuenta: "+this.getNroCuenta()+" - Saldo: "+this.getSaldo());
        System.out.println("Titular: "+this.getTitular().getNombre()+" "+this.getTitular().getApellido());
    }
}
