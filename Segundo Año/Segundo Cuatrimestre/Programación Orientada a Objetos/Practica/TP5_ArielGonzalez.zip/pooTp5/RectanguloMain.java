public class RectanguloMain
{
   public static void main(String[] args){
       Punto unPunto = new Punto(3,4);
       Cuadrado unCuadrado = new Cuadrado(unPunto,72.99);
       Rectangulo unRectangulo = new Rectangulo(unPunto,30,23);
       unRectangulo.caracteristicas();
       unCuadrado.caracteristicas();
   }
}
