/**
*@author Gonzalez Ariel
*Clase Circulo Tp 5.4
*/
public class Circulo extends Elipse
{
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param double p_radio
    *@param Punto p_centro
    */
    public Circulo(Punto p_centro,double p_radio){
        super(p_centro,p_radio,p_radio);
    }
    
    /**
     * Metodo publico, retorna una cadena con el nombre de la figura
     * @return devuelve un String
    */
    public String nombreFigura(){
        return "Circulo";
    }
    
    /**
    *Metodo publico,muestra por pantalla las caracteristicas de un Circulo
    */
    public void caracteristicas(){
        System.out.println("******"+this.nombreFigura()+"******");
        System.out.println("Centro: ("+super.getCentro().getX()+","+super.getCentro().getY()+")"+" - Radio: "+super.getEjeMayor());
        System.out.println("Superficie: "+super.superficie()+" -Perimetro: "+this.perimetro());
    }
    
    /**
    *Metodo publico,calcula el perimetro del circulo
    *@return devuelve un double
    */
   
    public double perimetro(){
        return (super.getEjeMayor() * Math.PI *  2);
    }
    
    /**
    *Metodo publico,muestra por pantalla la superficie de el circulo
    */
    public void mostrarSuperficie(){
        System.out.println("***"+this.nombreFigura()+"***");
        System.out.println("Superficie:"+this.perimetro());
    }
}
