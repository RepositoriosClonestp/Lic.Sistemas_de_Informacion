import java.util.*;
/**
*@author Gonzalez Ariel
*Clase Empleado 5.2
*/
public class Empleado extends Persona
{
    /**
     * Atributos de la clase
    */
    private long cuil;
    private double sueldoBasico;
    private Calendar fechaIngreso;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param double p_cuil
    *@param String p_apellido
    *@param String p_nombre
    *@param double p_importe
    *@param int p_anio
    */
    public Empleado(int p_dni,long p_cuil,String p_nombre,String p_apellido, double p_importe, int p_anio){
        super(p_dni,p_nombre,p_apellido,p_anio);
        this.setCuil(p_cuil);
        this.setSueldo(p_importe);
        this.setAnio(p_anio);
    }
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param double p_cuil
    *@param String p_apellido
    *@param String p_nombre
    *@param double p_importe
    *@param Calendar p_fecha
    */
    public Empleado(int p_dni,long p_cuil,String p_nombre,String p_apellido,double p_importe,Calendar p_fecha){
        super(p_dni,p_nombre,p_apellido,p_fecha);
        this.setCuil(p_cuil);
        this.setSueldo(p_importe);
    }
    
    /**
    *Setter,recibe un long por parametro y permite modificar el valor de el atributo cuil
    *@param long p_cuil
    */
    private void setCuil(long p_cuil){
        this.cuil = p_cuil;
    }
   
    /**
    *Setter,recibe un double por parametro y permite modificar el valor de el atributo sueldoBasico
    *@param double p_importe
    */
    private void setSueldo(double p_importe){
        this.sueldoBasico = p_importe;
    }
    
    /**
    *Setter,recibe un Calendar por parametro y permite modificar el valor de el atributo sueldoBasico
    *@param Calendar p_fecha
    */
    private void setFechaIngreso(Calendar p_fecha){
        this.fechaIngreso = p_fecha;
    }
    
    /**
    *Setter,recibe un int por parametro y permite modificar el valor de el atributo fechaIngreso
    *@param int p_anio
    */
    private void setAnio(int p_anio){
        Calendar fechaIngreso = Calendar.getInstance();
        fechaIngreso.set(p_anio,1,1);
        this.fechaIngreso = fechaIngreso;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo cuil
    *@return devuelve un long
    */
    public long getCuil(){
        return this.cuil;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo fechaIngreso
    *@return devuelve un Calendar
    */
    public Calendar getFechaIngreso(){
        return this.fechaIngreso;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo sueldoBasico
    *@return devuelve un double
    */
    public double getSueldo(){
        return this.sueldoBasico;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo fechaIngreso
    *@return devuelve un int
    */
    public int getAnio(){
        return this.fechaIngreso.get(Calendar.YEAR);
    }
    
    /**
    *Metodo publico, calcula la antiguedad del empleado
    */
    public int antiguedad(){
        Calendar añoHoy = new GregorianCalendar();
        return (añoHoy.get(Calendar.YEAR) - this.getAnio());
    }
    
    /**
    *Metodo privado, realiza un descuento al empleado
    */
    private double descuento(){
        double descuento;
        descuento = ((2 * this.getSueldo()) / 100) + 1500;
        return descuento;
    }
    
    /**
    *Metodo privado, se le paga un adicional al empleado con respecto a su antiguedad
    */
    private double adicional(){
        double adicional  = 0;
        if(antiguedad() < 2){
            adicional = ((2 * this.getSueldo()) / 100);
        }else if(antiguedad() >= 2 && antiguedad() < 10){
            adicional = ((4 * this.getSueldo()) / 100);
        }else if(antiguedad() >= 10){
            adicional = ((6 * this.getSueldo()) / 100);
        }
        return adicional;
    }
    
    /**
    *Metodo publico, calcula el sueldo neto del empleado
    */
    public double sueldoNeto(){
        double sueldoNeto;
        sueldoNeto = (this.getSueldo() + this.adicional()) - this.descuento();
        return sueldoNeto;
    }
    
    /**
    *Metodo publico, forma un cadena con el nombre y el apellido del empleado
    *@return devuelve un String
    */
    public String nomYApe(){
        return (""+this.getNombre()+" "+this.getApellido());
    }
    
    /**
    *Metodo publico, forma una cadena con el apellido y el nombre del empleado
    *@return devuelve un String
    */
    public String apeYNom(){
        return (""+this.getApellido()+" "+this.getNombre());
    }
    
    /**
    *Metodo publico, muestra por pantalla los datos del empleado
    */
    public void mostrar(){
        System.out.println("Nombre y Apellido: "+this.nomYApe());
        System.out.println("CUIL: "+this.getCuil()+" Antiguedad: "+this.antiguedad()+" años de servicio");
        System.out.println("Sueldo Neto: $"+this.sueldoNeto());
    }
    
    /**
    *Metodo publico, forma una cadena  con el cuil, apellido,nombre y sueldo del empleado
    *@return devuelve un String
    */
    public String mostrarLinea(){
        return (""+this.getCuil()+" "+this.getApellido()+", "+this.getNombre()+" ...............$"+this.sueldoNeto());
    }
    
    /**
     * Calcula si el dia actual es el aniversario de ingreso del empleado
     * @return devuelve un booleano
    */
    public boolean esAniversario(){
        Calendar fechaActual = new GregorianCalendar();
        int mesHoy = fechaActual.get(Calendar.MONTH)+1;
        int diaHoy = fechaActual.get(Calendar.DATE);
        
        int diaIngreso = this.getFechaIngreso().get(Calendar.DATE);
        int mesIngreso = this.getFechaIngreso().get(Calendar.MONTH);
        
        return ((diaIngreso == diaHoy) && (mesHoy == mesIngreso));
    }
}

