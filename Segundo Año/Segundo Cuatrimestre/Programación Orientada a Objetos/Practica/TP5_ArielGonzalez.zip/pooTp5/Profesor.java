import java.util.Calendar;
import java.util.ArrayList;
/**
*@author Gonzalez Ariel
*Clase Profesor Tp 5.5
*/
public class Profesor extends Persona
{
    /**
    *Atributos de la Clase 
    */
    private String titulo;
    private ArrayList<Cargo> cargos;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param int p_dni
    *@param String p_nombre
    *@param String p_apellido
    *@param int p_anio
    *@param String p_titulo
    *@param ArrayList<Cargo> p_cargos
    */
    public Profesor(int p_dni,String p_nombre,String p_apellido,int p_anio,String p_titulo,ArrayList<Cargo> p_cargos){
        super(p_dni,p_nombre,p_apellido,p_anio);
        this.setTitulo(p_titulo);
        this.setListaCargos(p_cargos);
    }
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param int p_dni
    *@param String p_nombre
    *@param String p_apellido
    *@param Calendar p_fecha
    *@param String p_titulo
    *@param ArrayList<Cargo> p_cargos
    */
    public Profesor(int p_dni,String p_nombre,String p_apellido,Calendar p_fecha,String p_titulo,ArrayList<Cargo> p_cargos){
        super(p_dni,p_nombre,p_apellido,p_fecha);
        this.setTitulo(p_titulo);
        this.setListaCargos(p_cargos);
    }
    
    /**
    *Setter,recibe un String y permite modificar el valor de el atributo titulo
    *@param String p_titulo
    */
    private void setTitulo(String p_titulo){
        this.titulo = p_titulo;
    }
    
    /**
    *Setter,recibe un ArrayList y permite modificar el valor de el atributo cargos
    *@param int p_cargos
    */
    private void setListaCargos(ArrayList<Cargo> p_cargos){
        this.cargos = p_cargos;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo cargos
    *@return devuelve un ArrayList
    */
    public ArrayList<Cargo> getListaCargos(){
        return this.cargos;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo titulo
    *@return devuelve un String
    */
    public String getTitulo(){
        return this.titulo;
    }
    
    /**
     * Metodo publico, permite agregar un cargo a la lista
     * @param Cargo p_cargo
     * @return devuelve un boolean
    */
    public boolean añadirCargo(Cargo p_cargo){
        if(this.getListaCargos().size() < 3){
            return this.getListaCargos().add(p_cargo);
        }else{
            return false;
        }
    }
    
    /**
     * Metodo publico, permite quitar un cargo a la lista
     * @param Cargo p_cargo
     * @return devuelve un boolean
    */
    public boolean quitarCargo(Cargo p_cargo){
        if(this.getListaCargos().size() > 1){
            return this.getListaCargos().remove(p_cargo);
        }else{
            return false;
        }
    }
    
    /**
     * Metodo publico,muestra por pantalla los datos del profesor
    */
    public void mostrar(){
        super.mostrar();
        System.out.println("Titulo: "+this.getTitulo());
        this.listarCargos();
        System.out.println("**Sueldo Total:"+this.sueldoTotal()+"**");
    }
    
    /**
     * Metodo publico,muestra por pantalla los datos de los cargos
    */
    public void listarCargos(){
        System.out.println("*****Cargos Asignados*****");
        for(Cargo unCargo: this.getListaCargos()){
            unCargo.mostrarCargo();
            System.out.println("");
        }
    }
    
    /**
     * Metodo publico,calcula el sueldo del profesor
     * @return devuelve un double
    */
    public double sueldoTotal(){
        double sueldoTotal = 0;
        for(Cargo unCargo: this.getListaCargos()){
            sueldoTotal += unCargo.sueldoDelCargo();
        }
        return sueldoTotal;
    }
    
    /**
     * Metodo publico,devuelve una cadena con los datos del profesor
     * @return devuelve un String
    */
    public String mostrarLinea(){
        return ("Dni:"+super.getDni()+" - Nombre: "+super.getNombre()+" "+super.getApellido()+" - Sueldo Total:"+this.sueldoTotal());
    }
}
