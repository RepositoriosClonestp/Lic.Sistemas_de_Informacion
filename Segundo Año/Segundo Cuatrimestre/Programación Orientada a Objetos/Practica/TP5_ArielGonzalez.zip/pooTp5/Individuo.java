import java.util.Calendar;
/**
*@author Gonzalez Ariel
*Clase Individuo Tp 5.10
*/
public class Individuo extends Visitante
{
    /**
    *Atributos de la Clase 
    */
    private Persona persona;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param Calendar p_fecha
    *@param Persona p_persona
    */
    public Individuo(Calendar p_fecha,Persona p_persona){
        super(p_persona.getNombre(),p_fecha);
        this.setPersona(p_persona);
    }
    
    /**
    *Setter,recibe una Persona y permite modificar el valor de el atributo persona
    *@param Persona p_persona
    */
    private void setPersona(Persona p_persona){
        this.persona = p_persona;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo persona
    *@return devuelve una Persona
    */
    public Persona getPersona(){
        return this.persona;
    }
    
    /**
    *Metodo publico,devuelve el valor de la entrada
    *@return devuelve un double
    */
    public double entrada(){
        return 10;
    }
    
    /**
     * Metodo publico, muestra por pantalla los datos de la persona
    */
    public void mostrar(){
        System.out.println("Nombre y Apellido: "+this.getPersona().getNombre()+" "+this.getPersona().getApellido());
        System.out.println("Dni: "+this.getPersona().getDni()+" Edad:"+this.getPersona().edad());
        System.out.println("");
    }
    
    /**
     * Metodo publico, Lista por fecha los visitantes
    */
    public void listarPorFecha(Calendar p_fecha, String p_visitante) {
        if (this.getFechaVisita().equals(p_fecha) && p_visitante == this.tipoVisitante()) {
            this.mostrar();
        } 
    }
    
    /**
     * Metodo publico,devuelve una cadena que indica que tipo de visitante es
     * @return devuelve un String
    */
    public String tipoVisitante(){
        return "Individuo";
    }
}
