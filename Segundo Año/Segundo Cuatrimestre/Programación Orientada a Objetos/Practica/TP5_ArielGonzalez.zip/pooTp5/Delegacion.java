import java.util.Calendar;
import java.util.ArrayList;
/**
*@author Gonzalez Ariel
*Clase Delegacion Tp 5.10
*/
public class Delegacion extends Visitante
{
    /**
    *Atributos de la Clase 
    */
    private ArrayList<Individuo> integrantes;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombre
    *@param Calendar p_fecha
    *@param ArrayList<Individuo> p_integrantes
    */
    public Delegacion(String p_nombre,Calendar p_fecha,ArrayList<Individuo> p_integrantes){
        super(p_nombre,p_fecha);
        this.setIntegrantes(p_integrantes);
    }
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombre
    *@param Calendar p_fecha
    *@param Individuo p_individuo
    */
    public Delegacion(String p_nombre,Calendar p_fecha,Individuo p_individuo){
        super(p_nombre,p_fecha);
        this.setIntegrantes(new ArrayList<Individuo>());
        this.inscribirIndividuo(p_individuo);
    }
    
    /**
    *Setter,recibe un ArrayList y permite modificar el valor de el atributo integrantes
    *@param ArrayList<Individuo> p_integrantes
    */
    private void setIntegrantes(ArrayList<Individuo> p_integrantes){
        this.integrantes = p_integrantes;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo integrantes
    *@return devuelve un ArrayList
    */
    public ArrayList<Individuo> getIntegrantes(){
        return this.integrantes;
    }
    
    /**
     * Metodo publico, permite agregar un individuo a la lista de individuo
     * @param Individuo p_individuo
    */
    public boolean agregarIndividuo(Individuo p_individuo){
        return this.getIntegrantes().add(p_individuo);
    }
    
    /**
     * Metodo publico, permite quitar un individuo a la lista de individuo
     * @param Individuo p_individuo
    */
    public boolean quitarIntegrante(Individuo p_individuo){
        if(this.cantidadDeIntegrantes() > 1){
            return this.getIntegrantes().remove(p_individuo);
        }
        return false;
    }
    
    /**
     * Metodo publico, devuelve la cantidad de integrantes
     * @return devuelve un int
    */
    public int cantidadDeIntegrantes(){
        return this.getIntegrantes().size();
    }
    
    /**
     * Metodo publico, calcula el valor de la entrada
     * @return devuelve un double
    */
    public double entrada(){
        double totalEntrada = 0;
        for(Individuo unIntegrante: this.getIntegrantes()){
            totalEntrada += unIntegrante.entrada();
        }
        double totalConDescuento = (totalEntrada  - ((totalEntrada * 10) / 100));
        return totalConDescuento;
    }
    
    /**
     * Metodo publico, inscribe un individuo a la delegacion
    */
    public void inscribirIndividuo(Individuo p_individuo){
        if(agregarIndividuo(p_individuo)){
            System.out.println("Se inscribio un nuevo integrante");
        }
    }
    
    /**
     * Metodo publico, muestra por pantalla los datos de la delegacion
    */
    public void mostrar(){
        System.out.println("----------------------------------------");
        System.out.println("Delegacion:"+super.getNombre());
        for(Individuo unIntegrante : this.getIntegrantes()){
            unIntegrante.mostrar();
        }
        System.out.println("Cantidad de integrantes:"+this.cantidadDeIntegrantes());
        System.out.println("----------------------------------------");
    }
    
    /**
     * Metodo publico, lista por fecha los datos de la delegacion
    */
    public void listarPorFecha(Calendar p_fecha, String p_visitante) { 
        if (this.getFechaVisita().equals(p_fecha) && p_visitante == this.tipoVisitante()) { 
            this.mostrar();
        }   
    }
    
    /**
     * Metodo publico,devuelve una cadena indicando que tipo de visitante es
     * @return devuelve un String
    */
    public String tipoVisitante(){
        return "Delegacion";
    }
}
