/**
*@author Gonzalez Ariel
*Clase Servicio Tp 5.9
*/
public class Servicio
{
    /**
    *Atributos de la Clase 
    */
    private String descripcion;
    private double precio;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_descripcion
    *@param double p_precio
    */
    public Servicio(String p_descripcion,double p_precio){
        this.setDescripcion(p_descripcion);
        this.setPrecio(p_precio);
    }
    
    /**
    *Setter,recibe un String y permite modificar el valor de el atributo descripcion
    *@param String p_descripcion
    */
    private void setDescripcion(String p_descripcion){
        this.descripcion = p_descripcion;
    }
    
    /**
    *Setter,recibe un double y permite modificar el valor de el atributo precio
    *@param double p_precio
    */
    private void setPrecio(double p_precio){
        this.precio = p_precio;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo descripcion
    *@return devuelve un String
    */
    public String getDescripcion(){
        return this.descripcion;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo precio
    *@return devuelve un double
    */
    public double getPrecio(){
        return this.precio;
    }
}
