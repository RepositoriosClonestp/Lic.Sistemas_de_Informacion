import java.util.Calendar;
import java.util.Scanner;
public class VendeEntrada
{
    public static void main(String[] args){
        Scanner leer = new Scanner(System.in);
        Zoologico unZoologico = new Zoologico("El Caribú");
        
        Calendar fechaDelegacion = Calendar.getInstance();
        fechaDelegacion.set(2016,Calendar.SEPTEMBER, 22); 
        
        Calendar diaVisita = Calendar.getInstance();
        diaVisita.set(2016,Calendar.SEPTEMBER,22);
        
        Persona unaPersona = new Persona(44542230, "Alexis", "Olivarez", 2002);
        Persona otraPersona = new Persona(45436643, "Axel", "Vega", 2003);
        
        Delegacion pami = new Delegacion("PAMI", fechaDelegacion, new Individuo(fechaDelegacion,unaPersona));
        pami.inscribirIndividuo(new Individuo(fechaDelegacion,otraPersona));
        
        int opcion = 0;
        do{
            System.out.println("Ingrese la opcion que desea realizar");
            System.out.println("1-Inscribir un visitante, 2-Inscribir una delegacion,3-Listar visitantes del dia 22/09,4-Listar por delegacion,5-Recaudacion");
            opcion = leer.nextInt();
            switch(opcion){
                case 1:
                    Calendar fechaNacimiento = Calendar.getInstance();
                    System.out.println("Ingrese el nro de dni:");
                    int dni = leer.nextInt();
                    System.out.println("Ingrese el nombre del visitante:");
                    String nombre = leer.next();
                    System.out.println("Ingrese el apellido del visitante:");
                    String apellido = leer.next();
                    System.out.println("Ingrese el año de nacimiento:");
                    int anio = leer.nextInt();
                    System.out.println("Ingrese el mes de nacimiento:");
                    int mes = leer.nextInt();
                    System.out.println("Ingrese el dia de nacimiento:");
                    int dia = leer.nextInt();
                    fechaNacimiento.set(anio,mes,dia);
                    Individuo unIndividuo = new Individuo(diaVisita,new Persona(dni,nombre,apellido,fechaNacimiento));
                    unZoologico.nuevoVisitante(unIndividuo);
                    break;
                case 2:
                    unZoologico.nuevoVisitante(pami);
                    break;
                case 3:
                    unZoologico.listaVisitantePorFecha(diaVisita);
                    break;
                case 4:
                    unZoologico.listaTipoVisitante(diaVisita,"Delegacion");
                    break;
                case 5:
                    System.out.println("Recaudación desde 1/9/2016 hasta 30/9/2016");
                    // * Fecha Desde para saber lo recaudado...
                    Calendar fechaDesde = Calendar.getInstance();
                    fechaDesde.set(2016, Calendar.SEPTEMBER, 1);
                    // * Fecha Hasta para saber lo recaudado...
                    Calendar fechaHasta = Calendar.getInstance();
                    fechaHasta.set(2016, Calendar.SEPTEMBER, 30);
                    System.out.println("Recaudacion: $"+unZoologico.recaudacion(fechaDesde,fechaHasta));
                    break;
            }
        }while(opcion != 0);
    }
}
