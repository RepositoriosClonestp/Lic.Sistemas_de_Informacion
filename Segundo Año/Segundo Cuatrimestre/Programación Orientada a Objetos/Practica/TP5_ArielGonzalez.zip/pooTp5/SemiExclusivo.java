/**
*@author Gonzalez Ariel
*Clase SemiExclusivo Tp 5.5
*/
public class SemiExclusivo extends Cargo
{
    /**
    *Atributos de la Clase 
    */
    private int horasDeInvestigacion;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombreCargo
    *@param double p_importe
    *@param int p_anio
    *@param int p_horasDocencia
    *@param int p_horasInvestigacion
    */
    public SemiExclusivo(String p_nombreCargo,double p_importe,int p_anio,int p_horasDocencia,int p_horasInvestigacion){
        super(p_nombreCargo,p_importe,p_anio,p_horasDocencia);
        this.setHorasInvestigacion(p_horasInvestigacion);
    }
    
    /**
    *Setter,recibe un int y permite modificar el valor de el atributo horasDeInvestigacion
    *@param int p_horasInvestigacion
    */
    private void setHorasInvestigacion(int p_horasInvestigacion){
        this.horasDeInvestigacion = p_horasInvestigacion;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo horasDeInvestigacion
    *@return devuelve un int
    */
    public int getHorasDeInvestigacion(){
        return this.horasDeInvestigacion;
    }
    
    /**
     * Metodo Publico,muestra por pantalla los datos del cargo
    */
    public void mostrarCargo(){
        super.mostrarCargo();
        System.out.println("----Cargo de caracter SemiExclusivo----");
        System.out.println("Horas de Investigacion: "+this.getHorasDeInvestigacion());
    }
}
