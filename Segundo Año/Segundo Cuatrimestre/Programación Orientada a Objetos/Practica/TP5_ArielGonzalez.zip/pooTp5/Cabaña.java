import java.util.ArrayList;
/**
*@author Gonzalez Ariel
*Clase Cabaña Tp 5.9
*/
public class Cabaña extends Alojamiento
{
    /**
    *Atributos de la Clase 
    */
    public int nroHabitaciones;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombre
    *@param double p_precioBase
    *@param int p_diasAlquiler
    *@param ArrayList<Cargo> p_servicos
    *@param int p_nroHabitaciones
    */
    public Cabaña(String p_nombre,double p_precioBase,int p_diasAlquiler,ArrayList<Servicio> p_servicios,int p_nroHabitaciones){
        super(p_nombre,p_precioBase,p_diasAlquiler,p_servicios);
        this.setNroHabitaciones(p_nroHabitaciones);
    }
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombre
    *@param double p_precioBase
    *@param int p_diasAlquiler
    *@param int p_nroHabitaciones
    */
    public Cabaña(String p_nombre,double p_precioBase,int p_diasAlquiler,int p_nroHabitaciones){
        super(p_nombre,p_precioBase,p_diasAlquiler);
        this.setNroHabitaciones(p_nroHabitaciones);
    }
    
    /**
     * Metodo publico, agrega un servicio a la lista
     * @return devuelve un boolean
    */
    public boolean agregarServicio(Servicio p_servicio){
        return super.agregarServicio(p_servicio);
    }
    
    /**
     * Metodo publico, quita un servicio de la lista
     * @return devuelve un boolean
    */
    public boolean quitarServicio(Servicio p_servicio){
        return super.quitarServicio(p_servicio);
    }
    
    /**
    *Setter,recibe un int y permite modificar el valor de el atributo nroHabitaciones
    *@param int p_nroHabitaciones
    */
    private void setNroHabitaciones(int p_nroHabitaciones){
        this.nroHabitaciones = p_nroHabitaciones;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo nroHabitaciones
    *@return devuelve un int
    */
    public int getNroHabitaciones(){
        return this.nroHabitaciones;
    }
    
    /**
     * Metodo publico,calcula el costo del alquiler
    */
    public double costo(){
        return (super.costo() + (super.getDiasAlquiler() * this.getNroHabitaciones() * 30));
    }
    
    /**
     * Metodo publico,cuenta la cantidad de cabañas
    */
    public int contar(String p_alojamiento){
        if(p_alojamiento.contains("Cabaña")){
            return 1;
        }
        return 0;
    }
    
    /**
     * Metodo publico,muestra por pantalla los datos de la cabaña
    */
    public void liquidar(){
        super.liquidar();
        System.out.println("Cabaña con "+this.getNroHabitaciones()+" habitaciones");
        System.out.println("Total: ------>$"+(super.costoServicios() + this.costo()));
    }
}