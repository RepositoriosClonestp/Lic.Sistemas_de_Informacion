import java.util.ArrayList;
public class AdministracionGerencia
{
    public static void main(String[] args){
        Servicio servicioInternet = new Servicio("Internet",5);
        Servicio servicioAlquilerAuto = new Servicio("Alquiler Auto",100);
        Servicio servicioLavanderia = new Servicio("Lavanderia",20);
        ArrayList<Servicio> listaServicios = new ArrayList();
        
        listaServicios.add(servicioInternet);
        listaServicios.add(servicioAlquilerAuto);
        
        ArrayList<Servicio> listaServicios2 = new ArrayList();
        
        listaServicios2.add(servicioAlquilerAuto);
        listaServicios2.add(servicioLavanderia);
        
        Hotel unHotel = new Hotel("Hotel Guarani",70,7,listaServicios,"Single");
        
        Cabaña unaCabaña = new Cabaña("Cabañas La Alondra",120,5,listaServicios2,3);
        ArrayList<Alojamiento> listaAlojamientos = new ArrayList();
        listaAlojamientos.add(unHotel);
        listaAlojamientos.add(unaCabaña);
        Gerencia unaGerencia = new Gerencia("Los Arroyos",listaAlojamientos);
        unaGerencia.mostrarLiquidacion();
    }
}
