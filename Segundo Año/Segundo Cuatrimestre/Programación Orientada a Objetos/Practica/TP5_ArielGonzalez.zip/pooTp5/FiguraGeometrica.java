/**
*@author Gonzalez Ariel
*Clase FiguraGeometrica Tp 5.7
*/
public abstract class FiguraGeometrica
{
    /**
    *Atributos de la Clase 
    */
    private Punto origen;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param Punto p_origen
    */
    public FiguraGeometrica(Punto p_origen){
        this.setOrigen(p_origen);
    }
    
    /**
    *Setter,recibe un Punto y permite modificar el valor de el atributo origen
    *@param Punto p_origen
    */
    private void setOrigen(Punto p_origen){
        this.origen = p_origen;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo origen
    *@return devuelve un Punto
    */
    public Punto getCentro(){
        return this.origen;
    }
    
    /**
     * Metodos Abstractos
    */
    public abstract String nombreFigura();
    public abstract double superficie();
    
    public  void mostrarSuperficie(){
        
    }
}
