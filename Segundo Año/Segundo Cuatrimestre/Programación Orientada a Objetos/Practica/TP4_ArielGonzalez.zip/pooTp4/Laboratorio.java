/**
*@author Gonzalez Ariel
*Clase Laboratorio Tp 4.2
*/
public class Laboratorio
{
    /**
    *Atributos de la Clase 
    */
    private String nombre;
    private String domicilio;
    private String telefono;
    private int compraMinima;
    private int diaEntrega;
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombre
    *@param String p_domicilio
    *@param String p_telefono
    *@param int p_compraMin
    *@param int p_diaEnt
    */
    public Laboratorio(String p_nombre,String p_domicilio,String p_telefono,int p_compraMin,int p_diaEnt){
        this.setNombre(p_nombre);
        this.setDomicilio(p_domicilio);
        this.setTelefono(p_telefono);
        this.setCompraMin(p_compraMin);
        this.setDiaEntrega(p_diaEnt);
    }
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombre
    *@param String p_domicilio
    *@param String p_telefono
    */
    public Laboratorio(String p_nombre,String p_domicilio,String p_telefono){
        this.setNombre(p_nombre);
        this.setDomicilio(p_domicilio);
        this.setTelefono(p_telefono);
        this.setCompraMin(0);
        this.setDiaEntrega(0);
    }
    
    /**
    *Setter,recibe un String y permite modificar el valor de el atributo nombre
    *@param String p_nombre
    */
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    /**
    *Setter,recibe un String y permite modificar el valor de el atributo domicilio
    *@param String p_domicilio
    */
    private void setDomicilio(String p_domicilio){
        this.domicilio = p_domicilio;
    }
    
    /**
    *Setter,recibe un String y permite modificar el valor de el atributo telefono
    *@param String p_telefono
    */
    private void setTelefono(String p_telefono){
        this.telefono = p_telefono;
    }
    
    /**
    *Setter,recibe un entero y permite modificar el valor de el atributo compraMinima
    *@param int p_compraMin
    */
    private void setCompraMin(int p_compraMin){
        this.compraMinima = p_compraMin;
    }
    
    /**
    *Setter,recibe un entero y permite modificar el valor de el atributo diaEntrega
    *@param int p_diaEnt
    */
    private void setDiaEntrega(int p_diaEnt){
        this.diaEntrega = p_diaEnt;
    }
    
    /**
    *Getter,permite obtener el valor de el atributo nombre
    *@return devuelve un String
    */
    public String getNombre(){
        return this.nombre;
    }
    
    /**
    *Getter,permite obtener el valor de el atributo domicilio
    *@return devuelve un String
    */
    public String getDomicilio(){
        return this.domicilio;
    }
    
    /**
    *Getter,permite obtener el valor de el atributo telefono
    *@return devuelve un String
    */
    public String getTelefono(){
        return this.telefono;
    }
    
    /**
    *Getter,permite obtener el valor de el atributo compraMinima
    *@return devuelve un valor entero
    */
    public int getCompraMin(){
        return this.compraMinima;
    }
    
    /**
    *Getter,permite obtener el valor de el atributo diaEntrega
    *@return devuelve un valor entero
    */
    public int getDiaEntrega(){
        return this.diaEntrega;
    }
    
    /**
    *Metodo publico,recibe por parametro un entero y crea una nueva compra minima
    *@param int p_compraMin
    */
    public void nuevaCompraMinima(int p_compraMin){
        this.setCompraMin(p_compraMin);
    }
    
    /**
    *Metodo publico,recibe por parametro un entero y crea un nuevo dia de entrega
    *@param int p_diaEnt
    */
    public void nuevoDiaEntrega(int p_diaEnt){
        this.setDiaEntrega(p_diaEnt);
    }
    
    /**
    *Metodo publico,forma una cadena con los datos del laboratorio
    *@return devuelve un String
    */
    public String mostrar(){
        return("Laboratorio: "+this.getNombre()+"\n"+"Domicilio: "+this.getDomicilio()+" - Telefono: "+this.getTelefono());
    }
}
