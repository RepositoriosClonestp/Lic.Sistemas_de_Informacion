import java.util.Scanner;

public class ArrayDePuntos
{
    public static void main(String[] args){
        Punto[] puntos = new Punto[6];
        Scanner leer = new Scanner(System.in);
        
        for(int i = 0; i < 6;i++){
            System.out.println("Ingrese la coordenada x: ");
            double x = leer.nextDouble();
            System.out.println("Ingrese la coordenada y: ");
            double y = leer.nextDouble();
            puntos[i] = new Punto(x,y);
        }
        
        for(int i = 0; i < 6;i++){
            System.out.println(puntos[i].coordenadas());
        }
        
        for(int i = 1; i < 6;i++){
            System.out.println("Distancia Pto "+i+" - Punto "+(i+1)+":"+puntos[i].distanciaA(puntos[i-1]));
        }
    }
}
