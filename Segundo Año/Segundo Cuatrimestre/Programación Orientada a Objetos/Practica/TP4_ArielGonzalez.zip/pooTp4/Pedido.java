import java.util.ArrayList;
import java.util.Calendar;
/**
*@author Gonzalez Ariel
*Clase Pedido Tp 4.2
*/
public class Pedido
{
    /**Atributos de la clase*/
    private Cliente cliente;
    private ArrayList<Producto> productos;
    private Calendar fecha;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param Calendar p_fecha
    *@param Cliente p_cliente
    *@param ArrayList<Producto> p_productos
    */
    public Pedido(Calendar p_fecha, Cliente p_cliente, ArrayList<Producto> p_productos){
        this.setFecha(p_fecha);
        this.setCliente(p_cliente);
        this.setProductos(p_productos);
    }
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param Calendar p_fecha
    *@param Cliente p_cliente
    *@param Producto p_producto
    */
    public Pedido(Calendar p_fecha, Cliente p_cliente,Producto p_producto){
        this.setFecha(p_fecha);
        this.setCliente(p_cliente);
        this.setProductos(new ArrayList());
        this.agregarProducto(p_producto);
    }
    
    /**
    *Setter,recibe un Calendar por parametro y permite modificar el valor de el atributo fecha
    *@param Calendar p_fecha
    */
    private void setFecha(Calendar p_fecha){
        this.fecha = p_fecha;
    }
    
    /**
    *Setter,recibe un Cliente por parametro y permite modificar el valor de el atributo cliente
    *@param Cliente p_cliente
    */
    private void setCliente(Cliente p_cliente){
        this.cliente = p_cliente;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo cliente
    *@return devuelve un Cliente
    */
    public Cliente getCLientes(){
        return this.cliente;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo fecha
    *@return devuelve un Calendar
    */
    public Calendar getFecha(){
        return this.fecha;
    }
    
    /**
    *Setter,recibe un ArrayList por parametro y permite modificar el valor de el atributo productos
    *@param ArrayList<Producto> p_productos
    */
    private void setProductos(ArrayList<Producto> p_productos){
        this.productos = p_productos;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo productos
    *@return devuelve un ArrayList<Producto>
    */
    public ArrayList<Producto> getProductos(){
        return this.productos;
    }
    
    /**
     * Metodo publico, devuelve el valor total de todos los productos al contado
     * @return devuelve un double
    */
    public double totalAlContado(){
        double totalContado = 0;
        for(Producto unProducto: this.getProductos()){
            totalContado += unProducto.precioContado();
        }
        return totalContado;
    }
    
    /**
     * Metodo publico, devuelve el valor total de todos los productos con precio lista
     * @return devuelve un double
    */
    public double totalFinanciado(){
        double totalFinanciado = 0;
        for(Producto unProducto: this.getProductos()){
            totalFinanciado += unProducto.precioLista();
        }
        return totalFinanciado;
    }
    
    /**
     * Metodo publico, agrega un producto a la lista
     * @param Producto p_producto
     * @return devuelve un boolean
    */
    public boolean agregarProducto(Producto p_producto){
        return this.getProductos().add(p_producto);
    }
    
    /**
     * Metodo publico, quita un producto a la lista
     * @param Producto p_producto
     * @return devuelve un boolean
    */
    public boolean quitarProducto(Producto p_producto){
        if(this.getProductos().size() > 1){
            return this.getProductos().remove(p_producto);    
        }else{
            return false;
        }
    }
    
    /**
     * Muestra por pantalla el detalle del pedido
    */
    public void mostrarPedido(){
        String [] meses ={"enero","febrero","marzo","abril","mayo","junio","julio",
        "agosto","septiembre","octubre","noviembre","diciembre"};
        System.out.print("******Detalle del pedido******");
        System.out.println("Fecha: "+this.getFecha().get(Calendar.DATE)+" de "+meses[this.getFecha().get(Calendar.MONTH)]+" "+this.getFecha().get(Calendar.YEAR));
        System.out.println("--------------------------------------------------------------------");
        System.out.println("Producto  Precio Lista   Precio Contado");
        for(Producto unProducto: this.getProductos()){
            System.out.println(unProducto.mostrarLinea());
        }
        System.out.println("--------------------------------------------------------------------");
        System.out.println("**** Total------"+this.totalFinanciado()+"  "+this.totalAlContado());
    }
}
