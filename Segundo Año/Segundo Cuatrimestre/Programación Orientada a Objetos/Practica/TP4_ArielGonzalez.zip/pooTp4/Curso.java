import java.util.HashMap;
/**
*@author Gonzalez Ariel
*Clase Curso 4.5
*/
public class Curso
{
    /**
     * Atributos de la clase
    */
    private String nombre;
    private HashMap<Integer,Alumno> alumnos;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombre
    */
    public Curso(String p_nombre){
        this.setNombre(p_nombre);
        this.setAlumnos(new HashMap<Integer,Alumno>());
    }
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombre
    *@param HashMap p_alumnos
    */
    public Curso(String p_nombre,HashMap p_alumnos){
        this.setNombre(p_nombre);
        this.setAlumnos(p_alumnos);
    }
    
    /**
    *Setter,recibe un String por parametro y permite modificar el valor de el atributo nombre
    *@param String p_nombre
    */
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    /**
    *Setter,recibe un HashMap por parametro y permite modificar el valor de el atributo alumnos
    *@param Hashmap<Integer,Alumno> p_alumnos
    */
    private void setAlumnos(HashMap<Integer,Alumno> p_alumnos){
        this.alumnos = p_alumnos;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo alumnos
    *@return devuelve un HashMap
    */
    public HashMap<Integer,Alumno> getAlumnos(){
        return this.alumnos;
    }
    
    /**
     * Metodo publico, agrega un alumno a la lista de alumnos
     * @param Alumno p_alumno
    */
    public void inscribirAlumno(Alumno p_alumno){
        this.getAlumnos().put(new Integer(p_alumno.getLu()),p_alumno);
    }
    
    /**
     * Metodo publico, quita un alumno de la lista de alumnos
     * @param int p_lu
     * @return devuelve un Alumno
    */
    public Alumno quitarAlumno(int p_lu){
        return (Alumno) this.getAlumnos().remove(new Integer(p_lu));
    }
    
    /**
     * Metodo publico, devuelve la cantidad de alumnos
     * @return devuelve un entero
    */
    public int cantidadDeAlumnos(){
        return this.getAlumnos().size();
    }
    
    /**
     * Metodo publico, averigua si un alumno esta inscripto
     * @param int p_lu
     * @return devuelve un boolean
    */
    public boolean estaInscripto(int p_lu){
        return this.getAlumnos().containsKey(p_lu);
    }
    
    /**
     * Metodo publico, averigua si un alumno esta inscripto
     * @param Alumno p_alumno
     * @return devuelve un boolean
    */
    public boolean estaInscripto(Alumno p_alumno){
        return this.getAlumnos().containsValue(p_alumno);
    }
    
    /**
     * Metodo publico, busca un alumno
     * @param int p_lu
     * @return devuelve un Alumno
    */
    public Alumno buscarAlumno(int p_lu){
        return (Alumno)this.getAlumnos().get(new Integer(p_lu));
    }
    
    /**
     * Metodo publico, imprime el promedio del alumno
     * @param int p_lu
    */
    public void imprimirPromedioDelAlumno(int p_lu){
        if(this.estaInscripto(p_lu) == true){
            System.out.println("****--Promedio del alumno:"+p_lu+"--****");
            System.out.println("Promedio:"+this.buscarAlumno(p_lu).promedio());
        }else{
            System.out.println("El alumno no esta inscripto");
        }
    }
    
    /**
     * Muestra por pantalla los datos de los alumnos inscriptos
    */
    public void mostrarInscriptos(){
        System.out.println("****--Alumnos inscriptos actualmente "+this.cantidadDeAlumnos()+"--****");
        if(this.cantidadDeAlumnos() > 0){
            for(Alumno alumno: this.getAlumnos().values()){
                System.out.println(""+alumno.getLu()+" "+alumno.getNombre()+" "+alumno.getApellido());
            }
        }else{
            System.out.println("No hay alumnos inscriptos a este curso");
        }
    }
}
