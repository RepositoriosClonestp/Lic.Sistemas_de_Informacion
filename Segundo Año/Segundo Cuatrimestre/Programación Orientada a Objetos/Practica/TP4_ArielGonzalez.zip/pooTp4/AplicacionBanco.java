import java.util.Scanner;
import java.util.Calendar;

public class AplicacionBanco
{
   public static void main(String[] args){
       Calendar fechaIngreso = Calendar.getInstance();
       fechaIngreso.set(2000,1,1);
       Calendar fechaNacimiento = Calendar.getInstance();
       fechaNacimiento.set(2000,10,5);
       
       Scanner leer = new Scanner(System.in);
       Localidad unaLocalidad = new Localidad("Bella Vista","Corrientes");
       Empleado unEmpleado = new Empleado(2335553L,"Perez","Lorena",20000,fechaIngreso);
       Banco unBanco = new Banco("Rio",unaLocalidad,3,unEmpleado);
       
       Persona titular = new Persona(42736725,"Ariel","Gonzalez",fechaNacimiento);
       Persona otroTitular = new Persona(12346725,"Pablo","Lezcano",fechaNacimiento);
       Persona otraTitular = new Persona(13686725,"Mica","Viciconte",fechaNacimiento);
       
       CuentaBancaria unaCuentaBancaria = new CuentaBancaria(1,titular,300000);
       CuentaBancaria otraCuentaBancaria = new CuentaBancaria(2,otroTitular,0);
       CuentaBancaria otraMasCuentaBancaria = new CuentaBancaria(3,otraTitular,230000);
       int opcion = 0;
       
       do{
           System.out.println("1-Contratar Empleado, 2-Despedir Empleado,3-Listar Sueldos,4-Agregar Cuentas,5-Resumen Cuentas,6-Quitar Cuenta");
           System.out.println("Ingrese una opcion: ");
           opcion = Integer.parseInt(leer.next());
           
           switch(opcion){
               case 1:
                   System.out.println("Ingrese el nombre:");
                   String nombre = leer.next();
                   System.out.println("Ingrese el apellido:");
                   String apellido = leer.next();
                   System.out.println("Ingrese el sueldo:");
                   double sueldo = Double.parseDouble(leer.next());
                   System.out.println("Ingrese el cuil:");
                   long cuil = leer.nextInt();
                   unBanco.agregarEmpleado(new Empleado(cuil,apellido,nombre,sueldo,fechaIngreso = Calendar.getInstance()));
                   break;
               case 2:
                   System.out.println("Ingrese el cuil del empleado a despedir:");
                   long cuilEmpleado = leer.nextInt();
                   for(int i = 0; i < unBanco.getEmpleados().size();i++){
                       if(unBanco.getEmpleados().get(i).getCuil() == cuilEmpleado){
                           unBanco.quitarEmpleado(unBanco.getEmpleados().get(i));
                       }
                   }
                   break;
               case 3:
                   unBanco.mostrar();
                   unBanco.listarSueldos();
                   break;
               case 4:
                   unBanco.agregarCuentaBancaria(unaCuentaBancaria);
                   unBanco.agregarCuentaBancaria(otraCuentaBancaria);
                   unBanco.agregarCuentaBancaria(otraMasCuentaBancaria);
                   break;
               case 5:
                   unBanco.mostrarResumen();
                   break;
               case 6:
                   System.out.println("Ingrese el nro de cuenta:");
                   int nroCuenta = leer.nextInt();
                   for(int i = 0;i< unBanco.getCuentasBancarias().size();i++){
                       if(unBanco.getCuentasBancarias().get(i).getNroCuenta() == nroCuenta){
                           unBanco.quitarCuentaBancaria(unBanco.getCuentasBancarias().get(i));
                       }
                   }
                   break;
           }
       }while(opcion !=0);
   }
}
