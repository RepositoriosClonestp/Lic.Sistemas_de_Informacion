import java.util.Scanner;

public class Carrera
{
    public static void main(String[] args){
        Scanner leer = new Scanner(System.in);
        Curso unCurso = new Curso("Diseño Grafico");
        int opcion = 0;
        
        do{
            System.out.println("1-Inscribir alumno,2-Dar de baja alumno,3-Ingresar notas de los alumnos,4-Alumnos inscriptos");
            System.out.println("5-Buscar alumno por Lu,6-Promedio de alumno");
            System.out.println("Ingrese una opcion: ");
            opcion = leer.nextInt();
            switch(opcion){
                case 1:
                    System.out.println("Ingrese el nombre del alumno:");
                    String nombre = leer.next();
                    System.out.println("Ingrese el apellido del alumno:");
                    String apellido = leer.next();
                    System.out.println("Ingrese la Lu del alumno:");
                    int lu = leer.nextInt();
                    unCurso.inscribirAlumno(new Alumno(lu,nombre,apellido));
                    break;
                case 2:
                    System.out.println("Ingrese la Lu del alumno que se va a dar de baja: ");
                    int numLuDarBaja = leer.nextInt();
                    unCurso.quitarAlumno(numLuDarBaja);
                    break;
                case 3:
                    System.out.println("Ingrese la lu del alumno para ingresar sus notas: ");
                    int alumBusc = leer.nextInt();
                    System.out.println("Ingrese la nota: ");
                    double nota1 = (double) leer.nextInt();
                    unCurso.buscarAlumno(alumBusc).setNota1(nota1);
                    
                    System.out.println("Ingrese la 2da nota: ");
                    double nota2 = (double)leer.nextInt();
                    unCurso.buscarAlumno(alumBusc).setNota2(nota2);
                    break;
                case 4:
                    unCurso.mostrarInscriptos();
                    break;
                case 5:
                    System.out.println("Ingrese la Lu del alumno: ");
                    unCurso.buscarAlumno(leer.nextInt()).mostrar();
                    break;
                case 6:
                    System.out.println("Ingrese la Lu del alumno para ver su promedio: ");
                    unCurso.imprimirPromedioDelAlumno(leer.nextInt());
                    break;
            }
        }while(opcion != 0);
    }
}
