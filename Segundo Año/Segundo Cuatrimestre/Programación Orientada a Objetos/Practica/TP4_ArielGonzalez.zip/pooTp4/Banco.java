import java.util.ArrayList;
/**
*@author Gonzalez Ariel
*Clase Banco Tp 4.4
*/
public class Banco
{
    /**
    *Atributos de la Clase 
    */
    private String nombre;
    private int nroSucursal;
    private ArrayList<Empleado> empleados;
    private ArrayList<CuentaBancaria> cuentasBancarias;
    private Localidad localidad;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombre
    *@param Localidad p_localidad
    *@param int p_nroSucursal
    *@param Empleado p_empleado
    */
    public Banco(String p_nombre,Localidad p_localidad,int p_nroSucursal,Empleado p_empleado){
        this.setNombre(p_nombre);
        this.setLocalidad(p_localidad);
        this.setSucursal(p_nroSucursal);
        this.setEmpleados(new ArrayList());
        this.setCuentaBancaria(new ArrayList());
        this.agregarEmpleado(p_empleado);
    }
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombre
    *@param Localidad p_localidad
    *@param int p_nroSucursal
    *@param ArrayList<Empleado> p_empleado
    */
    public Banco(String p_nombre,Localidad p_localidad, int p_nroSucursal,ArrayList<Empleado> p_empleados){
        this.setNombre(p_nombre);
        this.setLocalidad(p_localidad);
        this.setSucursal(p_nroSucursal);
        this.setEmpleados(p_empleados);
        this.setCuentaBancaria(new ArrayList());
    }
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param String p_nombre
    *@param Localidad p_localidad
    *@param int p_nroSucursal
    *@param ArrayList<Empleado> p_empleado
    *@param ArrayList<CuentaBancaria> p_cuentas
    */
    public Banco(String p_nombre,Localidad p_localidad, int p_nroSucursal,ArrayList<Empleado> p_empleados,ArrayList<CuentaBancaria> p_cuentas){
        this.setNombre(p_nombre);
        this.setLocalidad(p_localidad);
        this.setSucursal(p_nroSucursal);
        this.setCuentaBancaria(p_cuentas);
        this.setEmpleados(p_empleados);
    }
    
    /**
    *Setter,recibe un ArrayList<CuentaBancaria> y permite modificar el valor de el atributo cuentasBancarias
    *@param ArrayList<CuentaBancaria> p_cuentas
    */
    private void setCuentaBancaria(ArrayList<CuentaBancaria> p_cuentas){
        this.cuentasBancarias = p_cuentas;
    }
    
    /**
    *Setter,recibe un String y permite modificar el valor de el atributo nombre
    *@param String p_nombre
    */
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    /**
    *Setter,recibe un Localidad y permite modificar el valor de el atributo localidad
    *@param Localidad p_localidad
    */
    private void setLocalidad(Localidad p_localidad){
        this.localidad = p_localidad;
    }
    
    /**
    *Setter,recibe un ArrayList<Empleado> y permite modificar el valor de el atributo empleados
    *@param ArrayList<Empleado> p_empleados
    */
    private void setEmpleados(ArrayList<Empleado> p_empleados){
        this.empleados = p_empleados;    
    }
    
    /**
    *Setter,recibe un int y permite modificar el valor de el atributo nroSucursal
    *@param Localidad p_nroSucursal
    */
    private void setSucursal(int p_nroSucursal){
        this.nroSucursal = p_nroSucursal;
    }
    
    /**
    *Metodo publico, agrega un empleado a la lista
    *@param Empleado p_empleado
    *@return devuelve un boolean
    */
    public boolean agregarEmpleado(Empleado p_empleado){
        return this.getEmpleados().add(p_empleado);
    }
    
    /**
    *Metodo publico, quita un empleado de la lista
    *@param Empleado p_empleado
    *@return devuelve un boolean
    */
    public boolean quitarEmpleado(Empleado p_empleado){
        if(this.getEmpleados().size() > 1){
            return this.getEmpleados().remove(p_empleado);    
        }else{
            return false;
        }
    }
    
    /**
    *Getter, permite obtener el valor de el atributo empleados
    *@return devuelve un ArrayList<Empleado>
    */
    public ArrayList<Empleado> getEmpleados(){
        return this.empleados;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo nombre
    *@return devuelve un String
    */
    public String getNombre(){
        return this.nombre;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo localidad
    *@return devuelve una Localidad
    */
    public Localidad getLocalidad(){
        return this.localidad;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo nroSucursal
    *@return devuelve un int
    */
    public int getSucursal(){
        return this.nroSucursal;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo cuentasBancarias
    *@return devuelve un ArrayList<CuentaBancaria>
    */
    public ArrayList<CuentaBancaria> getCuentasBancarias(){
        return this.cuentasBancarias;
    }
    
    /**
     * Metodo publico, lista los datos del empleado y el total a pagar
    */
    public void listarSueldos(){
        for(Empleado unEmpleado: this.getEmpleados()){
            System.out.println(""+unEmpleado.getCuil()+" "+unEmpleado.getApellido()+", "+unEmpleado.getNombre()+" ------------$"+unEmpleado.sueldoNeto());
        }
        System.out.println("Total a pagar------------------------------$"+this.sueldosAPagar());
    }
    
    /**
     * Metodo publico, calcula la suma de sueldos de los empleados
    */
    public double sueldosAPagar(){
        double sueldos = 0;
        for(Empleado unEmpleado: this.getEmpleados()){
            sueldos += unEmpleado.sueldoNeto();
        }
        return sueldos;
    }
    
    /**
     * Muestra los datos de el banco
    */
    public void mostrar(){
        System.out.println("Banco:"+this.getNombre()+" Sucursal:"+this.getSucursal());
        System.out.println("Localidad:"+this.getLocalidad().getNombre()+" Provincia:"+this.getLocalidad().getProvincia());
    }
    
    /**
     * Metodo publico, agrega una cuenta a la lista de cuentas
     * @param CuentaBancaria p_cuenta
     * @return devuelve un boolean
    */
    public boolean agregarCuentaBancaria(CuentaBancaria p_cuenta){
        return this.getCuentasBancarias().add(p_cuenta);
    }
    
    /**
     * Metodo publico, quita una cuenta de la lista de cuentas
     * @param CuentaBancaria p_cuenta
     * @return devuelve un boolean
    */
    public boolean quitarCuentaBancaria(CuentaBancaria p_cuenta){
        return this.getCuentasBancarias().remove(p_cuenta);
    }
    
    /**
     * Metodo publico, Muestra los datos de las cuentas con saldo en 0
    */
    private void mostrarSaldoCero(){
        System.out.println("----------------------------------------------------------");
        System.out.println("Titulares con Cuenta en Saldo Cero");
        System.out.println("----------------------------------------------------------");
        for(CuentaBancaria unaCuenta :this.getCuentasBancarias()){
            if(unaCuenta.getSaldo() < 1){
                System.out.println(""+unaCuenta.getNroCuenta()+"    "+unaCuenta.getTitular().getApellido()+", "+unaCuenta.getTitular().getNombre());
            }
        }
        System.out.println("----------------------------------------------------------");
    }
    
    /**
     * Metodo privado, devuelve la cantidad de cuentas con saldo positivo
     * @return devuelve un int
    */
    private int cuentasSaldoActivo(){
        int cantCuentas = 0;
        for(CuentaBancaria unaCuenta :this.getCuentasBancarias()){
            if(unaCuenta.getSaldo() > 0){
                cantCuentas += 1;
            }
        }
        return cantCuentas;
    }
    
    /**
     * Metodo publico, Muestra el total de cuentas del banco
    */
    public void mostrarResumen(){
        this.mostrar();
        System.out.println("*************************************************************************");
        System.out.println("RESUMEN DE CUENTAS BANCARIAS");
        System.out.println("*************************************************************************");
        System.out.println("Numero total de cuentas bancarias:"+this.getCuentasBancarias().size());
        System.out.println("Cuentas Activas: "+this.cuentasSaldoActivo());
        System.out.println("Cuentas Saldo Cero: "+(this.getCuentasBancarias().size() - this.cuentasSaldoActivo()));
        this.mostrarSaldoCero();
    }
}
