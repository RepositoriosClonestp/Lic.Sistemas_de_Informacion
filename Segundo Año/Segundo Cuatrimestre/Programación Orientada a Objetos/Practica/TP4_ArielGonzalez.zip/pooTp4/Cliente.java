/**
*@author Gonzalez Ariel
*Clase Cliente Tp 4.2
*/
public class Cliente
{
    /**
    * Atributos de la clase
    */
    private int nroDNI;
    private String apellido;
    private String nombre;
    private double saldo;
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param int p_dni
    *@param String p_apellido
    *@param String p_nombre
    *@param double p_importe
    */
    Cliente(int p_dni, String p_apellido,String p_nombre, double p_importe){
        this.setDni(p_dni);
        this.setApellido( p_apellido);
        this.setNombre(p_nombre);
        this.setSaldo(p_importe);
    }
    
    /**
    *Setter,recibe un entero por parametro y permite modificar el valor de el atributo dni
    *@param int p_dni
    */
    private void setDni(int p_dni){
        this.nroDNI = p_dni;
    }
    
    /**
    *Setter,recibe un String por parametro y permite modificar el valor de el atributo apellido
    *@param String p_apellido
    */
    private void setApellido(String p_apellido){
        this.apellido = p_apellido;
    }
    
    /**
    *Setter,recibe un String por parametro y permite modificar el valor de el atributo nombre
    *@param String p_nombre
    */
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    /**
    *Setter,recibe un double y permite modificar el valor de el atributo saldo
    *@param double p_importe
    */
    private void setSaldo(double p_importe){
        this.saldo = p_importe;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo dni
    *@return devuelve un entero
    */
    public int getDni(){
        return this.nroDNI;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo apellido
    *@return devuelve un String
    */
    public String getApellido(){
        return this.apellido;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo nombre
    *@return devuelve un String
    */
    public String getNombre(){
        return this.nombre;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo saldo
    *@return devuelve un double
    */
    public double getSaldo(){
        return this.saldo;
    }
    
    /**
    *Metodo publico,utiliza los metodos nomYape() y getDni() para formar una cadena de texto y mostrarlo por panalla
    */
    public void mostrar(){
        System.out.println("-Cliente-");
        System.out.println("Nombre y Apellido: "+this.nomYape()+" ("+this.getDni()+")");
    }
    
    /**
    *Metodo publico, ingresa un nuevo saldo
    *@param double p_importe 
    *@return devuelve el saldo actual de tipo double
    */
    public double nuevoSaldo(double p_importe){
        this.setSaldo(p_importe);
        return this.saldo;
    }
    
    /**
    *Metodo publico, agrega saldo
    *@return devuelve un double
    */
    public double agregaSaldo(double p_importe){
        this.setSaldo(this.getSaldo() + p_importe);
        return this.saldo;
    }

    /**
    * Metodo publico, utiliza los metodos getApellido() y getNombre() para formar una cadena y devolverla
    * @return devuelve un String
    */
    public String apeYnom(){
        return(""+this.getApellido()+" "+this.getNombre());
    }
    
    /**
    * Metodo publico, utiliza los metodos getNombre() y getApellido() para formar una cadena y devolverla
    * @return devuelve un String
    */
    public String nomYape(){
        return(""+this.getNombre()+" "+this.getApellido());
    }
}
