import java.util.Scanner;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
public class TomaPedido
{
    public static void main(String[] args){
        int opcion = 0;
        Scanner leer = new Scanner(System.in);
        
        Laboratorio unLaboratorio = new Laboratorio("DobleClick","San Lorenzo y Hipolito Yrigoyen","3794573223");
        Producto unProducto = new Producto(1234,"Tecnologia","Pendrive",34.56,unLaboratorio);
        String descripcion;
        String rubro;
        int codProducto;
        double costo;
        
        Cliente unCliente = new Cliente(23565789,"Perez","Basualdo",40000);
        Calendar fecha = new GregorianCalendar();
        Pedido unPedido = new Pedido(fecha,unCliente,unProducto);
        
        do{
            System.out.println("1-Ingrese un producto,2-Quite un producto,3-Pedido");
            System.out.println("Ingrese una opcion: ");
            opcion = leer.nextInt();
            
            switch(opcion){
                case 1:
                    System.out.println("Cuantos productos quiere agregar?: ");
                    int cant = leer.nextInt();
                    for(int i = 0;i < cant;i++){
                        
                        //Ingreso de datos producto
                        System.out.println("Ingrese el nombre del producto:");
                        descripcion = leer.next();
                    
                        System.out.println("Ingrese el rubro del producto:");
                        rubro = leer.next();
                    
                        System.out.println("Ingrese el costo del producto:");
                        costo = Double.parseDouble(leer.next());
                
                        System.out.println("Ingrese el codigo del producto:");
                        codProducto = Integer.parseInt(leer.next());
                        unPedido.agregarProducto(new Producto(codProducto,rubro,descripcion,costo,unLaboratorio));
                    }
                    break;
                case 2:
                    System.out.println("Ingrese el codigo del producto: ");
                    int codigo = Integer.parseInt(leer.next());
                    for(int i = 0; i < unPedido.getProductos().size();i++){
                        if(unPedido.getProductos().get(i).getCodigo() == codigo){
                            unPedido.quitarProducto(unPedido.getProductos().get(i));
                        }
                    }
                    break;
                case 3:
                    unPedido.mostrarPedido();
                    break;
            }
        }while(opcion != 0);
            
    }
}
