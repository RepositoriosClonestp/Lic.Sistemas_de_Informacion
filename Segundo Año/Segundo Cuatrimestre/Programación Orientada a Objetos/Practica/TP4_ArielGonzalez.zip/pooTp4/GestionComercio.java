import java.util.Scanner;

public class GestionComercio
{
    public static void main(String[] args){
        Scanner leer = new Scanner(System.in);
        int opcion = 0;
        Comercio unComercio = new Comercio("Avanti SRL");
        do{
            System.out.println("1-Contratar Empleado,2-Despedir empleado,3-Sueldo Neto de un Empleado,4-Nomina de empleados");
            opcion = leer.nextInt();
            switch(opcion){
                case 1:
                    System.out.println("Ingrese el nombre del empleado: ");
                    String nombre = leer.next();
                    System.out.println("Ingrese el apellido del empleado: ");
                    String apellido = leer.next();
                    System.out.println("Ingrese el cuil del empleado");
                    long cuil = (long)leer.nextInt();
                    System.out.println("Ingrese el sueldo del empleado");
                    double sueldo = (double)leer.nextInt();
                    System.out.println("Ingrese el año de ingreso del empleado");
                    int anio = leer.nextInt();
                    unComercio.altaEmpleado(new Empleado(cuil,nombre,apellido,sueldo,anio));
                    break;
                case 2:
                    System.out.println("Ingrese el cuil del empleado:");
                    cuil = (long) leer.nextInt();
                    unComercio.bajaEmpleado(cuil);
                    break;
                case 3:
                    System.out.println("Ingrese el cuil del empleado:");
                    cuil = (long) leer.nextInt();
                    unComercio.sueldoNeto(cuil);
                    break;
                case 4:
                    unComercio.nomina();
                    break;
            }
        }while(opcion != 0);
    }
}
