import java.util.Scanner;
public class Secretaria
{
    public static void main(String[] args){
        Scanner leer = new Scanner(System.in);
        double sueldoBasico,asignacionFamiliar;
        System.out.println("Ingrese el nombre de la escuela:");
        String nombreEscuela = leer.nextLine();
        System.out.println("Ingrese el domicilio de la escuela:");
        String domicilio = leer.nextLine();
        System.out.println("Ingrese el nombre del director:");
        String director = leer.nextLine();
        Escuela unaEscuela = new Escuela(nombreEscuela,domicilio,director);
        
        System.out.println("Ingrese el nombre del docente:");
        String nombre = leer.nextLine();
        System.out.println("Ingrese el grado:");
        String grado = leer.nextLine();
        System.out.println("Ingrese el sueldoBasico:");
        sueldoBasico = Double.parseDouble(leer.nextLine());
        System.out.println("Ingrese la asignacion familiar:");
        asignacionFamiliar = Double.parseDouble(leer.nextLine());
        Docente unDocente = new Docente(nombre,grado,sueldoBasico,asignacionFamiliar);
        
        unaEscuela.imprimirRecibo(unDocente);
    }
}
