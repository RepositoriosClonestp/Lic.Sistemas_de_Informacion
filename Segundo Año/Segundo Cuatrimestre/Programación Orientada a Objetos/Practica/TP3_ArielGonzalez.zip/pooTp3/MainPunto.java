
public class MainPunto
{
   public static void main(String[] args){
       Punto unPunto = new Punto(2,5);
       Punto otroPunto = new Punto(3,7);
       System.out.println(unPunto.distanciaA(otroPunto));
   }
}
