import java.util.*;
public class CuentaMain
{
    public static void main(String[] args){
        Calendar fechaNacimiento = Calendar.getInstance();
        fechaNacimiento.set(2000,9,4);
        
        Persona titular = new Persona(1249,"Juan","Perez",fechaNacimiento);
        CuentaBancaria unaCuenta = new CuentaBancaria(123,titular);
    
        System.out.println("Deposito:"+unaCuenta.depositar(1000));
        unaCuenta.mostrar();
        System.out.println("Extrajo:"+unaCuenta.extraer(500));
        unaCuenta.mostrar();
        System.out.println(unaCuenta.toString());
    }
    
    
}
