import java.util.Calendar;
import java.util.Scanner;

public class MainEmpleadoConJefe
{
    public static void main(String[] args){
        Scanner leer = new Scanner(System.in);
        Calendar fechaIngresoJefe = Calendar.getInstance();
        fechaIngresoJefe.set(2011,10,8);
        Calendar fechaIngresoEmpleado = Calendar.getInstance();
        fechaIngresoEmpleado.set(2017,5,10);
        EmpleadoConJefe unJefe = new EmpleadoConJefe(3242342L,"Gonzalez","Ariel",300000,fechaIngresoJefe);
        EmpleadoConJefe unEmpleado = new EmpleadoConJefe(3242342L,"Marcori","Joel",200000,fechaIngresoEmpleado,unJefe);
        int opcion;
        do{
            System.out.println("1-Datos Empleado,2-Datos Jefe");
            System.out.println("Ingrese una opcion: ");
            opcion = leer.nextInt();
            switch(opcion){
                case 1:
                    unEmpleado.mostrar();
                    break;
                case 2:
                    unJefe.mostrar();
                    break;
            }
            System.out.println("Si desea terminar ingrese 0");
            opcion = leer.nextInt();
        }while(opcion != 0);
        
    }
}
