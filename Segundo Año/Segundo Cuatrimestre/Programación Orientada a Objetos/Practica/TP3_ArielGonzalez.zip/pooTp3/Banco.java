import java.util.*;
public class Banco
{
    public static void main(String[] args){
        int nroDni = Integer.parseInt(args[0]);
        String nombre = args[1];
        String apellido = args[2];
        Calendar fechaNacimiento = Calendar.getInstance();
        fechaNacimiento.set(2000,9,4);
        Persona unTitular = new Persona(nroDni,nombre,apellido,fechaNacimiento);
        
        CuentaCorriente unaCuentaCorriente = new CuentaCorriente(1735,unTitular,1500L);
        CajaDeAhorro unaCajaDeAhorro = new CajaDeAhorro(1735,unTitular,1500L);
        /*
        unaCuentaCorriente.mostrar();
        unaCuentaCorriente.depositar(700);
        unaCuentaCorriente.mostrar();
        unaCuentaCorriente.extraer(300);
        unaCuentaCorriente.mostrar();
        unaCuentaCorriente.extraer(3000);
        
        */
        unaCajaDeAhorro.mostrar();
        unaCajaDeAhorro.depositar(700);
        unaCajaDeAhorro.mostrar();
        unaCajaDeAhorro.extraer(100);
        unaCajaDeAhorro.mostrar();
        unaCajaDeAhorro.extraer(100);
        unaCajaDeAhorro.extraer(100);
        unaCajaDeAhorro.extraer(100);
        unaCajaDeAhorro.extraer(100);
        unaCajaDeAhorro.extraer(100);
        unaCajaDeAhorro.mostrar();
        unaCajaDeAhorro.extraer(100);
        unaCajaDeAhorro.extraer(100);
        unaCajaDeAhorro.extraer(100);
        unaCajaDeAhorro.mostrar();
        unaCajaDeAhorro.extraer(100);
        unaCajaDeAhorro.extraer(100);
        unaCajaDeAhorro.mostrar();
        
        if(unTitular.esCumpleaños() == true){
            System.out.println("Es tu dia,Feliz Cumpleaños!!!");
        }
    }
}
