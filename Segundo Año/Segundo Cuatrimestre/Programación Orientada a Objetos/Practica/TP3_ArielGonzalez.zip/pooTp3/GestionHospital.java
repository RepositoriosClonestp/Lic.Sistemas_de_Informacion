public class GestionHospital
{
    public static void main(String args[]){
        Hospital unHospital = new Hospital("Garrahan","Leonardo Ruiz");
        Localidad localidadVive = new Localidad("Monte Caseros","Corrientes");
        Localidad localidadNacido = new Localidad("Monte Caseros","Corrientes");
        Paciente unPaciente = new Paciente(57869,"Juan Manuel Ortigoza","Bulevar 3 de Abril",localidadNacido,localidadVive);
 
        unHospital.consultaDatosFiliatorios(unPaciente);
    }
}
