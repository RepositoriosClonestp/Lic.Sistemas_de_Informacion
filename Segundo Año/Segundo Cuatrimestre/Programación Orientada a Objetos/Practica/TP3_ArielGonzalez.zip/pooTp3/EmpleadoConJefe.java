import java.util.Calendar;
import java.util.GregorianCalendar;
/**
*@author Gonzalez Ariel
*Clase EmpleadoConJefe 3.12
*/
public class EmpleadoConJefe
{
    /**
     * Atributos de la clase
    */
    private long cuil;
    private String apellido;
    private String nombre;
    private double sueldoBasico;
    private Calendar fechaIngreso;
    private EmpleadoConJefe jefe;
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param long p_cuil
    **@param String p_apellido
    *@param String p_nombre
    *@param double p_importe
    *@param Calendar p_fecha
    *@param EmpleadoConJefe p_jefe;
    */
    public EmpleadoConJefe(long p_cuil,String p_apellido,String p_nombre, double p_importe,Calendar p_fecha,EmpleadoConJefe p_jefe){
        this.setCuil(p_cuil);
        this.setApellido(p_apellido);
        this.setNombre(p_nombre);
        this.setSueldo(p_importe);
        this.setFechaIngreso(p_fecha);
        this.setJefe(p_jefe);
    }
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param long p_cuil
    *@param String  p_apellido
    *@param String p_nombre
    *@param double p_importe
    *@param Calendar p_fecha
    */
    public EmpleadoConJefe(long p_cuil,String p_apellido,String p_nombre, double p_importe, Calendar p_fecha){
        this.setCuil(p_cuil);
        this.setApellido(p_apellido);
        this.setNombre(p_nombre);
        this.setSueldo(p_importe);
        this.setFechaIngreso(p_fecha);
    }
    
    /**
    *Constructor con parametros, instancia un objeto de la clase
    *@param long p_cuil
    *@param String  p_apellido
    *@param String p_nombre
    *@param double p_importe
    *@param int p_anio
    */
    public EmpleadoConJefe(long p_cuil,String p_apellido,String p_nombre,double p_importe,int p_anio){
        this.setCuil(p_cuil);
        this.setNombre(p_nombre);
        this.setApellido(p_apellido);
        this.setSueldo(p_importe);
        this.setAnioIngreso(p_anio);
    }
    
    /**
    *Setter,recibe un long por parametro y permite modificar el valor de el atributo cuil
    *@param double p_cuil
    */
    private void setCuil(long p_cuil){
        this.cuil = p_cuil;
    }
    
    /**
    *Setter,recibe un String por parametro y permite modificar el valor de el atributo apellido
    *@param String p_apellido
    */
    private void setApellido(String p_apellido){
        this.apellido = p_apellido;
    }
    
    /**
    *Setter,recibe un String por parametro y permite modificar el valor de el atributo nombre
    *@param String p_nombre
    */
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    /**
    *Setter,recibe un double por parametro y permite modificar el valor de el atributo sueldoBasico
    *@param double p_importe
    */
    private void setSueldo(double p_importe){
        this.sueldoBasico = p_importe;
    }
    
    /**
    *Setter,recibe un Calendar por parametro y permite modificar el valor de el atributo p_fecha
    *@param Calendar p_importe
    */
    private void setFechaIngreso(Calendar p_fecha){
        this.fechaIngreso = p_fecha;
    }
    
    /**
    *Setter,recibe un EmpleadoConJefe por parametro y permite modificar el valor de el atributo p_jefe
    *@param EmpleadoConJefe p_importe
    */
    private void setJefe(EmpleadoConJefe p_jefe){
        this.jefe = p_jefe;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo jefe
    *@return devuelve un EmpleadoConJefe
    */
    public EmpleadoConJefe getJefe(){
        return this.jefe;
    }
    
    /**
    *Setter,recibe un int por parametro y permite modificar el valor de el atributo fechaIngreso
    *@param int p_anio
    */
    private void setAnioIngreso(int p_anio){
        Calendar fechaIngreso = Calendar.getInstance();
        fechaIngreso.set(p_anio,1,1);
        this.fechaIngreso = fechaIngreso;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo cuil
    *@return devuelve un long
    */
    public long getCuil(){
        return this.cuil;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo apellido
    *@return devuelve un String
    */    
    public String getApellido(){
        return this.apellido;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo nombre
    *@return devuelve un String
    */
    public String getNombre(){
        return this.nombre;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo fechaIngreso
    *@return devuelve un Calendar
    */
    public Calendar getFechaIngreso(){
        return this.fechaIngreso;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo sueldoBasico
    *@return devuelve un double
    */
    public double getSueldo(){
        return this.sueldoBasico;
    }
    
    /**
    *Getter, permite obtener el valor de el atributo fechaIngreso
    *@return devuelve un int
    */
    public int getAnio(){
        return this.fechaIngreso.get(Calendar.YEAR);
    }
    
    /**
    *Metodo publico, calcula la antiguedad del empleado
    *@return devuelve un int
    */
    public int antiguedad(){
        Calendar añoHoy = new GregorianCalendar();
        return (añoHoy.get(Calendar.YEAR) - this.getFechaIngreso().get(Calendar.YEAR));
    }
    
    /**
    *Metodo privado, realiza un descuento al empleado
    *@return devuelve un double
    */
    private double descuento(){
        double descuento;
        descuento = ((2 * this.getSueldo()) / 100) + 1500;
        return descuento;
    }
    
    /**
    *Metodo privado, paga un adicional al empleado teniendo en cuenta su antiguedad
    *@return devuelve un double
    */
    private double adicional(){
        double adicional  = 0;
        if(antiguedad() < 2){
            adicional = ((2 * this.getSueldo()) / 100);
        }else if(antiguedad() >= 2 && antiguedad() < 10){
            adicional = ((4 * this.getSueldo()) / 100);
        }else if(antiguedad() >= 10){
            adicional = ((6 * this.getSueldo()) / 100);
        }
        return adicional;
    }
    
    /**
    *Metodo publico,calcula el sueldo neto del empleado
    *@return devuelve un double
    */
    public double sueldoNeto(){
        double sueldoNeto;
        sueldoNeto = (this.getSueldo() + this.adicional()) - this.descuento();
        return sueldoNeto;
    }
    
    /**
    *Metodo publico, devuelve una cadena formada por el nombre y el apellido del empleado
    */
    public String nomYApe(){
        return (""+this.getNombre()+" "+this.getApellido());
    }
    
    /**
    *Metodo publico, devuelve una cadena formada por el apellido y el nombre del empleado
    *@return devuelve un String
    */
    public String apeYNom(){
        return (""+this.getApellido()+" "+this.getNombre());
    }
    
    /**
    *Metodo publico, muestra por pantalla los datos del empleado y el apellido y nombre del jefe si es que responde a alguno
    */
    public void mostrar(){
        System.out.println("Nombre y Apellido: "+this.nomYApe());
        System.out.println("CUIL: "+this.getCuil()+" Antiguedad: "+this.antiguedad()+" años de servicio");
        System.out.println("Sueldo Neto: $"+this.sueldoNeto());
        if(this.getJefe() != null){
            System.out.println("Responde a:"+this.getJefe().getNombre()+","+this.getJefe().getApellido());
        }else{
            System.out.println("Gerente General");
        }
        
    }
    
    /**
    *Metodo publico, forma una cadena con el nombe, apellido y el sueldo del empleado
    *@return devuelve un String
    */
    public String mostrarLinea(){
        return (""+this.getCuil()+" "+this.getApellido()+", "+this.getNombre()+" ...............$"+this.sueldoNeto());
    }

}
