/**
*@author Gonzalez Ariel
*Clase Punto 3.2
*/
public class Punto
{
   /**
   * Atributos de la clase
   */
   private double x;
   private double y;
   
   /**
   * Constructor Vacio, Instancia un objeto
   */
   public Punto(){
   }
   
   /**
   * Constructor con parametros, Instancia un objeto
   * @param double p_x
   * @param double p_y
   */
   public Punto(double p_x, double p_y){
       this.setX(p_x);
       this.setY(p_y);
   }
   
   /**
    *Setter,recibe un double por parametro y permite modificar el valor de el atributo y
    *@param double p_y
    */
   private void setY(double p_y){
       this.y = p_y;
   }
   
   /**
    *Setter,recibe un double por parametro y permite modificar el valor de el atributo x
    *@param double p_x
    */
   private void setX(double p_x){
       this.x= p_x;
   }
   
   /**
    *Getter, permite obtener el valor de el atributo x
    *@return devuelve un double
    */
   public double getX(){
       return this.x;
   }
   
   /**
    *Getter, permite obtener el valor de el atributo y
    *@return devuelve un double
    */
   public double getY(){
        return this.y;
   }   
   
   /**
    *Metodo publico,recibe 2 parametros de tipo double y desplaza las coordenadas del centro del Punto
    *@param double p_dx
    *@param double p_dy
    */
   public void desplazar(double p_dx,double p_dy){
       this.setX(this.getX() + p_dx);
       this.setY(this.getY() + p_dy);
   }
   
   /**
    *Metodo publico,devuelve una cadena formada por las coordenadas x e y
    *@return devuelve un String
    */
   public String coordenadas(){
       return ("("+this.getX()+", "+this.getY()+")");
   }
   
   /**
    *Metodo publico,muestra por pantalla las coordenadas del punto
    */
   public void mostrar(){
       System.out.println("Punto. X: "+this.getX()+" Y: "+this.getY());
   }
   
   
   /**
    * Metodo publico,recibe un punto por parametro y calcula la distancia con el punto que ejecuto la accion
    * @param Punto p_ptoDistante
   */
   public double distanciaA(Punto p_ptoDistante){
       double d;
       double resultadoX = p_ptoDistante.getX() - this.getX();
       double resultadoY = p_ptoDistante.getY() - this.getY();
       
       return Math.sqrt( Math.pow(resultadoX,2) + Math.pow(resultadoY,2));
       
   }
}

