import java.util.Scanner;
public class GestionStock
{
    public static void main(String[] args){
        Laboratorio unLaboratorio = new Laboratorio("Colgate S.A."," Scalabrini Ortiz 5524"," 54-11 -4239-8447");
        Producto unProducto = new Producto(123,"Perfumeria","Jabon Deluxe",5.25,unLaboratorio);
        Scanner leer = new Scanner(System.in);
        int opcion;
        do{
            System.out.println("1-Modificar Stock,2-Descripcion Producto");
            System.out.println("Ingrese una opcion: ");
            opcion = leer.nextInt();
            switch(opcion){
                case 1:
                    if(unProducto.getStock() != 500){
                        System.out.println("Ingrese el stock: ");
                        unProducto.ajuste(leer.nextInt());
                        
                    }else{
                        unProducto.ajuste(-200);
                        System.out.println("Se destruyeron 200 productos por estar mal estibados");
                    }
                    unProducto.mostrar();
                    break;
                case 2:
                    System.out.println(unProducto.mostrarLinea());
                    break;
            }
            System.out.println("Si desea terminar ingrese 0");
            opcion = leer.nextInt();
        }while(opcion != 0);
        
    }
}
