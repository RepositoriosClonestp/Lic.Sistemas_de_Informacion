import java.util.Scanner;

public class RegistroCivil
{
    public static void main(String args[]){
        Hombre unHombre = new Hombre("Pedro","Leyes",29);
        Mujer unaMujer = new Mujer("Maria","Gomez",28);
        
        Scanner leer = new Scanner(System.in);
        int opcion;
        do{
            System.out.println("1-Casar Pareja,2-Divorciar Pareja,3-Estado civil hombre, 4-Estado civil mujer,5-Datos pareja");
            System.out.println("Ingrese una opcion: ");
            opcion = leer.nextInt();
            switch(opcion){
                case 1:
                    unHombre.casarseCon(unaMujer);
                    unaMujer.casarseCon(unHombre);
                    break;
                case 2:
                    unaMujer.divorcio();
                    unHombre.divorcio();
                    break;
                case 3:
                    unHombre.mostrarEstadoCivil();
                    break;
                case 4:
                    unaMujer.mostrarEstadoCivil();
                    break;
                case 5:
                    unHombre.casadoCon();
                    unaMujer.casadaCon();
                    break;
            }
            System.out.println("Si desea terminar ingrese 0");
            opcion = leer.nextInt();
        }while(opcion != 0);
    }
}
