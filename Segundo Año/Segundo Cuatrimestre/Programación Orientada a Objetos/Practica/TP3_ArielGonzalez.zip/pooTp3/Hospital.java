/**
 * @author Gonzalez Ariel 
 * Clase Hospitalidad 3.8
 */
public class Hospital
{
    /**
    *Atributos de la Clase 
    */
    private String nombreHospital;
    private String nombreDirector;
    
    /**
    *Constructor con parametros, instancia un objeto
    *@param String p_nombreHospital
    *@param String p_nombreDirector
    */
    public Hospital(String p_nombreHospital,String p_nombreDirector){
        this.setNombreHospital(p_nombreHospital);
        this.setDirector(p_nombreDirector);
    }
    
    /**
    *Setter, recibe un String y permite modificar el valor del atributo nombreHospital
    *@param String p_nombreHospital
    */
    private void setNombreHospital(String p_nombreHospital){
        this.nombreHospital = p_nombreHospital;
    }
    
    /**
    *Setter, recibe un String y permite modificar el valor del atributo nombreDirector
    *@param String p_nombreDirector
    */
    private void setDirector(String p_nombreDirector){
        this.nombreDirector = p_nombreDirector;
    }
    
    /**
    *Getter, permite obtener el valor del atributo nombreHospital
    *@return devuelve un String
    */
    public String getNombreHospital(){
        return this.nombreHospital;
    }
    
    /**
    *Getter, permite obtener el valor del atributo nombreDirector
    *@return devuelve un String
    */
    public String getDirector(){
        return this.nombreDirector;
    }
    
    /**
     * Metodo Publico,muestra por pantalla los datos del hospital y del paciente
     * @param Paciente p_paciente
    */
    public void consultaDatosFiliatorios(Paciente p_paciente){
        System.out.println("Hospital:"+this.getNombreHospital()+" Director:"+this.getDirector());
        System.out.println("---------------------------------------------------------------------------------------------");
        System.out.println("Paciente:"+p_paciente.getNombre()+"   Historia Clinica:"+p_paciente.getHistoriaClinica()+"   Domicilio:"+p_paciente.getDomicilio());
        System.out.println(p_paciente.getVive().mostrar());
    }
}
