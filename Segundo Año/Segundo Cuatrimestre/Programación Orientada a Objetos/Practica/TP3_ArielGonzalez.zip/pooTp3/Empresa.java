import java.util.Calendar;

public class Empresa
{
    public static void main(String[] args){
        Calendar fechaIngreso = Calendar.getInstance();
        fechaIngreso.set(2001,9,7);
        Empleado unEmpleado = new Empleado(20341234385L,"Juan","Perez",300000,fechaIngreso);
        if(unEmpleado.esAniversario()){
            System.out.println("Feliz aniversario!!!,Puede retirase 1 hora antes!!!");
        }
        unEmpleado.mostrar();
        
    }
}
