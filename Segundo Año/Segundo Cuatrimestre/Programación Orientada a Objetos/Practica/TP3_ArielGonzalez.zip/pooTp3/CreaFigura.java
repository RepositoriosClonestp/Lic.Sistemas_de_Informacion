import java.util.Scanner;
import java.util.Random;
public class CreaFigura
{
    public static void main(String[] args){
       Scanner leer = new Scanner(System.in);
       Random r1 = new Random();
       

       boolean salir = true;
       //asigna valor al radio,crea un circulo
       double radio = r1.nextDouble() * 100;
       Circulo unCirculo = new Circulo(radio,new Punto(0,0));

       //asigna valor al radio,crea otro circulo
       radio = r1.nextDouble() * 100;
       Circulo otroCirculo = new Circulo(radio,new Punto(5.2,0.5));   
       
       //asigna valor al ancho y al alto del rectangulo, crea un rectangulo
       double alto = r1.nextDouble() * 100;
       double ancho = r1.nextDouble() * 100;
       Rectangulo unRectangulo = new Rectangulo(new Punto(),ancho,alto);
       
       //asigna valor al ancho y al alto del rectangulo, otro rectangulo
       alto = r1.nextDouble() * 100;
       ancho = r1.nextDouble() * 100;
       Rectangulo otroRectangulo = new Rectangulo(new Punto(7.4,4.5),ancho,alto);
       
       
       do{
           System.out.println("1-Desplazar circulo, 2-Caracteristicas circulo,3-Circulo Mayor,4-Calcular distancias Circulos");
           System.out.println("5-Desplazar rectangulo,6-Caracteristicas Rectangulo,7-Rectangulo Mayor,8-Calcular distancias Rectangulos,9-Salir");
           int opcion = Integer.parseInt(leer.next());
           
           switch(opcion){
               case 1:
                   System.out.println("Ingrese el valor de la coordenada x:");
                   double x = Double.parseDouble(leer.next());
                   System.out.println("Ingrese el valor de la coordenada y:");
                   double y = Double.parseDouble(leer.next());
                   unCirculo.desplazar(x,y);
                   System.out.println("Se desplazo el circulo...");
                   unCirculo.getCentro().mostrar();
                   break;
               case 2:
                   unCirculo.caracteristicas();
                   break;
               case 3:
                   Circulo mayor = unCirculo.elMayor(otroCirculo);
                   mayor.caracteristicas();
                   break;
               case 4:
                   System.out.println(unCirculo.distanciaA(otroCirculo));
                   break;
               case 5:
                    System.out.println("Ingrese el valor de la coordenada x:");
                    x = Double.parseDouble(leer.next());
                    System.out.println("Ingrese el valor de la coordenada y:");
                    y = Double.parseDouble(leer.next());
                    unRectangulo.desplazar(x,y);
                    System.out.println("Se desplazo el rectangulo...");
                   break;
               case 6:
                   unRectangulo.caracteristicas();
                   break;
               case 7:
                   Rectangulo mayorRectangulo = unRectangulo.elMayor(otroRectangulo);
                   mayorRectangulo.caracteristicas();
                   break;
               case 8:
                   System.out.println(unRectangulo.distanciaA(otroRectangulo));
                   break;
               case 9:
                   salir = false;
                   break;
           }
       }while(salir != false);
    }
}
