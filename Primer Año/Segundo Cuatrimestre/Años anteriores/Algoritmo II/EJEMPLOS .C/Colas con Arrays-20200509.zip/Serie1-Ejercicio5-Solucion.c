/* 
	En una cl�nica la secretaria hace un listado con los nombres y apellidos 
	de los pacientes que van llegando para luego ser atendidos en ese orden. 
	El medico atiende un m�ximo de 20 pacientes por d�a. 
	Se solicita: generar un listado de todos los pacientes que van a ser 
	atendidos en el d�a, conocer si hay turnos disponibles, 
	y realizar una funci�n para borrar de la lista los pacientes a medida 
	que son atendidos (utilizar la implementaci�n con frente m�vil).
*/
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#define max 5

typedef char tstring[30];

typedef tstring tCola [max];	

tCola pacientes;
int i, frente, final;

void CrearColaVacia();
bool ColaVacia(); 
bool ColaLlena();
void agregarPaciente(tstring);
void eliminarPacienteFrenteMovil();
void PrimerElemento();
void visualizarPacientes();
bool hayTurnosDisponibles();
void Menu();

int main() {
	CrearColaVacia();	
	Menu();
	return 0;
}

void CrearColaVacia() {
	frente = -1;	
	final = -1;	
}

bool ColaVacia() {
	return ((frente == -1) && (final == -1));
}

bool ColaLlena() {
	return (final == (max-1));
}

void agregarPaciente(tstring pPaciente) {
	if (!ColaLlena()) {		
		final++;
		strcpy(pacientes[final], pPaciente);
		printf("Paciente agregado! %s\n", pacientes[final]);
		//significa que es el primer elemento
		if (final == 0 )
			frente = 0;				
	}
	else
		printf("No hay lugar!\n");
}

void eliminarPacienteFrenteMovil()
{
	if (ColaVacia())
		printf("No hay elementos por eliminar!!!\n");
	else {
		//poner en cero o vacio el elemento del frente
		strcpy(pacientes[frente], "");
		
		printf("Paciente atendido!!!\n");		
		
		//si frente y final son iguales significa que elimine el ultimo		
		if (frente == final) {
			CrearColaVacia();
		}
		else
			frente++;					
	}
}

void PrimerElemento() {
	printf("Elemento en el frente: %s\n", pacientes[frente]);;
}

void visualizarPacientes() {
	int i;
	printf("Pacientes esperando ser atendidos: \n");
	for (i = frente; i <= final; i++) {
		printf("%s\n", pacientes[i]);
	}
	printf("\n\n");	
}

bool hayTurnosDisponibles() {
	return !ColaLlena();
}

void Menu() {	
	int opcion;
	tstring paciente;
	printf("*** Opciones disponibles ***\n");	
	printf("1- Agregar paciente  2- Eliminar paciente 3- Mostrar primer elemento\n");
	printf("4- Visualizar pacientes en espera 5- Cola Vacia? 6- Cola Llena? 7-hay tunos? 0- Salir \n");	
	printf("Opcion: ");
	scanf("%d", &opcion); fflush(stdin);
	switch (opcion) {
		case 1:
		 	printf("Ingrese un paciente: ");
		 	//scanf("%[^\n]s", &paciente);
			gets(paciente);															
			agregarPaciente(paciente);
			printf("\n");
			Menu();	
		    break;
		case 2:		    
		    eliminarPacienteFrenteMovil();
			printf("\n");
			Menu();	
			break;
		case 3:		 
			PrimerElemento();
			Menu();	
			break;		
		case 4:		 
			printf("*** Pacientes en cola ***\n");									
			visualizarPacientes();
			Menu();	
			break;
		case 5:
			printf("Cola vacia? %s\n", ColaVacia() ? "si" : "no");
			Menu();	
			break;
		case 6:
			printf("Cola llena? %s\n", ColaLlena() ? "si" : "no");
			Menu();	
			break;
		case 7:
			printf("Hay turnos? %s\n", hayTurnosDisponibles() ? "si" : "no");
			Menu();	
			break;
		case 0:
			printf("\n");			
			break;
	}
}
