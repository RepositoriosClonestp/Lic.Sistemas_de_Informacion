#include <stdio.h>
void priprograma();
void finprograma();
void cliente();
void pricliente();
void fincliente();
void movimiento();

void abrirArchivo();
void leerArchivo();
void cerrarArchivo();

    
    
    FILE *Fichero;

struct sRegistro {
	int  NumeroCuenta;
 	char ApellidoyNombre[35];
 	int codOperacion;
 	float Importe;
 	
/* declarar tantos campos como se desee, pero todo el tama�o de la estructura 
   deben ser conocidos por el compilador. */ 
} registro;

	int numero=1;
    int NumeroCuentaAnterior;
    int contador=0;
    float TotalDeposito=0;
	float TotalExtraccion;
    
int main(){
    priprograma(); 
 	   
	   
       while (!feof(Fichero)){ 
  
   		 
		         
  	        cliente();
   
              }
	finprograma();
}
void priprograma(){
	printf("\n\tNumero de Cuenta \tApellido \tCod. Operacion \tImporte");
    abrirArchivo();
    leerArchivo();
}

void abrirArchivo(){
     Fichero=fopen("Clientes.dat", "rb");
}
	
void leerArchivo(){
     fread(&registro,sizeof(struct sRegistro), 1,Fichero);	 
    if (feof(Fichero)){
    	 registro.NumeroCuenta = 9999;
  }
}

void cliente(){
	 pricliente();
	   while (registro.NumeroCuenta==NumeroCuentaAnterior){
	   	      movimiento();
	   	     }   
     fincliente();
}


void pricliente(){
	 NumeroCuentaAnterior=registro.NumeroCuenta;
	 contador=0; 	
	 TotalDeposito=0;
	 TotalExtraccion=0;
}
void movimiento(){
	 printf("\n\t%i" "\t\t\t%s" "\t\t%i" "\t\t%.2f" , registro.NumeroCuenta, 
	 registro.ApellidoyNombre, registro.codOperacion, registro.Importe);
     contador=contador+1;
     if(registro.codOperacion==1) {
                                    
     TotalDeposito=TotalDeposito+registro.Importe;
                                                                 }
	 else  if(registro.codOperacion==2){
																		
     TotalExtraccion=TotalExtraccion+registro.Importe;
                                    							}
                                                                    
     leerArchivo();
 
}
void fincliente(){
 printf("\n\nMovimientos del Cliente = ");
      printf("%i", contador);
      printf(" Imp Depositos  =");
      printf("\%.2f",TotalDeposito);
      printf(" Imp Extraccion =");
      printf("\%.2f",TotalExtraccion);	
}

void finprograma(){
	  
      cerrarArchivo();
}

void cerrarArchivo(){
	 fclose(Fichero);
     getchar();
     return ;
}
