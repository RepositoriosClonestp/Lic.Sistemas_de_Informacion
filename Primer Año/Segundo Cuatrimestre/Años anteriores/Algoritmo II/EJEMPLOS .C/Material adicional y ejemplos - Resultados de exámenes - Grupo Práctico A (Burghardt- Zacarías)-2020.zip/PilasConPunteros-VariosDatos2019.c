/**
Ejercicio de ejemplo - Serie Pilas implementadas con Punteros.
Autor: Algoritmos y Estructuras de Datos 2
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef struct nodo {
	int dni;		
	char nombre[25];
    struct nodo *siguiente;    
}tPila;

tPila * pila;

void InicializarPila();
bool PilaVacia();
void Apilar(tPila);
void ApilarVersion2(int, char[25]);
void Desapilar();
void VisualizarElementos();
tPila Cima();

void InicializarPila(){	
	pila = NULL;	
}

bool  PilaVacia(){
	if (pila == NULL)
		return true;
	else
		return false;	
}

void Apilar(tPila pDatos){
	tPila * aux;
	aux = pila;
	pila = malloc(sizeof(tPila));	
	pila->dni = pDatos.dni;		
	strcpy(pila->nombre, pDatos.nombre);
	pila->siguiente = aux;				
	printf("Elemento insertado!\n");		
}

void Desapilar(){
	tPila * aux;
	aux = pila;
	pila = pila->siguiente;
	free(aux); 
	printf("Elemento de la cima eliminado!\n");
}

void VisualizarElementos(){
	tPila *aux;		
	aux = pila;
	if (PilaVacia() == false)	{
		printf( "\nElementos en la pila: \n" );
		while(aux != NULL) {
			printf("%d\t%s \n", aux->dni, aux->nombre);
	    	aux = aux->siguiente;
		}
	 }else printf( "\nLa pila esta vacia!!\n" );
	printf("\n\n" );
}

tPila Cima(){
	tPila datosCima;
	datosCima.dni = pila->dni;
	strcpy(datosCima.nombre, pila->nombre);
	datosCima.siguiente = pila->siguiente;
	return datosCima;	
}

int main() {	
	tPila datosIngresar, datosC;
	
	InicializarPila();	
	printf("Pila vacia? %s\n", PilaVacia() ? "si" : "no");	
	
	datosIngresar.dni = 111;
	strcpy(datosIngresar.nombre, "Maria");
	
	Apilar(datosIngresar);	
	printf("Pila vacia? %s\n", PilaVacia() ? "si" : "no");	
	
	datosIngresar.dni = 222;
	strcpy(datosIngresar.nombre, "Jose");
	
	Apilar(datosIngresar);	
	
	datosIngresar.dni = 333;
	strcpy(datosIngresar.nombre, "Maria Jose");
	
	Apilar(datosIngresar);	
	
	VisualizarElementos();	
	Desapilar();
	VisualizarElementos();
	
	datosC = Cima();
		
	printf("\nElemento en la cima: %s %d \n", datosC.nombre, datosC.dni);
	return 0;
}


