#include "operacionesRectangulo.h"
#include <stdio.h>

int main() {	
	char opc = 's';
	float base, altura;
	while (opc == 's') {
		printf("Ingresar base: ");
		scanf("%f", &base);
		printf("Ingresar altura: ");
		scanf("%f", &altura);
		
		/* Se utiliza las funciones que est�n declaradas y definidas en el TDA */
		printf("Perimetro: %.2f\n", perimetro(base, altura)); 
		printf("Area: %.2f\n", area(base, altura)); 
		
		printf("Otro calculo? s/n:"); fflush(stdin);
		scanf("%c", &opc);
	}
	
	return 0;
}
