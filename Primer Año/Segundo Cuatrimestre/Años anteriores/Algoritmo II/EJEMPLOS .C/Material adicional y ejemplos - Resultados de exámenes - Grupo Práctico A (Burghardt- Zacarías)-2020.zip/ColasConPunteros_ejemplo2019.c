/* Ejemplo de Cola, manejo con Vectores */
/*Autor: C�tedra Algoritmos y Estructuras de Datos II*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef struct nodo {
	int codprod;
	int stock;
	float precio;		
    struct nodo * siguiente;    
}tApNodo;

typedef struct {
	tApNodo * principio;
	tApNodo * final;
}tCola;


tCola v_cola;

void inicializarCola();
bool colaVacia();
void push(int p_codprod, int p_stock, float p_precio);
void pop();
void visualizarElementos();
tApNodo primerNodo();

void menu();

int main(){	
	inicializarCola();	
	menu();
	
	return 0;
}

void inicializarCola(){		
	v_cola.principio = NULL;
	v_cola.final = NULL;
}

bool  colaVacia(){		
	if (v_cola.final == NULL)
		return true;
	else
		return false;
}

void push(int p_codprod, int p_stock, float p_precio) {//Agregar elemento	
	tApNodo * nuevoNodo;
	nuevoNodo = malloc (sizeof(tApNodo));	
	nuevoNodo->codprod = p_codprod;
	nuevoNodo->stock = p_stock;
	nuevoNodo->precio = p_precio;	
	nuevoNodo->siguiente = NULL; //Siempre NULL porque se ingresa x el final
	
	if (colaVacia()== true) //significa que agrego el 1er nodo
	{	
		v_cola.principio = nuevoNodo;
		v_cola.final = nuevoNodo;
	}
	else
	{	
		v_cola.final->siguiente = nuevoNodo;
		v_cola.final = nuevoNodo;
	}	
	printf("Elemento insertado!\n");
}

void pop() {//Quitar elemento	
	tApNodo * nodoAux;
	if (colaVacia() == true)
		printf("No hay elementos en cola\n");
	else
	{
		//si la cola es unitaria
		if (v_cola.principio == v_cola.final)
		{
			nodoAux = v_cola.principio;
			free(nodoAux);
			v_cola.principio = NULL;
			v_cola.final = NULL;				
		}
		else
		{
			nodoAux = v_cola.principio;
			v_cola.principio = nodoAux->siguiente;
			free(nodoAux);
		}
	}	
}

void visualizarElementos(){
	tApNodo * colaPrincipio;
	if (colaVacia() == true)
		printf("No hay elementos para mostrar!\n");
	else
	{
		printf("Productos: \n");
		printf("Codigo     Stock     Precio unitario: \n");
		colaPrincipio = v_cola.principio;
		while (colaPrincipio != NULL)
		{
			printf("%.2d\t", colaPrincipio->codprod);
			printf("%.2d\t", colaPrincipio->stock);
			printf("%.2f\n", colaPrincipio->precio);
			colaPrincipio = colaPrincipio->siguiente;
		}
		printf("\n\n");
	}
}

tApNodo primerNodo(){
	tApNodo auxiliar;
	auxiliar.codprod = v_cola.principio->codprod;
	auxiliar.stock = v_cola.principio->stock;
	auxiliar.precio = v_cola.principio->precio;
	auxiliar.siguiente = v_cola.principio->siguiente;
	return auxiliar;
}

void menu() {	
	int opcion, elem;
	int vcod, vstock;
	float vpre;
	tApNodo aux;
	system("cls");
	printf("*** Opciones disponibles ***\n");	
	printf("1- Agregar Producto  2- Eliminar Producto 3- Mostrar Productos\n");
	printf("4- Cola vacia? 5- Datos del Primer Nodo 0- Salir \n");	
	printf("Opcion: ");
	scanf("%d", &opcion); fflush(stdin);
	switch (opcion) {
		case 1:
			printf("Ingrese el codigo de producto: ");
		 	scanf("%d", &vcod);
		 	printf("Ingrese el precio del producto: ");
		 	scanf("%f", &vpre);
		 	printf("Ingrese el stock: ");
			scanf("%d", &vstock);
			push(vcod, vstock, vpre);
			printf("\n");
			system("pause");
			menu();	
		    break;
		case 2:		    
		    pop();
			printf("\n");
			system("pause");
			menu();	
			break;
		case 3:		 
			visualizarElementos();
			system("pause");
			menu();	
			break;		
		case 4:		 
			printf("Cola vacia? %s\n", colaVacia() ? "si" : "no");
			system("pause");
			menu();	
			break;
		case 5:
			aux = primerNodo();
			printf("*** Primer Producto ***\n");
			printf("Codigo de Producto: %d \n", aux.codprod);
			printf("Precio: $ %f \n", aux.precio);
			printf("Stock: %d \n", aux.stock);
			system("pause");
			menu();	
			break;
		case 0:
			printf("PROGRAMA FINALIZADO.\n");			
			break;
	}
}

