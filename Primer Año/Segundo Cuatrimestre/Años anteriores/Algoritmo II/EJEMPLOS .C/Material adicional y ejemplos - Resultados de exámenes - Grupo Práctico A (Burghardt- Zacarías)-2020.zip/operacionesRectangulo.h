float perimetro(float, float);
float area(float, float);

float perimetro(float pBase, float pAltura) {
	return 2.0 * (pBase + pAltura);
}

float area(float pBase, float pAltura) {
	return pBase * pAltura;
}


