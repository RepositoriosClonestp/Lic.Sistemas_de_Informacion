/* Ejemplo de Lista enlazada, manejo con punteros */
/*Autor: C�tedra Algoritmos y Estructuras de Datos II*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef int tElem;

typedef struct nodo {
	tElem elem;		
    struct nodo *siguiente;    
}tLista;

tLista * lista;

void inicializarLista();
bool listaVacia();
void insertarPrimero(tElem pElem);
void insertarAdelante(tElem pElem);
void insertarElemento(tElem pElem);
void eliminarPrimero();
void visualizarElementos();
void insertarK(int k, tElem nuevoDato);
void eliminarK(int k);

int main() {	
	int velem;
	int vpos;
	inicializarLista();	
	printf("Lista vacia? %s\n", listaVacia() ? "si" : "no");	
	insertarElemento(1);	
	printf("Lista vacia? %s\n", listaVacia() ? "si" : "no");		
	insertarElemento(2);	
	insertarElemento(3);	
	visualizarElementos();
	insertarK(3, 5);
	visualizarElementos();
	insertarK(2, 10);
	printf("Ingrese el valor a insertar: ");
	scanf("%d", &velem);fflush(stdin);
	printf("Ingrese el valor de la posicion: ");
	scanf("%d", &vpos);fflush(stdin);
	insertarK(vpos, velem);
	
	visualizarElementos();
	eliminarPrimero();
	visualizarElementos();
	eliminarK(2);
	visualizarElementos();

	return 0;
}

void inicializarLista(){	
	lista = NULL;	
}

bool  listaVacia(){
	if (lista == NULL)
		return true;
	else
		return false;
	//return (lista == NULL);
}

void insertarPrimero(tElem pElem){
	lista = malloc(sizeof(tLista));
	lista->elem = pElem;		
	lista->siguiente = NULL;	
	printf("Primer elemento insertado!\n");
}

void insertarAdelante(tElem pElem){
	tLista * nuevoNodo;
	nuevoNodo = malloc(sizeof(tLista));	
	nuevoNodo->elem = pElem;		
	nuevoNodo->siguiente = lista;		
	lista = nuevoNodo;		
	printf("Elemento insertado!\n");
}

void insertarElemento(tElem pElem){
	if (lista == NULL)
		insertarPrimero(pElem);
	else
		insertarAdelante(pElem);
}

void eliminarPrimero(){
	tLista * aux;
	aux = lista;
	lista = lista->siguiente;
	free(aux); 
	printf("Primer elemento eliminado!\n");
}

void visualizarElementos(){
	tLista *aux; /* lo usamos para recorrer la lista */		
	aux = lista;
	if (listaVacia() == false)
	{
		while(aux != NULL) 
		{
			printf("%d ", aux->elem);
	    	aux = aux->siguiente;
		}
	 }else printf( "\nLa lista esta vacia!!\n" );
	printf("\n\n" );
	
	// otra forma de recorrer
	/*int i;	
	i=0;
	aux = lista;
	printf("\nElementos en la lista:\n");	
	while (aux != NULL) 
	{
	    printf("%d\n", aux->elem);
	    aux = aux->siguiente;
	    i++;
	}
	if (i==0) printf( "\nLa lista esta vacia!!\n" );
	printf("\n\n" );*/
}

void insertarK(int k, tElem nuevoDato){
	tLista * nuevoNodo, * aux;
	int i; 
	aux = lista; 
	//El bucle avanza aux hasta el nodo k-1
	for(i = 1; i < k-1; i++)
	{
		aux = aux->siguiente;
	}	
	//Actualizaci�n de punteros	
  	nuevoNodo = malloc(sizeof(tLista));
	nuevoNodo->elem = nuevoDato; 
	nuevoNodo->siguiente = aux->siguiente;
  	aux->siguiente = nuevoNodo;		
}

void eliminarK(int k){
	tLista * nodoSuprimir, * aux;
	int i; 
	aux = lista; 
	//El bucle avanza aux hasta el nodo k-1
	for(i = 1; i < k-1; i++)
	{
		aux = aux->siguiente;
	}	
	//Actualizaci�n de punteros	y liberar memoria	
	nodoSuprimir = aux->siguiente; 
	aux->siguiente = nodoSuprimir->siguiente; 
	free(nodoSuprimir);  
	
	printf("Elemento de la posicion %d eliminado\n", k);	
}




