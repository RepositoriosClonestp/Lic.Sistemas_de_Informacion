#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef float tDatos;

typedef struct nodo {
	tDatos dato;		
    struct nodo * siguiente;    
}tApNodo;

typedef struct {
	tApNodo * principio;
	tApNodo * final;
}tCola;

tCola cola;

void inicializarCola();
bool colaVacia();
void push(tDatos); /* insertar un elemento */
void pop(); /* quitar un elemento */
void visualizarElementos();
tDatos primerElemento();
tApNodo * primerElemento2(); /* otra forma de devolver el primer elemento */

void inicializarCola() {		
	cola.principio = NULL;
	cola.final = NULL;
}

bool  colaVacia() {		
	return (cola.final == NULL);
}

/* Agregar elemento */
void push(tDatos pDato) {	
	tApNodo * nuevoNodo;

	nuevoNodo = (tApNodo *) malloc (sizeof(tApNodo));	
	nuevoNodo->dato = pDato;	
	nuevoNodo->siguiente = NULL; //Siempre NULL porque se ingresa x el final
	
	if ( colaVacia() ) {	
		//significa que se agrega el primer nodo
		cola.principio = nuevoNodo;
		cola.final = nuevoNodo; 
	}
	else
	{	
		cola.final->siguiente = nuevoNodo;
		cola.final = nuevoNodo;
	}	
	printf("Elemento insertado!\n");
}

/* Quitar elemento */
void pop() {
	tApNodo * nodoAEliminar;
	if ( colaVacia() ) {
		printf("No hay elementos en cola\n");
	}else {
		/* se debe guardar la memoria del nodo que est� al principio  */
		nodoAEliminar = cola.principio;
		
		/* 	Actualizaci�n de punteros */
		if (cola.principio == cola.final) {
			/* 	si la cola es unitaria, se va a quitar el �ltimo elemento,
				entonces hay que poner en NULL los dos punteros */
			cola.principio = NULL;
			cola.final = NULL;				
		}else {	
			/* 	si la cola NO es unitaria, solo se actualiza el puntero del principio  */
			cola.principio = nodoAEliminar->siguiente;
		}
		/* una vez actualizados los punteros, solo resta liberar la memoria */
		free(nodoAEliminar);
		printf("Elemento eliminado!\n");
	}	
}

void visualizarElementos() {
	tApNodo * colaPorRecorrer;
		
	if ( colaVacia() ) {
		printf("No hay elementos para mostrar!\n");
	}else {
		printf("Elementos en la cola: \n");
		/* Para recorrer la cola se comienza por el nodo del principio */
		colaPorRecorrer = cola.principio; 
		while (colaPorRecorrer != NULL) {
			printf("%.2f\t", colaPorRecorrer->dato);
			colaPorRecorrer = colaPorRecorrer->siguiente;
		}
		printf("\n\n");
	}
}

tDatos primerElemento() {
	if ( !colaVacia() ) {
		return cola.principio->dato;
	}else	
		return 0.0;	
}

tApNodo * primerElemento2() {
	if ( !colaVacia() ) {
		return cola.principio;
	}else	
		return NULL;	
}

int main() {	
	inicializarCola();	
	printf("Cola vacia? %s\n", colaVacia() ? "si" : "no");	
	push(100.0);	
	printf("Cola vacia? %s\n", colaVacia() ? "si" : "no");	
	push(200.0);	
	push(300.0);	
	visualizarElementos();	
	pop();
	visualizarElementos();
	printf("\nElemento al principio: %.2f \n", primerElemento());
	pop();
	pop();
	visualizarElementos();	
	printf("\nElemento al principio: %.2f \n", primerElemento());
	return 0;
}


