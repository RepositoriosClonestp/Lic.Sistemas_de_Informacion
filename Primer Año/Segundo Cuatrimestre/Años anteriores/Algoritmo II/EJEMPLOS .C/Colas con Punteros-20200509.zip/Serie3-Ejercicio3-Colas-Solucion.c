#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
typedef char tString[20];

typedef struct {
	int ipPC;
	tString nombreDocumento;
	int tipoDocumento; //(01. docx - 02.pdf - 03.jpg - 04.png - 05.xlsx),
	float tamanioBytes;
}tDatos;

typedef struct nodo {
	tDatos documento;
	struct nodo * siguiente;
}tApNodo;

typedef struct {
	tApNodo * principio;
	tApNodo * final;	
}tColaDocumentos;

tColaDocumentos colaDocumentos;

void inicializarCola();
bool colaVacia();
void enviarDocumento(tDatos); /* insertar un elemento */
void quitarDocumento(); /* quitar un elemento */
void visualizarDocumentosEnCola();
tApNodo * proximoDocumento(); 
int cantidadDocumentosFormatoImg();
float tamanioTotalMB();

int main() {	
	tDatos doc;
	inicializarCola();
	
	doc.ipPC = 111;
	strcpy(doc.nombreDocumento, "doc1");
	doc.tipoDocumento = 1;
	doc.tamanioBytes = 24000.0;
	enviarDocumento(doc);
	
	doc.ipPC = 222;
	strcpy(doc.nombreDocumento, "img01");
	doc.tipoDocumento = 3;
	doc.tamanioBytes = 45000.0;
	enviarDocumento(doc);
	
	doc.ipPC = 333;
	strcpy(doc.nombreDocumento, "img02");
	doc.tipoDocumento = 4;
	doc.tamanioBytes = 54000.0;
	enviarDocumento(doc);
	
	visualizarDocumentosEnCola();
	printf("Tamanio total en MB: %.2f MB\n\n", tamanioTotalMB());
	
	quitarDocumento();
	
	visualizarDocumentosEnCola();
	
	printf("Proximo documento a imprimir: %s\n", proximoDocumento()->documento.nombreDocumento);
	
	printf("Cantidad de imagenes: %d\n", cantidadDocumentosFormatoImg());
		
	quitarDocumento();
	visualizarDocumentosEnCola();
	printf("Cantidad de imagenes: %d\n", cantidadDocumentosFormatoImg());
	
	return 0;
}

void inicializarCola() {
	colaDocumentos.principio = NULL;
	colaDocumentos.final = NULL;
}

bool colaVacia() {
	return (colaDocumentos.final == NULL);
}

void enviarDocumento(tDatos pDatosDocumento) {
	tApNodo * nuevoDocumento;
	
	nuevoDocumento = (tApNodo *) malloc(sizeof(tApNodo));
	nuevoDocumento->documento = pDatosDocumento;
	nuevoDocumento->siguiente = NULL;
	
	if(colaVacia()){
		colaDocumentos.principio = nuevoDocumento;
		colaDocumentos.final = nuevoDocumento;
	}else{
		colaDocumentos.final->siguiente = nuevoDocumento;
		colaDocumentos.final = nuevoDocumento;
	}
	printf("Documento insertado a la cola de impresion\n\n");
}

void quitarDocumento() {
	tApNodo * nodoSuprimir;
	if(colaVacia()) {
		printf("No hay documentos para imprimir!\n\n");
	}else {
		nodoSuprimir = colaDocumentos.principio;
		if(colaDocumentos.principio == colaDocumentos.final) {
			inicializarCola();
		}else {
			colaDocumentos.principio = nodoSuprimir->siguiente;
		}
		free(nodoSuprimir);
		printf("Documento impreso!\n\n");
	}
}

void visualizarDocumentosEnCola() {
	tApNodo * aux;
	if(colaVacia()) {
		printf("No hay documentos en cola!\n\n");
	}else {
		aux = colaDocumentos.principio;
		printf("Documentos en cola:\n");
		while(aux != NULL) {
			printf("%d\t%s\t%.2f\n", aux->documento.ipPC, aux->documento.nombreDocumento, aux->documento.tamanioBytes);
			aux = aux->siguiente;
		}
		printf("\n\n");
	}
}

tApNodo * proximoDocumento() {
	return colaDocumentos.principio;
} 

int cantidadDocumentosFormatoImg() {
	tApNodo * aux;
	int cantidadImagenes = 0;
	if(colaVacia()) {
		cantidadImagenes = 0;
	}else {
		aux = colaDocumentos.principio;
		while(aux != NULL) {	
			if(aux->documento.tipoDocumento == 3 || aux->documento.tipoDocumento == 4) {
				cantidadImagenes++;
			}
			aux = aux->siguiente;
		}
	}
	return cantidadImagenes;
}

float tamanioTotalMB() {
	tApNodo * aux;
	float totalTamanio = 0.0;
	if(colaVacia()) {
		totalTamanio = 0.0;
	}else {
		aux = colaDocumentos.principio;
		while(aux != NULL) {	
			//procesar el nodo
			totalTamanio = totalTamanio + aux->documento.tamanioBytes;
			aux = aux->siguiente;
		}
	}	
	return totalTamanio/1024/1024;	
}

