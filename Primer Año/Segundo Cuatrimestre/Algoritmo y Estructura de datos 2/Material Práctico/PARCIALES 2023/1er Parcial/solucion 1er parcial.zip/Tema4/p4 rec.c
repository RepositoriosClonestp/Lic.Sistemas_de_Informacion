#include<stdio.h>


typedef char tVector [5];

int contarVocal( tVector , int );

tVector vector = {'B','a','c','e','o'};
	
int main(){
	
	printf("%d", contarVocal(  vector,  5-1));
	
	return 0;
}


int contarVocal( tVector pVector, int pLongitud) {
    if (pLongitud < 0) {
        return 0; 
    }else{
    		if( pVector[pLongitud] =='a'||pVector[pLongitud] =='e'|| pVector[pLongitud] =='i'||pVector[pLongitud] =='o'||pVector[pLongitud] =='u' ){
    			 return 1 + contarVocal(pVector, pLongitud-1);
    		}else{
    			 return contarVocal(pVector , pLongitud-1);
    		}
    }
}
