#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#define TAB4 "\t\t\t\t"

typedef char tString [25];

typedef struct {
	int dni;
	tString nombre;
	tString apellido;
	int edad;
	int tipoAtencion;
	
}tDatos;

typedef struct nodo {
	tDatos datos;
	struct nodo * siguiente;
}tNodo;

typedef struct {
	tNodo * principio;
	tNodo * final;
}tPaciente ;

tPaciente cola;

/* Declaraci�n de prototipos */
void inicializarCola();
bool colaVacia( tPaciente );
void push( tDatos ); 
void pop();	
void visualizarElementos( tPaciente );
void visualizarSegunTipo( tPaciente, int );
void funcionSolicitada();
tNodo * primerElemento( tPaciente );
tDatos primerElemento2( tPaciente );

void menu();
void ingresarGenerico(int);

/* Declaraci�n de variables */

tDatos datoNulo;

tDatos dato, primeroB;
tNodo * primero;
int opcion;

tString vectorDesc[4]={"","consulta","Reparacion","extraccion"};

int main() {
	inicializarCola();
	menu();
	
	return 0;
}

/* Implementaci�n de funciones */

void ingresarOpciones(){
	printf("\t\nIngrese la opcion que desee.\n");
	printf("1-cargar cola generico\n");
	printf("2-eliminar de la cola\n");
	printf("3-Visualizar cola\n");
	printf("4-Finaliza\n");
	scanf("%d", &opcion);
}

void menu(){
	ingresarOpciones();
		while(opcion != 4){
			switch(opcion){
				case 1:
					ingresarGenerico(5);
					break;
				case 2:
					funcionSolicitada();
					break;
				case 3:
					visualizarElementos(cola);
					visualizarSegunTipo(cola,1);
					break;				
				default : printf("\n opcion incorrecta!");
				break; 
			}
			ingresarOpciones();
		}
}

void ingresarGenerico(int pCantidad){
	int i=0;
	for(i=1;i<=pCantidad;i++){
		dato.dni=i;
		char nro[20]; 
		
		sprintf(nro, "%d", i);
		strcpy(dato.nombre,"nombreTurno");	
		strcat(dato.nombre,nro);
	
		srand(i+time(NULL));
		if(i%2==0){
			dato.tipoAtencion = (rand() % (2))<1?1:2;
		}else{
			dato.tipoAtencion = (rand() % (2))<1?2:3;
		}
		 
		push( dato );
	}	
}

void inicializarCola() {
	cola.principio = NULL;
	cola.final = NULL;
	printf("Cola inicializada ... \n");	
}

bool colaVacia( tPaciente pCola ) {
	return ( pCola.principio == NULL && pCola.final == NULL );
}

void push( tDatos pDatos ) {	
	tNodo * nuevoNodo;
	nuevoNodo = (tNodo *) malloc(sizeof(tNodo));
	
	nuevoNodo->datos = pDatos;
	nuevoNodo->siguiente = NULL;
			
	if(colaVacia(cola)) {
		cola.principio = nuevoNodo;
		cola.final = nuevoNodo;
	}else {
		cola.final->siguiente = nuevoNodo;
		cola.final = nuevoNodo;
	}
	
	printf("Se inserto el elemento: %d-%s\n", pDatos.dni, pDatos.nombre);
}

void pop() {	
	if(!colaVacia(cola)){	
		tNodo * nodoSuprimir = cola.principio;		
		if ( cola.principio == cola.final ) {
			inicializarCola();
		}else {
			cola.principio = nodoSuprimir->siguiente;			
		}
		printf("Se quito el elemento: %d-%s\n", nodoSuprimir->datos.dni, nodoSuprimir->datos.nombre);
		
		free(nodoSuprimir);
		nodoSuprimir = NULL;
	} else {
		printf("No hay elementos para quitar!\n");	
	}	
}
	
void visualizarElementos( tPaciente pCola ) {
	if(colaVacia(pCola)) {
		printf("No hay elementos para visualizar!\n");	
	}else {
		tNodo * aux = pCola.principio;
		printf("\n*** ELEMENTOS EN LA COLA ***\n");
		printf("Codigo | Descripcion | Motivo\n");
		while(aux != NULL) {
			printf("%d | %s  |  %d\n", aux->datos.dni, aux->datos.nombre,aux->datos.tipoAtencion);
			aux = aux->siguiente;
		}
	}
}


void funcionSolicitada() {	
	tDatos aux = primerElemento2(cola);
	printf("%d | %s  |  %d\n", aux.dni, aux.nombre,aux.tipoAtencion);

/*
	if(!colaVacia(cola)){	
		tNodo * nodoSuprimir = cola.principio;		
		if ( cola.principio == cola.final ) {
			inicializarCola();
		}else {
			cola.principio = nodoSuprimir->siguiente;			
		}
		printf("Se quito el elemento: %d-%s\n", 
			nodoSuprimir->datos.dni, nodoSuprimir->datos.nombre);
		
		free(nodoSuprimir);
		nodoSuprimir = NULL;
	} else {
		printf("No hay elementos para quitar!\n");	
	}	
	*/
	pop();
}
	

tNodo * primerElemento( tPaciente pCola ) {
	return pCola.principio;
}

tDatos primerElemento2( tPaciente pCola ) {
	return colaVacia(pCola) == true ? datoNulo : pCola.principio->datos;	
} 


void visualizarSegunTipo( tPaciente pCola, int pTipoAtencion ) {
	int cantidad=0;
	if(colaVacia(pCola)) {
		printf("No hay elementos para visualizar segun tipo: %s!\n",vectorDesc[pTipoAtencion]);	
	}else {
		tNodo * aux = pCola.principio;
		printf("\n*** ELEMENTOS EN LA COLA segun tipo: %s ***\n",vectorDesc[pTipoAtencion]);
		printf("Codigo | Descripcion | Motivo\n");
		while(aux != NULL) {
			if(aux->datos.tipoAtencion == pTipoAtencion){
				printf("%d | %s  |  %d\n", aux->datos.dni, aux->datos.nombre,aux->datos.tipoAtencion);
				cantidad++;
			}		
			aux = aux->siguiente;
		}
	}
		printf("total %d\n", cantidad);
}

