#include<stdio.h>


typedef int tVector [5];

int multiplicarImpares( tVector , int );

tVector vector = {1,3,4,3,2};
	
int main(){
	
	printf("%d", multiplicarImpares(  vector,  5-1));
	
	return 0;
}


int multiplicarImpares( tVector pVector, int pLongitud) {
    if (pLongitud < 0) {
        return 1; 
    }else{
    		if( pVector[pLongitud] %2!=0 ){
    			 return pVector[pLongitud] * multiplicarImpares(pVector, pLongitud-1);
    		}else{
    			 return multiplicarImpares(pVector , pLongitud-1);
    		}
    }
}
