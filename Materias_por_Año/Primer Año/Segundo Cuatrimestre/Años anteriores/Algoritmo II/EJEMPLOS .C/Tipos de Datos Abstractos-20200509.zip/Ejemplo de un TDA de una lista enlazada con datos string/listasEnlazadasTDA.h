#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef char string[25];

typedef struct nodo {
	string elem;		
    struct nodo * siguiente;    
}tLista;

void InicializarLista(tLista **);
bool ListaVacia(tLista *);
void InsertarPrimero(tLista **, string);
void InsertarAdelante(tLista **, string);
void InsertarElemento(tLista **, string);
void EliminarPrimero(tLista **);
void VisualizarElementos(tLista *);
int  cantidadElementos(tLista *);
void InsertarK(tLista **, int, string);
void EliminarK(tLista **, int);
 
void InicializarLista(tLista ** lista) {	
	(*lista) = NULL;	
}

bool  ListaVacia(tLista * lista)  {	
	return (lista == NULL);
}

void InsertarPrimero(tLista ** lista, string pElem) {
	(*lista) = malloc(sizeof(tLista));
	strcpy((*lista)->elem, pElem);		
	(*lista)->siguiente = NULL;	
	printf("Primer elemento insertado!\n");
}

void InsertarAdelante(tLista ** lista, string pElem) {
	tLista * nuevoNodo;
	nuevoNodo = malloc(sizeof(tLista));	
	strcpy(nuevoNodo->elem, pElem);		
	nuevoNodo->siguiente = (*lista);		
	(*lista) = nuevoNodo;		
	printf("Elemento insertado!\n");	
}

void InsertarElemento(tLista ** lista, string pElem) {
	if (ListaVacia(*lista))
		InsertarPrimero(&(*lista),pElem);
	else
		InsertarAdelante(&(*lista), pElem);
}

void EliminarPrimero(tLista ** lista) {
	tLista * aux;
	aux = (*lista);
	if(!ListaVacia(*lista)) {
		(*lista) = (*lista)->siguiente;
		free(aux); 
		printf("Primer elemento eliminado!\n");
	} else {
		printf("No hay elementos por eliminar!\n");
	}		
}

void VisualizarElementos(tLista * lista) {
	tLista * aux; /* lo usamos para recorrer la lista */		
	aux = lista;
	if (!ListaVacia(lista)) 	{
		while(aux != NULL) {
			printf("%s ", aux->elem);
	    	aux = aux->siguiente;
		}
	 }else printf( "\nLa lista esta vacia!!\n" );
	printf("\n\n" );	
}

int cantidadElementos(tLista * lista) {
	tLista * aux; /* lo usamos para recorrer la lista */		
	aux = lista;
	int cant = 0;
	if (!ListaVacia(lista)) {
		while(aux != NULL) {
			cant = cant + 1;
	    	aux = aux->siguiente;
		}	
	}
	return cant;	
}

//inserta un elemento en la posici�n k
void InsertarK(tLista ** lista, int k, string nuevoDato) {
	tLista * nuevoNodo, * aux;
	int i; 
	aux = (*lista); 
	//El bucle avanza aux hasta el nodo k-1
	for(i = 1; i < k-1; i++) {
		aux = aux->siguiente;
	}	
	//Actualizaci�n de punteros	
  	nuevoNodo = malloc(sizeof(tLista));
	strcpy(nuevoNodo->elem, nuevoDato); 
	nuevoNodo->siguiente = aux->siguiente;
  	aux->siguiente = nuevoNodo;		
}

//elimina un elemento de la posici�n k
void EliminarK(tLista ** lista, int k) {
	tLista * nodoSuprimir, * aux;
	int i; 
	aux = (*lista); 
	
	//verificar que el k sea v�lido para el algoritmo
	//Para k=1 utilice la opcion EliminarPrimero
	if(k <= cantidadElementos(*lista) && k > 1){
		//El bucle avanza aux hasta el nodo k-1
		for(i = 1; i < k-1; i++) {
			aux = aux->siguiente;
		}	
		//Actualizaci�n de punteros	y liberar memoria	
		nodoSuprimir = aux->siguiente; 
		aux->siguiente = nodoSuprimir->siguiente; 
		free(nodoSuprimir);  
		
		printf("Elemento de la posicion %d eliminado\n", k);
	}else{
		printf("No se puede eliminar de la posicion %d.\n", k);
	}		
}



