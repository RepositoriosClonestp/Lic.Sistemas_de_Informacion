#include <stdio.h>
#include "listasEnlazadasTDA.h"

tLista * nombresGrupo1;
tLista * nombresGrupo2;

int main() {
	InicializarLista(&nombresGrupo1);
	InsertarElemento(&nombresGrupo1, "Augusto");
	InsertarElemento(&nombresGrupo1, "Brenda");
	InsertarElemento(&nombresGrupo1, "Carlos");
	
	
	InicializarLista(&nombresGrupo2);
	InsertarElemento(&nombresGrupo2, "Alan");
	InsertarElemento(&nombresGrupo2, "Boby");
	InsertarElemento(&nombresGrupo2, "Charles");
	
	printf("\nNombres del grupo 1: \n");
	VisualizarElementos(nombresGrupo1);
	printf("Nombres del grupo 2: \n");
	VisualizarElementos(nombresGrupo2);
	
	InsertarK(&nombresGrupo1, 2, "Juan");
	InsertarK(&nombresGrupo2, 2, "Joan");
	
	printf("\nNombres del grupo 1: \n");
	VisualizarElementos(nombresGrupo1);
	printf("Nombres del grupo 2: \n");
	VisualizarElementos(nombresGrupo2);
	
	EliminarK(&nombresGrupo1, 3);
	EliminarK(&nombresGrupo2, 4);
	
	printf("\nNombres del grupo 1: \n");
	VisualizarElementos(nombresGrupo1);
	printf("Nombres del grupo 2: \n");
	VisualizarElementos(nombresGrupo2);
	
	return 0;
}
