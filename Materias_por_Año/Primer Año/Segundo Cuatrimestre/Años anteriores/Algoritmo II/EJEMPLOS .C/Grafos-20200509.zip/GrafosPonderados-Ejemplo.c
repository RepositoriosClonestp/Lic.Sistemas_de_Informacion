/* Grafos Ponderados */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#define n 7

typedef int tPeso;
typedef int tVertice;

typedef struct {	 
	tVertice origen;
	tVertice destino;		
	tPeso peso;	
}tArco;
 	
typedef bool conjuntoVertices [n];
typedef tPeso conjuntoArcos [n][n];

typedef struct {	 		
	conjuntoVertices vertices;
	conjuntoArcos arcos;			
}tGrafoPonderado;

void incializarGrafo(tGrafoPonderado *);
void agregaVertice(tGrafoPonderado *, tVertice);
void agregaArcoP(tGrafoPonderado *, tArco);
void borrarVertice(tGrafoPonderado *, tVertice);
void borrarArco(tGrafoPonderado *, tArco);
int maxVertice(tGrafoPonderado *);
void visualizarMatrizPesos(tGrafoPonderado *);
void visualizarMatrizAdyacencia(tGrafoPonderado *);

tGrafoPonderado * grafo;	
tArco arco;	

int main() {	
	/* Inicializar el puntero del grafo	*/
	grafo = NULL;
	grafo = (tGrafoPonderado *) malloc(sizeof(tGrafoPonderado));
	incializarGrafo(grafo);

	agregaVertice(grafo, 1);
	agregaVertice(grafo, 2);
	agregaVertice(grafo, 3);
	
	arco.origen = 1;
	arco.destino = 2;
	arco.peso = 5;
	agregaArcoP(grafo, arco);
	
	arco.origen = 2;
	arco.destino = 3;
	arco.peso = 10;
	agregaArcoP(grafo, arco);
	
	arco.origen = 3;
	arco.destino= 3;
	arco.peso =15;
	agregaArcoP(grafo, arco);	
		
	visualizarMatrizPesos(grafo);
	visualizarMatrizAdyacencia(grafo);
	return 0;
}

void incializarGrafo(tGrafoPonderado * pGrafo) {
	int i, j;
	for (i = 1; i <= n; i++) {
		pGrafo->vertices[i] = 0;	
		for (j = 1; j <= n; j++) {		
			pGrafo->arcos[i][j]= 0;
		}	
	}
}

void agregaVertice(tGrafoPonderado * pGrafo, tVertice vert) {
	pGrafo->vertices[vert] = 1;
	printf("Se agrego el vertice %d\n", vert);
}

void agregaArcoP(tGrafoPonderado * pGrafo, tArco arc) {
	if(( pGrafo->vertices[arc.origen] == 1) && (pGrafo->vertices[arc.destino] == 1)) {
		pGrafo->arcos[arc.origen][arc.destino] = arc.peso;	
		printf("Se agrego el arco [%d, %d]\n", arc.origen, arc.destino);
	}					
}

void borrarVertice(tGrafoPonderado * pGrafo, tVertice ver) {
	pGrafo->vertices[ver] = 0;
}

void borrarArco(tGrafoPonderado * pGrafo, tArco arc) {
	pGrafo->arcos[arc.origen][arc.destino] = 0;
}

int maxVertice(tGrafoPonderado * pGrafo) {
	int i, max;
	max = 0;
	for (i = 1; i <= n; i++) {	
		if (pGrafo->vertices[i] == 1) {
			max = i;
		}				
	}
	return max;
}

void visualizarMatrizPesos(tGrafoPonderado * pGrafo) {
	int i, j, maxVer;
	printf("\nMATRIZ DE PESOS\n\n");
	maxVer = maxVertice(pGrafo);
	for (i = 1; i<= maxVer; i++) {
		for (j = 1; j<= maxVer; j++) {
			printf("%d ", pGrafo->arcos[i][j]);			
		}	
		printf("\n");
	}
}

void visualizarMatrizAdyacencia(tGrafoPonderado * pGrafo) {	
	int i, j, maxVer;
	printf("\nMATRIZ DE ADYACENCIA\n\n");
	maxVer = maxVertice(pGrafo);
	for (i = 1; i<= maxVer; i++) {
		for (j = 1; j<= maxVer; j++) {
			if (pGrafo->arcos[i][j] == 0) {
				printf("0");
			}else { printf("1"); }
			printf(" ");
		}	
		printf("\n");
	}
}

