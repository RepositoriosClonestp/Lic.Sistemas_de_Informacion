#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#define n 7

typedef int tVertice;

typedef struct {
	tVertice origen;
	tVertice destino;
}tArco;

typedef bool conjuntoVertices [n];
typedef bool conjuntoArcos [n][n];	

typedef struct {
	conjuntoVertices vertices;
	conjuntoArcos arcos;
}tGrafoNoPonderado;

void incializarGrafo(tGrafoNoPonderado *);
void agregaVertice(tGrafoNoPonderado *, tVertice);
void agregaArco(tGrafoNoPonderado *, tArco);
void borrarVertice(tGrafoNoPonderado *, tVertice);
void borrarArco(tGrafoNoPonderado *, tArco);
int maxVertice(tGrafoNoPonderado *);
void visualizarMatrizAdyacencia(tGrafoNoPonderado *);

tGrafoNoPonderado * grafo;	
tArco arco;

int main() {		
	/* Inicializar el puntero del grafo	*/
	grafo = NULL;
	grafo = (tGrafoNoPonderado *) malloc(sizeof(tGrafoNoPonderado));
	incializarGrafo(grafo);

	agregaVertice(grafo, 1);
	agregaVertice(grafo, 2);
	agregaVertice(grafo, 3);
	agregaVertice(grafo, 4);
	
	arco.origen = 1;
	arco.destino = 2;	
	agregaArco(grafo, arco);
	
	arco.origen = 2;
	arco.destino = 3;	
	agregaArco(grafo, arco);
	
	arco.origen = 3;
	arco.destino = 3;	
	agregaArco(grafo, arco);
	
	arco.origen = 3;
	arco.destino = 4;	
	agregaArco(grafo, arco);
	
	arco.origen = 4;
	arco.destino = 2;	
	agregaArco(grafo, arco);
			
	visualizarMatrizAdyacencia(grafo);
	
	return 0;
}

void incializarGrafo(tGrafoNoPonderado * pGrafo) {
	int x, y;
	
	for (x = 0; x < n; x++)	{
		pGrafo->vertices[x] = 0;			
		for (y = 0; y < n; y++)	{
			pGrafo->arcos[x][y] = 0;
		}
	}
}

void agregaVertice(tGrafoNoPonderado * pGrafo, tVertice vert) {
	pGrafo->vertices[vert] = 1;	
	printf("Se agrego el vertice %d\n", vert);
}

void agregaArco(tGrafoNoPonderado * pGrafo, tArco arc) {
	if((pGrafo->vertices[arc.origen] == 1) && (pGrafo->vertices[arc.destino] == 1)) {
		pGrafo->arcos[arc.origen][arc.destino] = 1;	
		printf("Se agrego el arco [%d, %d]\n", arc.origen, arc.destino);
	}
}

void borrarVertice(tGrafoNoPonderado * pGrafo, tVertice vert) {
	pGrafo->vertices[vert] = 0;
}

void borrarArco(tGrafoNoPonderado * pGrafo, tArco arc) {
	pGrafo->arcos[arc.origen][arc.destino] = 0;
}

int maxVertice(tGrafoNoPonderado * pGrafo) {
	int i, max;
	max = 0;
	for (i = 0; i< n; i++) {
		if (pGrafo->vertices[i] == 1) {
			max = i;
		}		
	}
	return max;
}

void visualizarMatrizAdyacencia(tGrafoNoPonderado * pGrafo) {	
	int i, j, maxVer;
	printf("\nMATRIZ DE ADYACENCIA\n\n");
	maxVer = maxVertice(pGrafo);
	for (i = 1; i<= maxVer; i++) {
		for (j = 1; j<= maxVer; j++) {
			if (pGrafo->arcos[i][j] == true) {
				printf("1");
			} else { printf("0"); }
			printf(" ");
		}	
		printf("\n");
	}
}

