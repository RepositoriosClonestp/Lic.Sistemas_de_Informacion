/*
	En un dep�sito de televisores se ubican las cajas de televisores LED 
	en pilas de hasta 20 como m�ximo. El encargado ingresa en el sistema 
	inform�tico el dato referido a las pulgadas de los distintos elevisores. 
	Se requiere listar todos los elementos apilados y contar cu�ntos son. 
	Conforme se vayan retirando de la pila (eliminado), detectar cu�l es 
	el que est� en el tope. Considere que no se podr� apilar una caja 
	grande sobre otra m�s chica.
*/
#include <stdio.h>
#include <stdbool.h>
#define max 5

typedef float tPila[max];

void inicializarPila();
void apilar(float);
void desapilar();
float cima();
bool pilaLlena();
bool pilaVacia();
int cantidadDeTV();
void visualizarElementos();
void menu(); // falta implementar el men� de opciones

tPila pilaTV;
int tope;

int main(){
	float pulgadas;
	inicializarPila();
	//usar las funciones para el manejo de la pila
	apilar(20.0);
	
	printf("Ingrese pulgadas: ");
	scanf("%f", &pulgadas);
	
	if(pulgadas<= cima()){
		apilar(pulgadas);
	}else{
		printf("No se puede colocar una tv mas grande sobre una mas chica\n");
	}
	
	visualizarElementos();
	
	printf("\nTamanio de TV de la cima= %.2f\n", cima());	
	printf("\nCantidad de TVs apiladas= %d\n", cantidadDeTV());
	
	desapilar();
	
	visualizarElementos();
	
	return 0;
}

void inicializarPila(){
	tope = -1;
	printf("Pila de TVS inicializada\n");
}

void apilar(float pPulgadas){
	if(!pilaLlena()){
		//puedo insertar
		tope++;
		pilaTV[tope] = pPulgadas;
		printf("Tv de %.2f pulgadas insertada\n", pPulgadas);
	}else{
		printf("No hay lugar para mas tvs\n");
	}
}

void desapilar(){
	if(pilaVacia()){
		printf("No hay TVs por eliminar!\n");
	}else{
		pilaTV[tope] = 0.0;
		tope--;
		printf("Elemento eliminado!\n");
	}
}

float cima(){
	return pilaTV[tope];
}

bool pilaLlena(){
	return (tope == max-1);
}

bool pilaVacia(){
	bool result = (tope == -1);
	return result;
}

int cantidadDeTV(){	
	return tope + 1;
}

void visualizarElementos(){
	int i;
	printf("Elementos en la pila:\n");
	for (i=tope; i>=0; i--){
		printf("%.2f\n", pilaTV[i]);
	}
}


