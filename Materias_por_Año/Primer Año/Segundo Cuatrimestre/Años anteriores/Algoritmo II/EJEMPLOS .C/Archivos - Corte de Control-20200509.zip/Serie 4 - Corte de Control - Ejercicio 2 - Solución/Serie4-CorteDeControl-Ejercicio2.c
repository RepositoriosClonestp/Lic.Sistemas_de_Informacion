#include <stdio.h> 
#include <string.h>
typedef struct
{	    
    int LU;
    int codMateria;
    float nota;
}tRegistroNotaAlumno;	 

tRegistroNotaAlumno regNotaAlumno, regNotaAlumnoAnt;
FILE * archivoNotas;

int cantNotas, sumaNotas, totalAlumnos;
	
void inicializacion();
void procesoCorte();
void finalizacion();

void principioCorte();
void unaNota();
void finCorte();

int main(){		
	inicializacion();	
	procesoCorte();		
	finalizacion();
}

void inicializacion()
{
	archivoNotas = fopen("examenes.dat", "rb");		
    fread(&regNotaAlumno, sizeof(tRegistroNotaAlumno), 1, archivoNotas);
    
	regNotaAlumnoAnt = regNotaAlumno;
	totalAlumnos = 0;
	printf("*** Listado de promedios ***\n");
	printf("Numero de Libreta\tNota promedio\n");
}

void procesoCorte(){
	while (!feof(archivoNotas))
	{	
		principioCorte();
	    while(!feof(archivoNotas) && regNotaAlumno.LU == regNotaAlumnoAnt.LU) 
		{			
			unaNota();
			fread(&regNotaAlumno, sizeof(tRegistroNotaAlumno), 1, archivoNotas);
		}
		finCorte();
	}
}

void principioCorte() {
	cantNotas = 0;
	sumaNotas = 0;
	totalAlumnos++;
}

void unaNota() {
	cantNotas++;
	sumaNotas = sumaNotas + regNotaAlumno.nota;
}

void finCorte() {
	printf("\t%d\t\t\t%.2f\n", regNotaAlumnoAnt.LU, (float)(sumaNotas/cantNotas));
	regNotaAlumnoAnt = regNotaAlumno;
}

void finalizacion(){
	fclose(archivoNotas);     
	printf("\nTotal de alumnos: %d", totalAlumnos);
}
