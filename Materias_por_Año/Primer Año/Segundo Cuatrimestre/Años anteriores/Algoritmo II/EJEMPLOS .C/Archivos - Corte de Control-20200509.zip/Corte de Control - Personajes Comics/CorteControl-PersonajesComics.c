/* 	Este ejercicio realiza el corte de control respecto del campo de control correspondiente al c�digo de universo
	de un archivo con datos de personajes de comics */
#include <stdio.h> 
#include <string.h>
typedef char tString[20];
typedef struct {	    
	short codUniverso; 
	tString nombrePersonaje;
	tString nombreTerrestre;
	char genero;
	char codRol;	
	short cantPeliculasAparicion; 
}tRegistroHeroes;	 

void inicializacion();
void procesoCorte();
void finalizacion();

void principioCorte();
void unHeroe();
void finCorte();

tRegistroHeroes heroe;
FILE * archivoHeroes;
short universoAnt;
int cantHeroesGrupo, cantVillanosGrupo;
int cantHeroesTotal, cantVillanosTotal;
tString universoDesc = "";

short mayorPeliGrupo;
tString mayorPersonajeGrupo = "";

int main() {		
	inicializacion();	
	procesoCorte();		
	finalizacion();
}

void inicializacion() {
	archivoHeroes = fopen("Personajes.dat", "rb");
	fread(&heroe, sizeof(tRegistroHeroes), 1, archivoHeroes);
	universoAnt = heroe.codUniverso;
	
	if(universoAnt == 1) {
		strcpy(universoDesc, "DC");
	}else{
		if(universoAnt == 2) {
			strcpy(universoDesc, "Marvel");
		}
	}
	
	printf("Informe sobre personajes de universos Dc y Marvel\n");	
	cantHeroesTotal = 0;
	cantVillanosTotal = 0;
}

void procesoCorte() {
	while(!feof(archivoHeroes)){
		principioCorte();
		while(!feof(archivoHeroes) && heroe.codUniverso == universoAnt) {
			unHeroe();
			fread(&heroe, sizeof(tRegistroHeroes), 1, archivoHeroes);
		}
		finCorte();
	}
}

void principioCorte() {
	cantHeroesGrupo = 0;
	cantVillanosGrupo = 0;
	
	mayorPeliGrupo = 0;
	strcpy(mayorPersonajeGrupo, "");
	
	printf("Detalle %s\n", universoDesc);
	printf("-----------------\n");
}

void unHeroe() {
	if(heroe.codRol == 'H'){
		cantHeroesGrupo++;
	}else{
		cantVillanosGrupo++;
	}
	
	if(heroe.cantPeliculasAparicion > mayorPeliGrupo) {
		mayorPeliGrupo = heroe.cantPeliculasAparicion;
		strcpy(mayorPersonajeGrupo, heroe.nombrePersonaje);
	}
}

void finCorte() {
	printf("Cantidad de heroes del grupo: %d\n", cantHeroesGrupo);
	printf("Cantidad de villanos del grupo: %d\n\n", cantVillanosGrupo);
	
	printf("Personaje con apariciones en mas peliculas: %s (%d) \n\n", mayorPersonajeGrupo, mayorPeliGrupo);
	
	universoAnt = heroe.codUniverso;
	if(universoAnt == 1) {
		strcpy(universoDesc, "DC");
	}else{
		if(universoAnt == 2) {
			strcpy(universoDesc, "Marvel");
		}
	}
	
	cantHeroesTotal = cantHeroesTotal + cantHeroesGrupo;
	cantVillanosTotal = cantVillanosTotal + cantVillanosGrupo;
}

void finalizacion() {
	fclose(archivoHeroes);
	
	printf("Cantidad de heroes total: %d\n", cantHeroesTotal);
	printf("Cantidad de villanos total: %d\n\n", cantVillanosTotal);
}

