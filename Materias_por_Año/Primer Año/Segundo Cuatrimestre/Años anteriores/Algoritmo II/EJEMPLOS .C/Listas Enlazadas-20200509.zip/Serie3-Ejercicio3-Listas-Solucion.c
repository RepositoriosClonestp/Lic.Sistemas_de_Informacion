#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
/*
	El departamento de alumnado necesita trabajar con los datos de los alumnos de la materia AEDII, 
	para ello implementa una lista simplemente enlazada, donde cada nodo guarda el n�mero de libreta 
	universitaria y el nombre del alumno. Se pide crear las funciones necesarias para:
	a)	Generar la lista.
	b)	Insertar el primer alumno (nodo) de la lista.
	c)	Insertar alumnos al principio de la lista.
	d)	Eliminar el primer alumno de la lista.
	e)	Insertar un alumno en una determinada posici�n dentro de la lista.
	f)	Eliminar un alumno de una determinada posici�n de la lista.
	g)	Visualizar todos los datos de los alumnos que est�n en la lista.
	Adem�s, crear una funci�n que retorne la cantidad de alumnos que contiene la lista e implementar un men� principal que contenga todos los �tems anteriormente solicitados.
*/

typedef char tString[25];

typedef struct {
	int LU;
	tString nombre;	
}tDatosAlumno;

typedef struct nodo {
	tDatosAlumno alumno;		
    struct nodo *siguiente;    
}tListaAlumnos;

tListaAlumnos * listaAlumnos;

void inicializarLista();
bool listaVacia();
void insertarPrimerAlumno(tDatosAlumno);
void insertarAlumnoAdelante(tDatosAlumno);
void insertarAlumno(tDatosAlumno);
void eliminarPrimerAlumno();
void visualizarAlumnos();
int cantidadDeAlumnos();
void insertarAlumnoSegunPosicion(tDatosAlumno, int);
void eliminarAlumnoSegunPosicion(int);
void menu(); /* Falta implementar :) */

void inicializarLista() {	
	listaAlumnos = NULL;	
}

bool  listaVacia() {	
	return (listaAlumnos == NULL);
}

void insertarPrimero(tDatosAlumno pAlumno) {
	listaAlumnos = (tListaAlumnos *) malloc(sizeof(tListaAlumnos));
	listaAlumnos->alumno = pAlumno;		
	listaAlumnos->siguiente = NULL;	
	printf("Primer alumno agregado!\n");
}

void insertarAdelante(tDatosAlumno pAlumno) {
	tListaAlumnos * nuevoNodo;
	nuevoNodo = (tListaAlumnos *) malloc(sizeof(tListaAlumnos));	
	nuevoNodo->alumno = pAlumno;		
	nuevoNodo->siguiente = listaAlumnos;		
	listaAlumnos = nuevoNodo;		
	printf("Alumno agregado!\n");
}

void insertarElemento(tDatosAlumno pAlumno) {
	if (listaAlumnos == NULL)
		insertarPrimero(pAlumno);
	else
		insertarAdelante(pAlumno);
}

void eliminarPrimero() {
	tListaAlumnos * aux;
	if(!listaVacia()) {
		aux = listaAlumnos;
		listaAlumnos = listaAlumnos->siguiente;
		free(aux); 
		printf("Primer alumno de la lista eliminado!\n");
	}else {
		printf( "\nNo existen alumnos para eliminar!!\n" );	
	}
}

void visualizarAlumnos() {
	tListaAlumnos * aux; /* lo usamos para recorrer la lista de alumnos */		
	aux = listaAlumnos;
	if (!listaVacia()) {
		printf("\nLista de alumnos:\n");	
		while(aux != NULL) 
		{
			printf("%d - %s\n", aux->alumno.LU, aux->alumno.nombre);
	    	aux = aux->siguiente;
		}
	 }else {
	 	printf( "\nNo existen alumnos en la lista!!\n" );	
	 }
	printf("\n\n" );
}

int cantidadDeAlumnos() {
	tListaAlumnos * aux;
	int cantidad = 0;	
	aux = listaAlumnos;
	if (!listaVacia()) {		
		while(aux != NULL) 
		{
			cantidad++;
	    	aux = aux->siguiente;
		}
	}
	return cantidad;
}

void insertarAlumnoSegunPosicion(tDatosAlumno pAlumnoNuevo, int posicion) {
	tListaAlumnos * nuevoNodo, * aux;
	int i; 
	aux = listaAlumnos; 
	//El bucle avanza aux hasta el nodo k-1
	for(i = 1; i < posicion-1; i++) {
		aux = aux->siguiente;
	}	
	//Actualizaci�n de punteros	
  	nuevoNodo = (tListaAlumnos *) malloc(sizeof(tListaAlumnos));
	nuevoNodo->alumno = pAlumnoNuevo; 
	nuevoNodo->siguiente = aux->siguiente;
  	aux->siguiente = nuevoNodo;	
  	printf("Producto agregado en la posicion %d!\n", posicion);
}

void eliminarAlumnoSegunPosicion(int posicion) {
	tListaAlumnos * nodoSuprimir, * aux;
	int i; 
	aux = listaAlumnos; 
	
	/*  en primer lugar hay que verificar que la "posicion" sea v�lida para el algoritmo
		Para posicion=1 utilice la opcion eliminarProductoAdelante() */
	if(posicion <= cantidadDeAlumnos() && posicion > 1) {
		//El bucle avanza aux hasta el nodo posicion-1
		for(i = 1; i < posicion-1; i++) {
			aux = aux->siguiente;
		}	
		//Actualizaci�n de punteros	y liberar memoria	
		nodoSuprimir = aux->siguiente; 
		aux->siguiente = nodoSuprimir->siguiente; 
		free(nodoSuprimir);  
		
		printf("Alumno de la posicion %d eliminado!\n", posicion);
	}else{
		printf("No se puede eliminar un alumno de la posicion %d!\n", posicion);
	}		
}

int main() {	
	tDatosAlumno alumno;		
	inicializarLista();	
	printf("Lista vacia? %s\n", listaVacia() ? "si" : "no");	
	
	alumno.LU = 111;
	strcpy(alumno.nombre, "Jose");
	insertarElemento(alumno);	
	visualizarAlumnos();
	
	printf("Lista vacia? %s\n", listaVacia() ? "si" : "no");		
	
	alumno.LU = 222;
	strcpy(alumno.nombre, "Maria");
	insertarElemento(alumno);	
	
	alumno.LU = 333;
	strcpy(alumno.nombre, "Agustina");
	insertarElemento(alumno);	
		
	visualizarAlumnos();
	
	alumno.LU = 444;
	strcpy(alumno.nombre, "Mariano");
	insertarAlumnoSegunPosicion(alumno, 2);	
		
	visualizarAlumnos();
	
	eliminarPrimero();
	visualizarAlumnos();
	
	printf("Cantidad de alumnos en la lista: %d\n\n", cantidadDeAlumnos());	
	
	eliminarAlumnoSegunPosicion(3);
	visualizarAlumnos();
	eliminarPrimero();
	visualizarAlumnos();
	

	return 0;
}


