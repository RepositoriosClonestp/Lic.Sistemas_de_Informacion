#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef struct { 
	int dni;		
	char nombre[25];
}tElem;

typedef struct nodo {
	tElem datos;
    struct nodo * siguiente;    
}tPila;

tPila * pila;

void inicializarPila();
bool pilaVacia();
void apilar(tElem);
void apilar2(tElem);
void desapilar();
void visualizarElementos();
tElem cima();
tPila * cima2(); /* otra forma de implementar la funci�n cima */

void inicializarPila() {	
	pila = NULL;	
}

bool  pilaVacia() {
	return pila == NULL;
}

void apilar(tElem pDatos) {
	tPila * nuevoNodo;
	nuevoNodo = (tPila *) malloc(sizeof(tPila));	
	nuevoNodo->datos = pDatos;		
	nuevoNodo->siguiente = pila;	
	pila = nuevoNodo;			
	printf("Elemento insertado!\n");		
}

/* otra forma de apilar*/
void apilar2(tElem pDatos) {
	tPila * aux;
	aux = pila;
	pila = (tPila *) malloc(sizeof(tPila));	
	pila->datos = pDatos;		
	pila->siguiente = aux;				
	printf("Elemento insertado!\n");		
}

void desapilar() {
	tPila * nodoSuprimir;
	
	if (!pilaVacia()) {
		nodoSuprimir = pila;
		pila = pila->siguiente;
		free(nodoSuprimir); 
		printf("\nElemento de la cima eliminado!\n");
	}else{
		printf("No hay elementos para eliminar!\n");
	}	
}

void visualizarElementos() {
	tPila * aux;		
	aux = pila;
	if (!pilaVacia()) {
		printf( "\nElementos en la pila: \n" );
		while(aux != NULL) {
			printf("%d\t%s \n", aux->datos.dni, aux->datos.nombre);
	    	aux = aux->siguiente;
		}
	 }else printf( "\nLa pila esta vacia!!\n" );
	printf("\n" );
}

tElem cima() {
	return (pila->datos);	
}

/* funci�n cima pero que retorna el puntero */
tPila * cima2() {
	return pila;	
}

int main() {	
	tElem datosIngresar, datosC;
	
	inicializarPila();	
	/* Consultamos si la pila est� vac�a, al principio lo est� */
	printf("Pila vacia? %s\n", pilaVacia() ? "si" : "no");	
	
	datosIngresar.dni = 111;
	strcpy(datosIngresar.nombre, "Maria");
	
	apilar(datosIngresar);	
	
	/* 	Volvemos a consultar si la pila est� vac�a, 
		ahora no lo est� porque ya tiene un elemento */
	printf("Pila vacia? %s\n", pilaVacia() ? "si" : "no");	
	
	datosIngresar.dni = 222;
	strcpy(datosIngresar.nombre, "Jose");
	
	apilar(datosIngresar);	
	
	datosIngresar.dni = 333;
	strcpy(datosIngresar.nombre, "Juan");
	
	apilar(datosIngresar);	
	
	visualizarElementos();	
	datosC = cima();		
	printf("Elemento en la cima: %s %d \n", datosC.nombre, datosC.dni);
	
	desapilar();
	visualizarElementos();
	
	datosC = cima2()->datos;		
	printf("Elemento en la cima (usando la otra opcion): %s %d \n", datosC.nombre, datosC.dni);
	return 0;
}


