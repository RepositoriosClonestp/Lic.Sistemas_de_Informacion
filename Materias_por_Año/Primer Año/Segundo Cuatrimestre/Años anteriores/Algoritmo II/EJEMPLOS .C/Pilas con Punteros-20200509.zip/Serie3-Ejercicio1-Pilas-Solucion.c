#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef struct {
	int codProducto;
	int codRubro;
	int cantidad;
	float precioUnitario;
	char descripcion[50];
}tDatos;

typedef struct nodo {
	tDatos producto;
	struct nodo * siguiente;
}tPila;

void inicializarPila();
bool pilaVacia();
void apilar(tDatos);
void apilar2(tDatos); /* otra forma de apilar*/ 
void desapilar();
void visualizarElementos();
tDatos cima();
float montoTotalRecaudado();
void menu(); /* falta implemetar men� de opciones disponibles*/

tPila * pila;

int main() {
	tDatos datosIngresoUsuario, elementoCima;

	inicializarPila();
	printf("\n Esta vacia?  %d \n", pilaVacia());
	
	datosIngresoUsuario.codProducto = 111;
	datosIngresoUsuario.codRubro = 1;
	datosIngresoUsuario.cantidad = 5;
	datosIngresoUsuario.precioUnitario = 20.5;
	strcpy(datosIngresoUsuario.descripcion, "GALLETITAS CHOCOLINAS");
	
	apilar(datosIngresoUsuario);
	
	datosIngresoUsuario.codProducto = 222;
	datosIngresoUsuario.codRubro = 2;
	datosIngresoUsuario.cantidad = 10;
	datosIngresoUsuario.precioUnitario = 150.5;
	strcpy(datosIngresoUsuario.descripcion, "ACEITE DE OLIVA");
	
	apilar(datosIngresoUsuario);
		
	visualizarElementos();
	
	elementoCima = cima();
	
	printf("Elemento en la cima: %s\n\n", elementoCima.descripcion);
	
	printf("Monto total recaudado: $%.2f\n", montoTotalRecaudado());
	
	desapilar();
	
	visualizarElementos();
	
	return 0;
}

void inicializarPila() {
	pila = NULL;
}

bool pilaVacia() {
	return (pila == NULL);	
}

void apilar(tDatos pProducto) {
	tPila * aux;
	aux = pila;
	pila = malloc(sizeof(tPila));
	pila->producto = pProducto;
	pila->siguiente = aux;
	printf("Elemento Insertado\n");
}

/* Otra forma de apilar */
void apilar2(tDatos pProducto) {
	tPila * nuevoNodo;	
	nuevoNodo = malloc(sizeof(tPila));
	nuevoNodo->producto = pProducto;
	nuevoNodo->siguiente = pila;
	pila = nuevoNodo;
	printf("Elemento Insertado con Apilar 2\n");
}

void desapilar() {
	tPila * nodoSuprimir;
	if (pilaVacia()) {
		printf("No hay productos para eliminar\n");
	}else {
		nodoSuprimir = pila;
		pila = pila->siguiente;
		free(nodoSuprimir);
		printf("Elemento eliminado\n");
	}
}

void visualizarElementos() {
	tPila * aux;
	aux = pila;
	if (pilaVacia()) {
		printf("No hay productos para visualizar\n");
	}
	else {
		printf("*** Productos en pila ***\n");
		while (aux != NULL) {
			printf("Codigo Producto: %d\n", aux->producto.codProducto);
			printf("Codigo Rubro: %d\n", aux->producto.codRubro);
			printf("Cantidad: %d\n", aux->producto.cantidad);
			printf("Precio Unitario: $%.2f\n", aux->producto.precioUnitario);
			printf("Descripcion: %s\n\n", aux->producto.descripcion);
			
			aux = aux->siguiente;
		}
	}	
}

tDatos cima() {
	tDatos cimaAux;
	
	cimaAux.codProducto = 0;
	cimaAux.codRubro = 0;
	cimaAux.cantidad = 0;
	cimaAux.precioUnitario = 0.0;
	strcpy(cimaAux.descripcion, " ");
	
	if (!pilaVacia()) {
		cimaAux = pila->producto;	
	}
	
	return cimaAux;
}

float montoTotalRecaudado() {
	tPila * aux;
	aux = pila;
	
	float montoRetornar = 0;
	
	while (aux != NULL) {		
		montoRetornar = montoRetornar + ((int)aux->producto.cantidad * aux->producto.precioUnitario);						
		aux = aux->siguiente;
	}
	return montoRetornar;		
}


