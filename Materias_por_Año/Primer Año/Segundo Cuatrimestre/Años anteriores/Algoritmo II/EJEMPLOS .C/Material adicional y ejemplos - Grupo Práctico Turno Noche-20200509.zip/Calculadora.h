/* Interfaz (p�blica) */
float suma(float, float);
float resta(float, float);
float multiplicacion(float, float);
float division(float, float);

/* Implementaci�n (privada) */
float suma(float n1, float n2){
	return (n1 + n2);
}
float resta(float n1, float n2){
	return (n1 - n2);
}
float multiplicacion(float n1, float n2){
	return (n1 * n2);
}

float division(float n1, float n2){
	return  (n1 / n2);
}

