/* Ejemplo de Pila con Vectores */
#include <stdio.h>
#include <stdbool.h>
#define max 5

typedef int tPila [max];	

tPila pila;
int i, tope;
char elemento;

void CrearPilaVacia();
bool PilaVacia(); 
bool PilaLlena();
void Apilar(int);
void Desapilar();
int cima();
void visualizarElementos();

int main()
{
	CrearPilaVacia();	
	/*	este ejercicio no contempla el pedido de datos por teclado porque se realiz� 
		solo a manera de ejemplificar para mostrar c�mo utilizar los procedimientos y/o funciones	
	*/
	printf("Pila vacia? %s\n", PilaVacia() ? "si" : "no");	
	Apilar(1);
	printf("Pila vacia? %s\n", PilaVacia() ? "si" : "no");
	Apilar(2);
	Apilar(3);
	Apilar(4);	
	visualizarElementos();	
	Desapilar();	
	printf("Elementos en pila luego de desapilar: \n");	
	visualizarElementos();	
	printf("Elemento en la cima de la pila: %d \n\n", cima());	
	Apilar(5);	
	printf("Elementos en pila luego de agregar el 5: \n");	
	visualizarElementos();	
	Apilar(6);
	Apilar(7);		
	printf("Elementos en pila luego de agregar 6 y 7: \n");	
	visualizarElementos();	
	
	return 0;
}

void CrearPilaVacia()
{
	tope = -1;	
}

bool PilaVacia()
{
	if (tope == -1) 
		return true;
	else
		return false;
}

bool PilaLlena()
{
	if (tope == (max-1)) 
		return true;
	else
		return false;
}

void Apilar(int pElemento)
{
	if (PilaLlena() != true)
	{		
		tope = tope + 1;
		pila[tope] = pElemento;		
		printf("Elemento Insertado! %d\n", pila[tope]);
	}
	else
		printf("Pila Llena!\n");
}

void Desapilar()
{
	if (PilaVacia() == true)
		printf("Pila Vacia!!!\n");
	else
	{
		pila[tope] = 0;
		tope = tope - 1;
		printf("Elemento eliminado!!!\n");		
	}
}

int cima()
{
	return pila[tope];
}

void visualizarElementos()
{
	int i;
	printf("Elementos en pila: \n");
	for (i = 0; i <= tope; i++)
	{
		printf("%d ", pila[i]);
	}
	printf("\n\n");	
}
