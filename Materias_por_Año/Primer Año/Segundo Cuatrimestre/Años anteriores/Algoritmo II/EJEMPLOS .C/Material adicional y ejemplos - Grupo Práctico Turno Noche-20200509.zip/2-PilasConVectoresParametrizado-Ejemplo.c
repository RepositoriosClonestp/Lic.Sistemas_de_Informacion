/* Ejemplo de Pila con Vectores (Parametrizado)*/
#include <stdio.h>
#include <stdbool.h>
#define max 5

typedef int tPila [max];	

tPila pila, pila2;
int i, tope, tope2;
char elemento;

void CrearPilaVacia(int *);
bool PilaVacia(int *); 
bool PilaLlena(int * pTope);
void Apilar(tPila, int, int *);
void Desapilar(tPila, int *);
int cima(tPila, int * );
void visualizarElementos(tPila, int *);

int main()
{
	CrearPilaVacia(&tope);	
	/*	este ejercicio no contempla el pedido de datos por teclado porque se realiz� 
		solo a manera de ejemplificar para mostrar c�mo utilizar los procedimientos y/o funciones	
	*/
	printf("Pila vacia? %s\n", PilaVacia(&tope) ? "si" : "no");	
	Apilar(pila, 1, &tope);
	printf("Pila vacia? %s\n", PilaVacia(&tope) ? "si" : "no");
	Apilar(pila, 2, &tope);
	Apilar(pila, 3, &tope);
	Apilar(pila, 4, &tope);	
	visualizarElementos(pila, &tope);	
	Desapilar(pila, &tope);	
	printf("Elementos en pila luego de desapilar: \n");	
	visualizarElementos(pila, &tope);	
	printf("Elemento en la cima de la pila: %d \n\n", cima(pila, &tope));	
	Apilar(pila, 5, &tope);	
	printf("Elementos en pila luego de agregar el 5: \n");	
	visualizarElementos(pila, &tope);	
	Apilar(pila, 6, &tope);
	Apilar(pila, 7, &tope);		
	printf("Elementos en pila luego de agregar 6 y 7: \n");	
	visualizarElementos(pila, &tope);	
	
	CrearPilaVacia(&tope2);
	Apilar(pila2, 100, &tope2);
	Apilar(pila2, 200, &tope2);		
	printf("Elementos en pila 2: \n");	
	visualizarElementos(pila2, &tope2);	
	printf("Elemento en la cima de la pila 2: %d \n\n", cima(pila2, &tope2));	
	
	return 0;
}

void CrearPilaVacia(int * pTope)
{
	*pTope = -1;	
}

bool PilaVacia(int * pTope)
{
	if (*pTope == -1) 
		return true;
	else
		return false;
}

bool PilaLlena(int * pTope)
{
	if (*pTope == (max-1)) 
		return true;
	else
		return false;
}

void Apilar(tPila pPila, int pElemento, int * pTope)
{
	if (PilaLlena(pTope) != true)
	{		
		*pTope = *pTope + 1;
		pPila[*pTope] = pElemento;		
		printf("Elemento Insertado! %d\n", pPila[*pTope]);
	}
	else
		printf("Pila Llena!\n");
}

void Desapilar(tPila pPila, int * pTope)
{
	if (PilaVacia(pTope) == true)
		printf("Pila Vacia!!!\n");
	else
	{
		pPila[*pTope] = 0;
		*pTope = *pTope - 1;
		printf("Elemento eliminado!!!\n");		
	}
}

int cima(tPila pPila, int * pTope)
{
	return pPila[*pTope];
}

void visualizarElementos(tPila pPila, int * pTope)
{
	int i;
	printf("Elementos en pila: \n");
	for (i = 0; i <= *pTope; i++)
	{
		printf("%d ", pPila[i]);
	}
	printf("\n\n");	
}
