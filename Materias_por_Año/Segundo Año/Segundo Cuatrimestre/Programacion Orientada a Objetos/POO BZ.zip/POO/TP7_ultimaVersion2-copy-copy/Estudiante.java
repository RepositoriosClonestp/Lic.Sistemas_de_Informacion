import java.util.ArrayList;
/**
 * Write a description of class Estudiante here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Estudiante extends Socio
{
    private String carrera;

    public Estudiante(int p_dniSocio, String p_nombre, int p_diasPrestamo, String p_carrera){
        super(p_dniSocio,p_nombre,p_diasPrestamo);
        this.setCarrera(p_carrera);
    }

    //getters y setters.
    private void setCarrera(String p_carrera){
        this.carrera = p_carrera;
    }

    public String getCarrera(){
        return this.carrera;
    }

    public boolean puedePedir(){
        boolean condi = super.puedePedir();

        if(condi == true && super.cantLibrosPrestados() <= 3){
            return true;
        }else{
            return false;
        }
    }

    public String soyDeLaClase(){
        return ("Estudiante");
    }
}
