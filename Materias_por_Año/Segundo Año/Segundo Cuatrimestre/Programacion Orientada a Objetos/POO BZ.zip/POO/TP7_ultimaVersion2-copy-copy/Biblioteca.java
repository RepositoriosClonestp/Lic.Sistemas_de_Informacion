/**
 * Class Biblioteca.
 * Representa una biblioteca con su nombre, lista de libros y lista de socios.
 * 
 * @author (tu nombre)
 * @version (29-10-24)
 */
import java.util.*;

public class Biblioteca {
    /** Atributos de la clase */
    private String nombre;
    private ArrayList <Libro> libros;
    private HashMap <Integer, Socio> socios;

    /**
     * Constructor Biblioteca
     * Inicializa la biblioteca con un nombre, un libro y un socio
     *
     * @param p_nombre Nombre de la biblioteca
     * @param p_libros Libro a agregar
     * @param p_socios Socio a agregar
     */
    public Biblioteca(String p_nombre) {
        this.setNombre(p_nombre);
        this.setLibro(new ArrayList<Libro>());
        this.setSocio(new HashMap<Integer, Socio>());
    }

    /**
     * Constructor Biblioteca
     * Inicializa la biblioteca con un nombre, una lista de libros y una lista de socios
     *
     * @param p_nombre Nombre de la biblioteca
     * @param p_libros Lista de libros de la biblioteca
     * @param p_socios Lista de socios de la biblioteca
     */
    public Biblioteca(String p_nombre, ArrayList<Libro> p_libros, HashMap<Integer, Socio> p_socios) {
        this.setNombre(p_nombre);
        this.setLibro(p_libros);
        this.setSocio(p_socios);
    }

    /** Accesors (Setters) */
    private void setNombre(String p_nombre) {
        this.nombre = p_nombre;
    }

    private void setLibro(ArrayList<Libro> p_libro) {
        this.libros = p_libro;
    }

    private void setSocio(HashMap<Integer, Socio> p_socio) {
        this.socios = p_socio;
    }

    /** Accesors (Getters) */
    public String getNombre() {
        return this.nombre;
    }

    public ArrayList <Libro> getLibro() {
        return this.libros;
    }

    public HashMap <Integer, Socio> getSocio() {
        return this.socios;
    }

    public boolean agregarLibro(Libro p_libro){
        return this.getLibro().add(p_libro);
    }

    public boolean quitarLibro(Libro p_libro){
        return this.getLibro().remove(p_libro);
    }

    public void agregarSocio(Socio p_socio){
        this.getSocio().put(new Integer(p_socio.getDniSocio()),p_socio);
    }

    public Socio quitarSocio(int p_dni){
        return (Socio)this.getSocio().remove(new Integer(p_dni));
    }

    public void nuevoLibro(String p_titulo, int p_edicion, String p_editorial, int p_anio){
        Libro libro = new Libro(p_titulo, p_edicion,p_editorial, p_anio);
        System.out.println("Libro "+p_titulo+ " - Edicion: "+p_edicion+ " - Editorial:"+p_editorial+ " - Año: "+p_anio);
        if (libros.contains(p_titulo)){
            System.out.println("Ya pertenece a la biblioteca \n ");          
        }else{
            this.agregarLibro(libro);
            System.out.println("Fue agregado a la biblioteca");
        }
    }

    public void nuevoSocioEstudiante(int p_dniSocio, String p_nombre, String p_carrera){
        Estudiante estudiante = new Estudiante(p_dniSocio, p_nombre, 20, p_carrera);
        System.out.println("Dni: "+p_dniSocio+ " - Socio: "+p_nombre+ " - Carrera: "+p_carrera);
        if (socios.containsKey(p_dniSocio)){
            System.out.println("Estudiante: " +p_nombre+" ya es socio");
        }else{
            this.agregarSocio(estudiante);
            System.out.println("Estudiante: " +p_nombre+" fue agregado");
        } 
    }

    public void nuevoSocioDocente(int p_dniSocio, String p_nombre, String p_carrera){

        Docente docente = new Docente(p_dniSocio, p_nombre, 20, p_carrera);
        System.out.println("Dni: "+p_dniSocio+ " - Socio: "+p_nombre+ " - Carrera: "+p_carrera);
        if (socios.containsKey(p_dniSocio)){
            System.out.println("Docente: " +p_nombre+ " ya es socio");
        }else{
            this.agregarSocio(docente);
            System.out.println("Docente: " +p_nombre+ " fue agregado");
        } 
    }
    
    public boolean prestarLibro(Calendar p_fechaRetiro, Socio p_socio, Libro p_libro) {
        Calendar fechaDev = Calendar.getInstance();
        boolean resp = false;

        if (p_socio != null) {
            if(p_socio.equals("Estudiante")){
                fechaDev.add( Calendar.DAY_OF_MONTH, 20);

            }else{
                if(p_socio.equals("Docente")){
                    fechaDev.add(Calendar.DAY_OF_MONTH, 5);
                }
            }
            if (p_socio.puedePedir() && !p_libro.prestado()) {
                p_socio.agregarPrestamo(new Prestamo(p_libro, p_socio, p_fechaRetiro, fechaDev));
                p_libro.agregarPrestamo(new Prestamo(p_libro, p_socio, p_fechaRetiro, fechaDev));
                resp = true;
            } 
            resp = false;
        } 
        return resp;
    }
  

    public void devolverLibro(Libro p_libro) throws LibroNoPrestadoException {
        //Calendar fechaHoy = Calendar.getInstance(); 
        if (!p_libro.prestado()) {
            throw new LibroNoPrestadoException ("El libro" + p_libro.getTitulo() + "\t no se puede prestar ya que se encuentra en la biblioteca"); 
        } else {
            for (Libro unLibro: this.getLibro()) {
                for (Prestamo unPrestamo: unLibro.getPrestamos()) {
                    if(unPrestamo.getLibro().equals(p_libro)) {
                        unLibro.removePrestamo(unPrestamo);
                    }
                }

            }
        }
        throw new LibroNoPrestadoException ("El libro" + p_libro.getTitulo() + "no tiene el prestamo solicitado");
    }

    public Socio buscarSocio(int p_dni){
        return (Socio)this.getSocio().get(new Integer(p_dni));
    }

    public int cantidadDeSociosPorTipo(String p_objeto){
        int cant = 0;

        for(Socio socio : this.getSocio().values()){
            if(socio.soyDeLaClase().equalsIgnoreCase(p_objeto)){
                cant += 1;
            }
        }
        return cant;
    }

    /**Si la fecha de devolucion es anterior a la fecha*/
    public ArrayList <Prestamo> prestamosVencidos(){
        ArrayList <Prestamo> prestamosVencidos = new ArrayList<>();
        Calendar fecha = new GregorianCalendar();

        for(Libro libro : this.getLibro()){
            for(Prestamo prestamo : libro.getPrestamos()){
                if(prestamo.vencido(fecha) == true){
                    prestamosVencidos.add(prestamo);
                }

            }   
        }
        return prestamosVencidos;
    }

    public ArrayList <Docente> docentesResponsables(){
        ArrayList <Docente> docentesResp = new ArrayList<>();

        for(Socio socio: this.getSocio().values()){
            if (socio.soyDeLaClase().equals("Docente")) {
                Docente unDocente = (Docente)socio;
                if(unDocente.esResponsable() == true){
                docentesResp.add(unDocente);
                }
            }
        }
        return docentesResp;
    }

    /*public String quienTieneElLibro(Libro p_libro) throws LibroNoPrestadoException {
    if (p_libro.prestado())
    return p_libro.getPrestamos().getSocio().getNombre(); 
    throw new LibroNoPrestadoException("El libro '" + p_libro.getTitulo() + "' se encuentra en la biblioteca\n");
    }*/
    public String quienTieneElLibro(Libro p_libro) throws LibroNoPrestadoException {
        // Verificamos si el libro está prestado
        if (!p_libro.prestado()) {
            throw new LibroNoPrestadoException("El libro '" + p_libro.getTitulo() + "' se encuentra en la biblioteca\n");
        }

        // Si el libro está prestado, buscamos el último préstamo para obtener el socio
        ArrayList<Prestamo> prestamos = p_libro.getPrestamos();
        if (!prestamos.isEmpty()) {
            Prestamo ultimoPrestamo = prestamos.get(prestamos.size() - 1);
            return ultimoPrestamo.getSocios().getNombre(); // Retornamos el nombre del socio
        }

        // Si no se encontró ningún préstamo (aunque debería encontrarse si el libro está prestado)
        throw new LibroNoPrestadoException("No se encontró información sobre quién tiene el libro '" + p_libro.getTitulo() + "'");
    }

    public String listaDocentesResponsables(){
        String listaResp = ""; 
        for (Docente docResponsable: this.docentesResponsables()) {
            listaResp = listaResp + docResponsable.toString(); 
        }
        return listaResp; 
    }

    public String listaDeSocios(){
        StringBuilder listaS = new StringBuilder(); 
        for (Map.Entry <Integer,Socio> mos: socios.entrySet()) {
            listaS.append("D.N.I: ").append(mos.getKey()).append("||").append(mos.getValue().getNombre()).append("\t||").append("Libros Prestados:").append(mos.getValue().cantLibrosPrestados()).append("\n\n");
        }
        return listaS.toString();
    }


    public String listaDeLibros() {
        int i=0; 
        String listaL = ""; 
        for (Libro unLibro: this.getLibro()) {
            i++;
            if (!unLibro.prestado()){
                listaL = listaL + i  +")" + "Titulo: " + unLibro.getTitulo() + "\t||Prestado (NO)" + "\n\n";
                continue; 
            } else {
                listaL = listaL + i +")" + "Titulo: " + unLibro.getTitulo()+ "\t||Prestado (SI)" + "\n\n";
            }
        }
        return listaL;
    }

    public String listaDeTitulos () {
        int i = 0; 
        String listaTitulos = ""; 
        for (Libro unLibro:this.getLibro()){
            i++;
            listaTitulos = listaTitulos + i +")"+ unLibro.toString() + ",\t Editorial: " + unLibro.getEditorial() + ",\tEdicion" + unLibro.getEdicion() + ",\tAño de Publicacion: " + unLibro.getAnio() + "\n";
        }
        return listaTitulos; 
    }

}

