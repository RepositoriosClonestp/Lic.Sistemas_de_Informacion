
/**
 * Write a description of class EjecutableBiblioteca here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.*;
public class EjecutableBiblioteca
{
    public static void main(String [] args){
        /**Fecha para prueba prestamos NO vencidos*/
        Calendar fecha1 = Calendar.getInstance();
        fecha1.set(Calendar.YEAR, 2023);
        fecha1.set(Calendar.MONTH, Calendar.NOVEMBER); 
        fecha1.set(Calendar.DAY_OF_MONTH, 9);
        
        Calendar fecha3 = Calendar.getInstance();
        fecha3.set(Calendar.YEAR, 2023);
        fecha3.set(Calendar.MONTH, Calendar.SEPTEMBER); 
        fecha3.set(Calendar.DAY_OF_MONTH, 6);
        
        /**Fecha para prueba prestamos vencidos*/
        Calendar fecha2 = Calendar.getInstance();
        fecha2.set(Calendar.YEAR, 2024);
        fecha2.set(Calendar.MONTH, Calendar.OCTOBER); 
        fecha2.set(Calendar.DAY_OF_MONTH, 20);

        
        /**Instanciacion de Biblioteca*/
        Biblioteca b1 = new Biblioteca("Biblioteca Mariño");
        
        /**Agrega nuevo libros a la biblioteca*/
        b1.nuevoLibro("JAVA. Como Programar", 2002, "TechIn", 2010);
        b1.nuevoLibro("Longman. Diccionario Pocket", 1999, "husua", 2001);
        b1.nuevoLibro("Microcontroladores", 2005, "BlueOcean", 2020);
        b1.nuevoLibro("Ciencia de Datos", 2000, "Bugambilia", 2015);
        b1.nuevoLibro("Herramientas de Aprendizaje", 2007, "Santa Lucia", 2021);
        b1.nuevoLibro("Enciclopedia de Plantas", 2003, "Naturals", 2019);
        b1.nuevoLibro("Monografia Alan Turing", 2004, "Locred", 2010);
        
        /**Se instancian nuevos objetos de la clase Docente**/
        b1.nuevoSocioDocente(40123456,"Carlos Gutierrez","Fisica");
        b1.nuevoSocioDocente(30147852,"Soledad Gomez"," Ingles");
        b1.nuevoSocioDocente(41258745," Mariano Bondar","Algebra");
        
        /**Se instancian nuevos objetos de la clase Estudiante**/
        b1.nuevoSocioEstudiante(43124568, "Sol Solis ", "Lic. Sistemas");
        b1.nuevoSocioEstudiante(44147852, "Daiana Esquivel", "Ing. Industrial");
        b1.nuevoSocioEstudiante(42147852, "Luis Montoya", "Artes Combinadas");

    
        /**Se recupera valor de los libros, asignandolos a una variable*/
        Libro libro1 = b1.getLibro().get(0); 
        Libro libro2 = b1.getLibro().get(1); 
        Libro libro3 = b1.getLibro().get(2); 
        Libro libro4 = b1.getLibro().get(3); 
        Libro libro5 = b1.getLibro().get(4); 
        Libro libro6 = b1.getLibro().get(5); 
        Libro libro7 = b1.getLibro().get(6);
            
        /**Se recupera valor de los socios Docentes*/
        Docente socioDocente1 = (Docente) b1.getSocio().get(40123456); 
        Docente socioDocente2 = (Docente) b1.getSocio().get(30147852); 
        Docente socioDocente3 = (Docente) b1.getSocio().get(41258745); 
        
        /**Asignar prestamo de libro a Docente*/
        boolean prestarDoc1 = b1.prestarLibro(fecha1, socioDocente1, libro1);
        boolean prestarDoc2 = b1.prestarLibro(fecha3, socioDocente2, libro2);
        boolean prestarDoc3 = b1.prestarLibro(fecha2, socioDocente3, libro3);/*Se le asigna fecha bastante anterior a la actual para probar metodo de vencimiento*/
        //boolean prestado = b1.prestarLibro(fecha1, socio, libro1);
        
        /**Se recupera valor de los socios Estudiantes*/
        Estudiante socioEstudiante1 = (Estudiante) b1.getSocio().get(43124568); 
        Estudiante socioEstudiante2 = (Estudiante) b1.getSocio().get(44147852); 
        Estudiante socioEstudiante3 = (Estudiante) b1.getSocio().get(42147852); 

        /**Asignar prestamo de libro a Docente*/
        boolean prestarAlum1 = b1.prestarLibro(fecha1, socioEstudiante1, libro4);
        boolean prestarAlum2 = b1.prestarLibro(fecha1, socioEstudiante2, libro5);
        boolean prestarAlum3 = b1.prestarLibro(fecha2, socioEstudiante3, libro6); /**Se le asigna fecha bastante anterior a la actual para probar metodo de vencimiento*/
        
         /**Caso de prueba en el cual el libro se encuentra en la biblioteca (no se presto)*/
        try {
            b1.quienTieneElLibro(libro7);
        } catch (LibroNoPrestadoException excp) {
            System.out.println(excp.getMessage());
        }  

        /**Caso de prueba devolucion de libro (El libro se encuentra prestado)*/
        /*try {
            b1.devolverLibro(libro1);
        } catch (LibroNoPrestadoException excp) {
            System.out.println(excp.getMessage());
        }

        /**Caso de prueba devolucion de libro (El libro NO se encuentra prestado)*/
        /*try {
            b1.devolverLibro(libro7);
        } catch (LibroNoPrestadoException excp) {
            System.out.println(excp.getMessage());
        }*/
        
         /**Caso de prueba en el que se desea prestar un libro que ya se encuentra prestado. 
           En este caso el socioEstudiante2 tiene en su poder el libro5
           el cual el socioEstudiante1 quiere pedir prestado a la biblioteca.*/
        b1.prestarLibro(fecha1, socioEstudiante1, libro5);
        
        
        System.out.println("\n\n**************** GESTION BIBLIOTECA  *******************\n");
        System.out.println("Cantidad de socios de tipo Estudiante: "+b1.cantidadDeSociosPorTipo("Estudiante"));
        System.out.println("----------------------------------------------------------------------------");
        
        System.out.println("Cantidad de socios de tipo Docente: "+b1.cantidadDeSociosPorTipo("Docente"));
        System.out.println("----------------------------------------------------------------------------");
                
        System.out.println("Lista de docentes que no adeudan ni han adeudo libros: "+"\n"+b1.listaDocentesResponsables());
        System.out.println("----------------------------------------------------------------------------\n");
        
        System.out.println("Lista de Prestamos Vencidos: \n" +b1.prestamosVencidos());
        System.out.println("----------------------------------------------------------------------------\n");
         
        System.out.println("\nLista de libros: " +"\n"+b1.listaDeLibros());
        System.out.println("----------------------------------------------------------------------------\n");
        
        System.out.println("Lista de socios: " +"\n"+b1.listaDeSocios());
        System.out.println("----------------------------------------------------------------------------\n");
        
        System.out.println("Lista de Titulos disponibles en la Biblioteca:" + "\n" +b1.listaDeTitulos());
        System.out.println("----------------------------------------------------------------------------\n");
        
        System.out.println("Busqueda de socios a traves de su DNI: \n");
        System.out.println("El socio con el dni n° 43124568 es: " +b1.buscarSocio(43124568) );
        System.out.println("El socio con el dni n° 30147852 es: " +b1.buscarSocio(30147852) );
        System.out.println("El socio con el dni n° 42147852 es: " +b1.buscarSocio(42147852) );
        System.out.println("----------------------------------------------------------------------------\n");
        
        try {
            System.out.println("El libro 'JAVA. Como Programar' está en posesión de: " + b1.quienTieneElLibro(libro1));
        } catch (LibroNoPrestadoException excp) {
            System.out.println(excp.getMessage());
        }

    }
}
