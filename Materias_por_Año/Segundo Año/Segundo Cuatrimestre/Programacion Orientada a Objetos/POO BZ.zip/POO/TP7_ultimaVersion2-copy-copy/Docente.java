import java.util.ArrayList;
/**
 * Clase Docente 
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Docente extends Socio
{
    private String area;

    public Docente(int p_dniSocio, String p_nombre, int p_diasPrestamo, String p_area){
        super(p_dniSocio,p_nombre,p_diasPrestamo);
        this.setArea(p_area);
    }

    //getters y setters.
    private void setArea(String p_area){
        this.area = p_area;
    }

    public String getArea(){
        return this.area;
    }

    //
    public boolean esResponsable(){
        return this.puedePedir();
    }

    public void cambiarDiasDePrestamo(int p_dias){
        p_dias = super.getDiasPrestamo();
        if(this.esResponsable()){
            p_dias++;
        }
    }

    public boolean puedePedir(){
        boolean condi = super.puedePedir();
        if (condi == true && super.getDiasPrestamo() <= 5){
            return true;
        }
        return false;
    }

    public String soyDeLaClase(){
        return ("Docente");
    }

}
