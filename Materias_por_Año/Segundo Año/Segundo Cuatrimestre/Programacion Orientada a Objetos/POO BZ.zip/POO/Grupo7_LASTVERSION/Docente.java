import java.util.ArrayList;
import java.util.Calendar;
/**
 * La Clase Docente proporciona métodos para verificar si es un Socio responsable, aumentar días de prestamo en caso que lo sea, verificar si puede pedir
 * prestado y un retorno de String informando a qué clase de Socio pertenece.
 * 
 * @author X, Ingrid Noelí.
 * @version (7/11/24).
 */
public class Docente extends Socio
{
    private String area;
    
    /**
     * Constructor que inicializa los atributos por parametro.
     * @param p_dniSocio      DNI del Socio.
     * @param p_nombre        Nombre del Socio.
     * @param p_diasPrestamo  Días máximo de prestamo para el Socio.
     * @param p_area          Área a la que pertenece el Docente.
     */
    public Docente(int p_dniSocio, String p_nombre, int p_diasPrestamo, String p_area){
        super(p_dniSocio,p_nombre,p_diasPrestamo);
        this.setArea(p_area);
    }

    //getters y setters.
    private void setArea(String p_area){
        this.area = p_area;
    }

    public String getArea(){
        return this.area;
    }

    /**Verifica si es un Socio responsable.
     * @return un valor booleano del método puedePedir() que verifica que el Docente no tenga préstamos vencidos.
     */
    public boolean esResponsable(){
        return this.puedePedir();
    }
    
     /** Verifica si es un Socio responsable, en caso de serlo aumenta los días de prestamo.
     * @param p_dias heredado de la clase Socio, contiene la cantidad de días máximo de préstamo para el Socio.
     */
    public void cambiarDiasDePrestamo(int p_dias){
        p_dias = super.getDiasPrestamo();
        if(this.esResponsable()){
            p_dias++;
        }
    }
    
    /**
     * Verifica si el Docente nunca tuvo ni tiene un préstamo vencido para pedir un libro prestado.
     * @return boolean devolverá true en caso de que cumpla los requisitos, false en caso contrario.
     */
    public boolean puedePedir(){
        boolean condi = super.puedePedir();
        if (condi == true && super.getDiasPrestamo() <= 5){
            return true;
        }
        return false;
    }
    
    /**
     * Especificación del método abstracto soyDeLaClase(), heredado de la Clase Socio.
     * @return string de la clase de Socio.
     */
    public String soyDeLaClase(){
        return ("Docente");
    }

}
