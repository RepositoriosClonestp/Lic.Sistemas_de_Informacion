/**
 * Clase Libro de la Serie Integradora o TP7.
 *
 * @author (Zárate, Enzo Javier)
 * @version (04/11/2024)
 */

import java.util.*;

public class Libro
{
    private String titulo;
    private int edicion;
    private String editorial;
    private int anio;
    private ArrayList <Prestamo> prestamos;
    
    /**
     * Constructor para crear un libro nuevo, sin ningún prestamo
     */
    public Libro(String p_titulo, int p_edicion, String p_editorial, int p_anio){
        this.setTitulo(p_titulo);
        this.setEdicion(p_edicion);
        this.setEditorial(p_editorial);
        this.setAnio(p_anio);
        this.setPrestamo(new ArrayList<>());
    }
    
    /**
     * Constructor para ingresar un nuevo libro pero con un Array de prestamos(historial de prestamos)
     */
    public Libro(String p_titulo, int p_edicion, String p_editorial, int p_anio, ArrayList p_prestamo){
        this.setTitulo(p_titulo);
        this.setEdicion(p_edicion);
        this.setEditorial(p_editorial);
        this.setAnio(p_anio);
        this.setPrestamo(p_prestamo);
    }
    
    /**Conjunto de Setters y Getters*/
    private void setTitulo(String p_titulo){
        this.titulo = p_titulo;
    }
    
    private void setEdicion(int p_edicion){
        this.edicion = p_edicion;
    }
    
    private void setEditorial(String p_editorial){
        this.editorial = p_editorial;
    }
    
    private void setAnio(int p_anio){
        this.anio = p_anio;
    }
    
    private void setPrestamo(ArrayList<Prestamo> p_prestamo){
        this.prestamos = p_prestamo;
    }
    
    public String getTitulo(){
        return this.titulo;
    }
    
    public int getEdicion(){
        return this.edicion;
    }
    
    public String getEditorial(){
        return this.editorial;
    }
    
    public int getAnio(){
        return this.anio;
    }
    
    /**
     * Devuelve el último préstamo realizado por la Biblioteca.
     * @return El último prestamo, si es que existe dentro del ArrayList de Préstamo.
     */
    public Prestamo ultimoPrestamo(){
        if(!this.getPrestamos().isEmpty()){
            return this.getPrestamos().get(this.getPrestamos().size()-1);
        }
        return null;
    }
    
    /**
     * Devuelve todos los préstamos realizados hasta el momento.
     * @return Todos los préstamos.
     */
    public ArrayList <Prestamo> getPrestamos(){
        return this.prestamos;
    }
    
    /**
     * Remueve el objeto nulo para agregar un objeto de la colección Préstamo
     */
    public boolean agregarPrestamo(Prestamo p_prestamo){
        return this.getPrestamos().add(p_prestamo);
    }
    
    /**
     * Se agrega un valor null para especificar que el libro no tiene un prestamo realizado.
     */
    public boolean removePrestamo(Prestamo p_prestamo){
        return this.getPrestamos().remove(p_prestamo);
    }
    
    /**
     * Devuelve un valor TRUE para verificar que el libro está prestado.
     * @return TRUE si el libro está prestado
     */
    public boolean prestado(){
        boolean dato = false;
        
        for(Prestamo prest : this.getPrestamos()){
            if(this.getTitulo().equals(prest.getLibro().getTitulo())){
                dato = true;
            }
        }
        return dato;
        
        //return !(this.ultimoPrestamo() == null);
    }

    /**
     * @return Titulo del Objeto Libro y si está o no prestado
     */
    public String toString(){
        return "Titulo: "+ this.getTitulo();
    }
}