import java.util.Calendar;

/**
 * La clase Prestamo representa un préstamo de un libro a un socio en una biblioteca.
 * Cada préstamo tiene información sobre el libro prestado, el socio que lo tomó,
 * la fecha de retiro y la fecha de devolución del libro.
 * 
 * Esta clase proporciona métodos para registrar la devolución, verificar si el préstamo está vencido
 * y obtener información detallada sobre el préstamo.
 * 
 * Autor: Sanchez Morales Benjamin Delfor
 * Versión: 5/11/2024
 */
public class Prestamo {
    private Libro libro;                  
    private Socio socio;                  
    private Calendar fechaRetiro;         
    private Calendar fechaDevolucion;     

    /**
     * Constructor de la clase Prestamo. Inicializa un nuevo préstamo con el libro, el socio,
     * la fecha de retiro y la fecha de devolución especificadas.
     * 
     * @param p_libro           Libro prestado.
     * @param p_socio           Socio que toma el préstamo.
     * @param p_fechaRetiro     Fecha en la que el libro fue retirado.
     * @param p_fechaDevolucion Fecha límite para devolver el libro.
     */
    public Prestamo(Libro p_libro, Socio p_socio, Calendar p_fechaRetiro, Calendar p_fechaDevolucion) {
        this.setLibro(p_libro);
        this.setSocio(p_socio);
        this.setFechaRetiro(p_fechaRetiro);
        this.setFechaDevolucion(p_fechaDevolucion);
    }

    private void setFechaDevolucion(Calendar p_fechaRetiro){
        this.fechaDevolucion = p_fechaRetiro;
    }
    
    public Calendar getFechaDevolucion(){
        return this.fechaDevolucion;
    }
    
    /**
     * Establece el libro que se está prestando.
     * 
     * @param p_libro Libro prestado.
     */
    private void setLibro(Libro p_libro) {
        this.libro = p_libro;
    }

    /**
     * Establece el socio al que se le presta el libro.
     * 
     * @param p_socio Socio que toma el préstamo.
     */
    private void setSocio(Socio p_socio) {
        this.socio = p_socio;
    }

    /**
     * Establece la fecha de retiro del préstamo.
     * 
     * @param p_fechaRetiro Fecha en la que el libro fue retirado.
     */
    private void setFechaRetiro(Calendar p_fechaRetiro) {
        this.fechaRetiro = p_fechaRetiro;
    }

    /**
     * Obtiene el libro asociado al préstamo.
     * 
     * @return El libro prestado.
     */
    public Libro getLibro() {
        return this.libro;
    }

    /**
     * Obtiene el socio que tomó el préstamo.
     * 
     * @return El socio que recibe el préstamo.
     */
    public Socio getSocios() {
        return this.socio;
    }

    /**
     * Obtiene la fecha de retiro del préstamo.
     * 
     * @return Fecha en la que el libro fue retirado.
     */
    public Calendar getFechaRetiro() {
        return this.fechaRetiro;
    }

    /**
     * Obtiene la fecha de devolución del préstamo.
     * 
     * @return Fecha en la que el libro debe ser devuelto.
     
    public Calendar getFechaDevolucion() {
        return this.fechaDevolucion;
    }*/

    /**
     * Registra o actualiza la fecha de devolución del préstamo.
     * 
     * @param p_fecha Fecha de devolución.
     */
    public void registrarFechaDevolucion(Calendar p_fecha) {
        this.setFechaDevolucion(p_fecha);
    }

    /**
     * Verifica si el préstamo está vencido en una fecha específica.
     * 
     * @param p_fecha Fecha en la cual se evalúa si el préstamo está vencido.
     * @return true si la fecha actual es posterior a la fecha de devolución; false en caso contrario.
     */
    public boolean vencido(Calendar p_fecha) {
        return p_fecha.after(this.getFechaDevolucion());
    }

    /**
     * Representación en cadena del préstamo, incluyendo la fecha de retiro, 
     * la fecha de devolución, el título del libro y el nombre del socio.
     * 
     * @return Cadena que representa el préstamo.
     */
    public String toString() {
        return "Retiro: " + this.getFechaRetiro().getTime() + " - " +
               "Devolución: " + this.getFechaDevolucion().getTime() + "\n" +
               "Libro: " + this.libro.getTitulo() + "\n" +
               "Socio: " + this.getSocios().getNombre();
    }
}
