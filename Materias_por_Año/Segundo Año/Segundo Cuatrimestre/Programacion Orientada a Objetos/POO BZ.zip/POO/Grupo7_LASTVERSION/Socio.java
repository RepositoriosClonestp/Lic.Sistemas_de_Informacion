import java.util.ArrayList;
import java.util.Calendar;

/**
 * La clase abstracta Socio representa a un socio de una biblioteca que tiene un nombre, un DNI y
 * un conjunto de préstamos de libros. 
 * Los socios pueden tener varios préstamos y su duración máxima depende de los días permitidos
 * para el tipo de socio.
 * 
 * Esta clase cuenta con métodos para agregar y quitar préstamos, verificar si un préstamo está vencido,
 * y obtener información sobre el socio.
 * 
 * Autor: Sanchez Morales Benjamin Delfor
 * Versión: 5/11/2024
 */
public abstract class Socio {
    private ArrayList<Prestamo> prestamos; 
    private int dniSocio;                  
    private String nombre;                 
    private int diasPrestamo;              

    /**
     * Constructor de la clase Socio que inicializa los datos básicos y la lista de préstamos vacía.
     * 
     * @param p_dniSocio      DNI del socio.
     * @param p_nombre        Nombre del socio.
     * @param p_diasPrestamo  Días máximos de préstamo para el socio.
     */
    public Socio(int p_dniSocio, String p_nombre, int p_diasPrestamo) {
        this.setDniSocio(p_dniSocio);
        this.setNombre(p_nombre);
        this.setDiasPrestamo(p_diasPrestamo);
        this.setPrestamos(new ArrayList<>());
    }

    /**
     * Constructor de la clase Socio que inicializa los datos básicos y la lista de préstamos proporcionada.
     * 
     * @param p_dniSocio      DNI del socio.
     * @param p_nombre        Nombre del socio.
     * @param p_diasPrestamo  Días máximos de préstamo para el socio.
     * @param p_prestamos     Lista de préstamos actuales del socio.
     */
    public Socio(int p_dniSocio, String p_nombre, int p_diasPrestamo, ArrayList<Prestamo> p_prestamos) {
        this.setDniSocio(p_dniSocio);
        this.setNombre(p_nombre);
        this.setDiasPrestamo(p_diasPrestamo);
        this.setPrestamos(p_prestamos);
    }

    /**
     * Establece el DNI del socio.
     * 
     * @param p_dniSocio DNI del socio.
     */
    private void setDniSocio(int p_dniSocio) {
        this.dniSocio = p_dniSocio;
    }

    /**
     * Establece el nombre del socio.
     * 
     * @param p_nombre Nombre del socio.
     */
    private void setNombre(String p_nombre) {
        this.nombre = p_nombre;
    }

    /**
     * Establece la cantidad máxima de días de préstamo para el socio.
     * 
     * @param p_diasPrestamo Días máximos de préstamo permitidos para el socio.
     */
    private void setDiasPrestamo(int p_diasPrestamo) {
        this.diasPrestamo = p_diasPrestamo;
    }

    /**
     * Establece la lista de préstamos del socio.
     * 
     * @param p_prestamos Lista de préstamos del socio.
     */
    private void setPrestamos(ArrayList<Prestamo> p_prestamos) {
        this.prestamos = p_prestamos;
    }

    /**
     * Obtiene el DNI del socio.
     * 
     * @return DNI del socio.
     */
    public int getDniSocio() {
        return this.dniSocio;
    }

    /**
     * Obtiene el nombre del socio.
     * 
     * @return Nombre del socio.
     */
    public String getNombre() {
        return this.nombre;
    }

    /**
     * Obtiene la cantidad máxima de días permitidos para cada préstamo del socio.
     * 
     * @return Días máximos de préstamo.
     */
    public int getDiasPrestamo() {
        return this.diasPrestamo;
    }

    /**
     * Obtiene la lista de préstamos actuales del socio.
     * 
     * @return Lista de préstamos.
     */
    public ArrayList<Prestamo> getPrestamos() {
        return this.prestamos;
    }

    /**
     * Agrega un nuevo préstamo a la lista de préstamos del socio.
     * 
     * @param p_prestamo Préstamo a agregar.
     * @return true si el préstamo se agregó correctamente, false en caso contrario.
     */
    public boolean agregarPrestamo(Prestamo p_prestamo) {
        return this.getPrestamos().add(p_prestamo);
    }

    /**
     * Elimina un préstamo de la lista de préstamos del socio.
     * 
     * @param p_prestamo Préstamo a eliminar.
     * @return true si el préstamo se eliminó correctamente, false en caso contrario.
     */
    public boolean quitarPrestamo(Prestamo p_prestamo) {
        return this.getPrestamos().remove(p_prestamo);
    }

    /**
     * Calcula la cantidad de libros que el socio tiene actualmente en préstamo.
     * 
     * @return Cantidad de libros prestados.
     */
    public int cantLibrosPrestados() {
        return this.getPrestamos().size();
    }

    /**
     * Representación en cadena del socio, que incluye su DNI, nombre, tipo de socio
     * y la cantidad de libros prestados.
     * 
     * @return Cadena representativa del socio.
     */
    public String toString() {
        return "D.N.I: " + this.getDniSocio() + " || " + this.getNombre() + " " + this.soyDeLaClase() + "Libros Prestados: " + this.cantLibrosPrestados();
    }

    /**
     * Verifica si el socio puede pedir más préstamos. La decisión depende de si el socio
     * tiene algún préstamo vencido y además no tiene más de tres libros prestados.
     * 
     * @return true si el socio puede pedir más préstamos, false si tiene préstamos vencidos o tiene más de tres libros prestados.
     */
    public boolean puedePedir() {
        Calendar fechaActual = Calendar.getInstance();
        boolean valor = true;
        for(Prestamo pres : this.getPrestamos()){
            if(pres.vencido(fechaActual)){
                valor = false;
            }
        }
        return valor;
    }

    /**
     * Método abstracto que deberá ser implementado en las subclases para indicar
     * el tipo de socio.
     * 
     * @return Una cadena que identifica el tipo de socio.
     */
    public abstract String soyDeLaClase();
}
