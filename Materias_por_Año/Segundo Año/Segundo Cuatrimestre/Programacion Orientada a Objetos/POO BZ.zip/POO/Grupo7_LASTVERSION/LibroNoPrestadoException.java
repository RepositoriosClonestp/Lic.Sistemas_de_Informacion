/**
 * Write a description of class LibroNoPrestadoException here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LibroNoPrestadoException extends Exception 
{
    /**
     * Constructor for objects of class LibroNoPrestadoException
     */
    public LibroNoPrestadoException(String mensaje)
    {
        super(mensaje);
    }
}