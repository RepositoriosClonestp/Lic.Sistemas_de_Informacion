/**
 * Ejercicio 11.CLASE EJECUTBLE EMPRESA.
 * 
 * @author (Zimerman Benjamin, Solis Agustina) 
 * @version (6/09/24)
 */
import java.util.Scanner;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Empresa {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String op = "s";
        while (op.equalsIgnoreCase("s")) {
            System.out.println("Cuil: ");
            long cuil = scan.nextLong();

            System.out.println("Nombre: ");
            String nom = scan.next();

            System.out.println("Apellido:");
            String ape = scan.next();

            System.out.println("Sueldo Basico: ");
            double sb = scan.nextDouble();

            System.out.println("Fecha de ingreso ");
            System.out.println("Año: ");
            int anio = scan.nextInt();
            System.out.println("Mes: ");
            int mes = scan.nextInt() - 1; // Restamos 1 para que el mes sea correcto
            System.out.println("Dia: ");
            int dia = scan.nextInt();
            Calendar fI = Calendar.getInstance();
            fI.set(anio, mes, dia);
            Empleado emp = new Empleado(cuil, nom, ape, sb, fI);

            if (emp.esAniversario() == false) {
                System.out.println("No es su aniversario");
            } else {
                emp.mostrar();
            }
            System.out.println("Ingresar otro empleado?");
            op = scan.next();
        }
        System.out.println("Saliendo del programa");
        scan.close();
    }
}

