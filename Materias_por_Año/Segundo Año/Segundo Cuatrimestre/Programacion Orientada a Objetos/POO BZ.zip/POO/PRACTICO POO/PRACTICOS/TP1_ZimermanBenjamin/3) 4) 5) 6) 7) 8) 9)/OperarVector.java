/**Crear una clase denominada OperarVector que permita ingresar por teclado (Scanner) 5 notas de alumnos, las 
que serán almacenadas en un array de enteros. Calcular el promedio y determinar la mayor nota. El promedio 
debe permitir resultado con decimales (aplicar cast a los elementos enteros cuando sea necesario para obtener 
dicho resultado). Mostrar los elementos ingresados, separados por un tabulador. Mostrar el promedio y la 
mayor nota con el mensaje respectivo.*/ 
import java.util.Scanner;
public class OperarVector
{
  public static void main (String [] args){
      Scanner scanner = new Scanner (System.in);
      int [] notas = new int[5];
      int elMayor = Integer.MIN_VALUE; 
      int suma = 0;
      double promedio = 0;
      int i;
      for(i=0; i < notas.length; i++ ){
        System.out.println("Ingrese nota del alumno "+(i+1)+ ":");
        notas[i] = scanner.nextInt();
        suma += notas[i];
        if(notas [i] > elMayor){
            elMayor = notas[i];
        }
    }
      for(i= 0; i< notas.length; i++){
        System.out.println(+notas[i]+"\t");
    }
    float v1 = Float.valueOf(suma);
    promedio = v1/notas.length;
    System.out.println("Promedio: "+promedio);
    System.out.println("Mayor nota: "+elMayor);

}
}

