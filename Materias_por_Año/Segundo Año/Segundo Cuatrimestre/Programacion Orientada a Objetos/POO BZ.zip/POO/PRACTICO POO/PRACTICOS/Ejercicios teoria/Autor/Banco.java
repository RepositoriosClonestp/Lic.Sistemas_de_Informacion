public class Banco{ 
    public static void main(String arg []){ 
        
        Persona cliente_1 = new Persona(25132456, "Maria Gonzales"); 
        Persona cliente_2 = new Persona(17425236, "Juan Dominguez"); 
        
        CajaAhorro.setCantCajas(0); //inicializa el contador de cajas, antes de instanciar 
        CajaAhorro caja_1 = new CajaAhorro(cliente_1, 1000); 
        CajaAhorro caja_2 = new CajaAhorro(cliente_2); 
        
        System.out.println("Se crearon: " + CajaAhorro.cuantasCajas() + " cajas"); 
        
        caja_1.depositar(200); 
        caja_2.setSaldo(500.00); 
        caja_2.depositar(300); 
        
        cliente_1.mostrar(); 
        caja_1.mostrar(); 
        caja_2.mostrar(); 
    } 
} // fin clase Banco 