/** CLASE EJECUTABLE BANCO
 * 
 * @author (Zimerman Benjamin, Solis Agustina A.) 
 * @version (11/9/24)
 */
import java.util.*;
public class Banco {
    private String nombre;
    private int nroSucursal;
    private Localidad localidad;
    private ArrayList<Empleado> empleados;
    private ArrayList <CuentaBancaria> cuentas; 
    
    /**METODO CONSTRUCTOR: crea e inicializa objetos de la clase Banco
     * @param p_nombre: nombre del banco. 
     * @param p_localidad: ubicacion del banco. 
     * @param p_sucursal: numero de sucursal del banco. 
     * @param p_empleado: objeto de Clase Empleado, modela los empleados del banco. 
       **/
    public Banco (String p_nombre, Localidad p_localidad, int p_nroSucursal, Empleado p_empleado){
        this.setNombre(p_nombre);
        this.setLocalidad(p_localidad);
        this.setSucursal(p_nroSucursal);
        this.setEmpleados(new ArrayList <Empleado>());
        this.agregarEmpleado(p_empleado);
        this.quitarEmpleado(p_empleado);
    }
    
    /**METODO CONSTRUCTOR: crea e inicializa objetos de la clase Banco
     * @param p_nombre: nombre del banco. 
     * @param p_localidad: ubicacion del banco. 
     * @param p_sucursal: numero de sucursal del banco. 
     * @param p_empleados: ArrayList de objetos de clase Empleado. 
     */
    public Banco(String p_nombre, Localidad p_localidad, int p_nroSucursal, ArrayList<Empleado> p_empleados){
        this.setNombre(p_nombre);
        this.setLocalidad(p_localidad);
        this.setSucursal(p_nroSucursal);
        this.setEmpleados(p_empleados);
    }
    
    /**METODO CONSTRUCTOR: crea e inicializa objetos de la clase Banco
     * @param p_nombre: nombre del banco. 
     * @param p_localidad: ubicacion del banco. 
     * @param p_sucursal: numero de sucursal del banco. 
     * @param p_empleados: ArrayList de objetos de clase Empleado. 
     * @param p_cuenta: objeto de clase CuentaBancaria que modela una cuenta. 
     */
    public Banco(String p_nombre, Localidad p_localidad, int p_nroSucursal, ArrayList<Empleado> p_empleados, CuentaBancaria p_cuenta){
        this.setNombre(p_nombre);
        this.setLocalidad(p_localidad);
        this.setSucursal(p_nroSucursal);
        this.setEmpleados(p_empleados);
        this.setCuentas (new ArrayList <CuentaBancaria> ());
        this.agregarCuentaBancaria (p_cuenta);
        this.quitarCuentaBancaria(p_cuenta); 
    }
    
    /**METODO CONSTRUCTOR: crea e inicializa objetos de la clase Banco
     * @param p_nombre: nombre del banco. 
     * @param p_localidad: ubicacion del banco. 
     * @param p_sucursal: numero de sucursal del banco. 
     * @param p_empleados: ArrayList de objetos de clase Empleado. 
     * @param p_cuentas: ArrayList de objetos de clase CuentaBancaria que modela una cuenta. 
     */
    public Banco(String p_nombre, Localidad p_localidad, int p_nroSucursal, ArrayList<Empleado> p_empleados, ArrayList <CuentaBancaria> p_cuentas){
        this.setNombre(p_nombre);
        this.setLocalidad(p_localidad);
        this.setSucursal(p_nroSucursal);
        this.setEmpleados(p_empleados);
        this.setCuentas(p_cuentas); 
    }
    

    /**ACCESORS*/
    /**SETTERS*/
    private void setNombre (String p_nombre){
        this.nombre = p_nombre;
    }

    private void setLocalidad (Localidad p_localidad){
        this.localidad = p_localidad;
    }

    private void setSucursal (int p_nroSucursal){
        this.nroSucursal = p_nroSucursal;
    }

    private void setEmpleados (ArrayList <Empleado> p_empleado){
        this.empleados = p_empleado;
    }
    
    public void setCuentas (ArrayList <CuentaBancaria> p_cuentas){
        this.cuentas =p_cuentas; 
    }
    
    /**GETTERS*/
    public String getNombre(){
        return this.nombre;
    }

    public Localidad getLocalidad(){
        return this.localidad;
    }

    public int getSucursal(){
        return this.nroSucursal;
    }

    public ArrayList <Empleado> getEmpleados(){
        return this.empleados;
    }

    public ArrayList <CuentaBancaria> getCuentas() {
        return this.cuentas;
    }
    
    /**METODO agregarEmpleado(Empleado p_empleado): agrega un objeto de clase Empleado al ArrayList 
       @return el ArrayList con el objeto p_empleado ingresado como parametro
       **/
    public boolean agregarEmpleado(Empleado p_empleado){
        return this.getEmpleados().add(p_empleado);
    }
    
    /**METODO quitarEmpleado(Empleado p_empleado): remueve un objeto de clase Empleado al ArrayList 
       @return el ArrayList sin el objeto p_empleado ingresado como parametro**/
    public boolean quitarEmpleado(Empleado p_empleado){
        return this.getEmpleados().remove(p_empleado);
    }
    
    /**METODO agregarCuentaBancaria(CuentaBancaria p_cuenta): agrega un objeto de clase CuentaBancaria al ArrayList 
       @return el ArrayList con el objeto p_cuenta ingresado como parametro**/
    public boolean agregarCuentaBancaria (CuentaBancaria p_cuenta) {
        return this.getCuentas().add(p_cuenta); 
    }
    
    /**METODO quitarCuentaBancaria(CuentaBancaria p_cuenta): remueve un objeto de clase CuentaBancaria al ArrayList 
       @return el ArrayList sin el objeto p_cuenta ingresado como parametro**/
    public boolean quitarCuentaBancaria(CuentaBancaria p_cuenta) {
        return this.getCuentas().remove(p_cuenta);
    }
    
    /**METODO listarCuentasConSaldoCero(): imprime el resumen correspondiente si el saldo de la cuenta es 0**/
    public void listarCuentasConSaldoCero(){
        System.out.println ("***CUENTAS SIN SALDO***");
        System.out.println ("---Cuenta-----------Apellido y Nombre-----------");
        for (CuentaBancaria cuentas: this.getCuentas()) {
            if (cuentas.getSaldo() == 0) {
                System.out.println (cuentas.getNroCuenta() + "\t" + cuentas.getTitular().apeYNom() ); 
            }
        }
    }
    
    /**METODO cuentasSaldoActivo(): lista e imprime el resumen correspondiente si el saldo de la cuenta es mayor a 0**/
    public int cuentasSaldoActivo() {
    int contador=0;
        for (CuentaBancaria cuentas: this.getCuentas()) {
            if(cuentas.getSaldo() != 0) {
                contador= contador+1; 
            }
        }
        return contador;
    } 
  
    /**METODO listarSueldos(): recorre el array de empleados con una estructura for, imprimiendo por cada elemento empleado su atributo cuil,
       nombre, apellido, y sueldoNeto*/
    public void listarSueldos(){
        for (Empleado empleado : this.getEmpleados()) {
            double sueldoNeto = empleado.neto();
            System.out.println(empleado.getCuil()+ "\t"+ empleado.apeYNom() + "\t..................$"+sueldoNeto);
            //this.empleado.mostrarLinea();
        }
    }
    
    /**METODO sueldosAPagar(): recorre el array de empleados y acumula en la variable temporal sum la sumatoria de los sueldos
       netos de los empleados, cantidad a pagar por el banco**/
    public double sueldosAPagar(){
        double sum = 0; 
        for(int i=0; i<this.getEmpleados().size();i++){
            sum += ((Empleado)this.getEmpleados().get(i)).neto();
        }
        return sum;
    }
    
    /**Crea un HashSet de clase Persona, rpresenta a los titulares de las cuentas bancarias**/
    public HashSet<Persona> listadeTitulares() {
        HashSet<Persona> listaT = new HashSet<>(); 
        for (CuentaBancaria cuentas: this.getCuentas()) {
            listaT.add(cuentas.getTitular());
        }
        return listaT; 
    }
    
    /**METODO mostrar(): imprime por pantalla el resumen correspondiente**/
    public void mostrar(){
        System.out.println("Banco: "+this.getNombre()+ " Sucursal: "+this.getSucursal());
        System.out.println("Localidad: "+this.getLocalidad().getNombre()+ " Provincia: "+this.getLocalidad().getProvincia()+"\n");
        this.listarSueldos();
        System.out.println("Total a pagar: "+this.sueldosAPagar()); 

    }
    
    public void mostrarResumen () {
        this.mostrar(); 
        System.out.println ("\n**********************************");
        System.out.println ("RESUMEN DE CUENTAS BANCARIAS");
        System.out.println ("************************************");
        System.out.println ("Numero total de cuentas bancarias: "+this.getCuentas().size());
        System.out.println ("Cuentas Activas: "+this.cuentasSaldoActivo());
        System.out.println ("------------------------------------"); 
        this.listarCuentasConSaldoCero(); 
        System.out.println ("------------------------------------");
        System.out.println ("Listado de Clientes: "); 
        HashSet <Persona> listaTitulares = listadeTitulares(); 
        for (Persona titular : listaTitulares) {
            System.out.println (titular.apeYNom()+":");
        }
         System.out.println ("------------------------------------");
    }
}