import java.util.*;

/**Clase Pedido que contiene una lista de renglones*/
/**
 * Clase Pedido que representa un pedido con una lista de renglones.
 */
public class Pedido {

    /**
     * ATRIBUTO
     */
    private ArrayList<Renglon> renglones; 
    
    /**
     * Establece la lista de renglones del pedido.
     *
     * @param p_renglones la nueva lista de renglones
     */
    private void setRenglones(ArrayList<Renglon> p_renglones) {
        this.renglones = p_renglones;
    }

    /**
     * Obtiene la lista de renglones del pedido.
     *
     * @return la lista de renglones
     */
    public ArrayList<Renglon> getRenglones() {
        return this.renglones;
    }

    /**
     * Método principal para la ejecución del programa.
     *
     * @param args los argumentos de la línea de comandos
     */
    public static void main(String[] args) {
        Pedido pedido = new Pedido();
        
        /**Establece una nueva lista de renglones en el pedido*/
        pedido.setRenglones(new ArrayList<Renglon>());

        /**Instancias de Premium y Comun*/
        Premium p1 = new Premium(10, 25.0);
        Comun c1 = new Comun(40, 20.0);

        /**Instancia renglones con productos*/
        Renglon r1 = new Renglon(30, 100, p1);
        Renglon r2 = new Renglon(40, 50, c1);

        /**Añadir renglones a la lista del pedido*/
        pedido.getRenglones().add(r1);
        pedido.getRenglones().add(r2);

        /**Variables de control*/
        int i = 0;
        double total = 0;
        double cantidad = 0;

        /**Mostrar la cantidad de ítems en el pedido*/
        System.out.println("Pedido: ");
        System.out.println("Cantidad de ítems: " + pedido.getRenglones().size());

        /** Iterar sobre los renglones y calcular los totales*/
        for (Renglon ren : pedido.getRenglones()) {
            i++;
            System.out.println("Ítem: " + i);

            /** Método mostrar()*/
            ren.mostrar(); 

            /**Método getImporte()*/
            total += ren.getImporte();

            /**Método getCantidad()*/
            cantidad += ren.getCantidad();
            System.out.println("Precio: " + ren.getImporte());
        }

        /** Mostrar el total del pedido */
        System.out.println("---Total pedido: " + cantidad + " por un importe total de: $" + total);
    }
}
