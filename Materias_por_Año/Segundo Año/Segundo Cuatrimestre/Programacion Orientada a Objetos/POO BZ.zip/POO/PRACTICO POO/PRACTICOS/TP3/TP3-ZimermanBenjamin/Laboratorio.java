/**Clase Laboratorio: clase que modela la informacion de los Laboratorios que comercializan medicamentos con una droguería.
 * @author Zimerman Benjamin, Solis Agustina Aylen 
 * @version (27/8/24)
 */
/**DEFINICION CLASE LABORATORIO**/
public class Laboratorio{
    /**ATRIBUTOS DE LA CLASE**/ 
    private String nombre;
    private String domicilio;
    private String telefono;
    private int compraMinima;
    private int diaEntrega;
    
    /**METODO CONSTRUCTOR: crea e inicializa objetos de la clase LABORATORIO teniendo como firma 3 String y 2 int como tipo de dato
       @param p_nombre: define el nombre del laboratorio.
       @param p_domicilio: define la direccion del Laboratorio.
       @param p_telefono: define el numero de telefono del laboratorio. 
       @param p_compraMin: compra minima de articulos. 
       @param p_diaEnt: define el dia de entrega de la compra
    */
    public Laboratorio(String p_nombre, String p_domicilio, String p_telefono, int p_compraMin, int p_diaEnt){
        this.setNombre(p_nombre);
        this.setDomicilio(p_domicilio);
        this.setTelefono(p_telefono);
        this.setCompMin(p_compraMin);
        this.setDiaEnt(p_diaEnt);    
    }

    /**METODO CONSTRUCTOR: crea e inicializa objetos de la clase LABORATORIO teniendo como firma 3 String como tipo de dato
       @param p_nombre: define el nombre del laboratorio.
       @param p_domicilio: define la direccion del Laboratorio.
       @param p_telefono: define el numero de telefono del laboratorio. 
       */
    public Laboratorio(String p_nombre, String p_domicilio, String p_telefono){
        this.setNombre(p_nombre);
        this.setDomicilio(p_domicilio);
        this.setTelefono(p_telefono);
    }

    /**SETTERS*/
    /**setNombre(): modifica el valor del atributo nombre de tipo String 
       @param p_nombre: nombre del laboratorio. 
       */   
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }

    /**setDomicilio(): modifica el valor del atributo domicilio de tipo String
       @param p_domicilio: domicilio del Laboratorio
       */   
    private void setDomicilio(String p_domicilio){
        this.domicilio = p_domicilio;
    }

    /**setTelefono(): modifica el valor del atributo telefono de tipo String
       @param p_telefono: String que define el tel. del Laboratorio.
       */  
    private void setTelefono(String p_telefono){
        this.telefono = p_telefono;
    }

    /**setCompMin(): modifica el valor del atributo compramMinima de tipo int
       @param p_campraMin: define la compra minima de articulos
       */   
    private void setCompMin(int p_compraMin){
        this.compraMinima = p_compraMin;
    }

    /**setDiaEnt(): modifica el valor del atributo diaEntrega de tipo int 
       @param p_diaEnt.
       */   
    private void setDiaEnt(int p_diaEnt){
        this.diaEntrega = p_diaEnt;
    }

    /**GETTERS*/
    /**getNombre(): obtiene el valor del atributo nombre de tipo String *
       @return el nombre del Lab.*/
    public String getNombre(){
        return this.nombre;
    }

    /**getDomicilio(): obtiene el valor del atributo domicilio de tipo String *
       @return la direccion del lab. */
    public String getDomicilio(){
        return this.domicilio;
    }

    /**getTelefono(): obtiene el valor del atributo telefono de tipo  *
       @return el telefono del objeto laboratorio*/
    public String getTelefono(){
        return this.telefono;
    }

    /**getCompraMinima(): obtiene el valor del atributo compraMinima de tipo int *
       @return el numero de articulos minimos que se deben comprar del objeto laboratorio.*/
    public int getCompraMinima(){
        return this.compraMinima;
    }

    /**getDiaEntrega(): obtiene el valor del atributo diaEntrega de tipo int  *
       @return el dia de la entrega de la compra al Lab.*/
    public int getDiaEntrega(){
        return this.diaEntrega;
    }

    /**METODO EN CASO DE QUE LA EMPRESA VARIE SU POLITICA O REGLAS DE NEGOCIOS QUE PERMITEN MODIFICAR LOS ATRIBUTOS ASIGNANDOLE NUEVOS VALORES. Metodo que devuelve compra minima*/
    public void nuevaCompraMinima(int p_compraMin){
        this.getCompraMinima();
    }

    /**METODO EN CASO DE QUE LA EMPRESA VARIE SU POLITICA O REGLAS DE NEGOCIOS QUE PERMITEN MODIFICAR LOS ATRIBUTOS ASIGNANDOLE NUEVOS VALORES. Metodo que devuelve nuevo dia de entrega*/
    public void nuevoDiaEntrega(int p_diaEnt){
        this.setDiaEnt(p_diaEnt);
    }

    /**Metodo mostrar: imprime por pantalla los valores de los atributos en base al estado del objeto */
    public void mostrar(){
        System.out.println("Laboratorio: "+this.nombre);
        System.out.println("Domicilio: "+this.domicilio);
        System.out.println("Telefono: "+this.telefono);
    }
}