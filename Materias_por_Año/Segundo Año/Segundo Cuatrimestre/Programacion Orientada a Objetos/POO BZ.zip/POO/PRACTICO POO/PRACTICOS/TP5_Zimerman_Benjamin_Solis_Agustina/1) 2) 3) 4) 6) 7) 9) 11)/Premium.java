/**
 * Clase Premium que hereda de Etiqueta.
 */
public class Premium extends Etiqueta {

    /**
     * Número de colores del ítem Premium.
     */
    private int colores;

    /**
     * Constructor de la clase Premium.
     *
     * @param p_color el número de colores
     * @param p_costo el costo del ítem Premium
     */
    public Premium(int p_color, double p_costo) {
        super(p_costo);
        this.colores = p_color;
    }

    /**
     * Calcula el precio en base a la cantidad.
     *
     * @param q la cantidad
     * @return el precio calculado
     */
    public double precio(int q) {
        switch (q) {
            case 1:
                return q;
            case 2:
                return q + (q * adicional());
            case 3:
                return q + (q * adicional());
            default:
                return q + (q * adicional());
        }
    }

    /**
     * Calcula un adicional en base al número de colores.
     *
     * @return el adicional calculado
     */
    private double adicional() {
        switch (this.colores) {
            case 2:
                return 0.05;
            case 3:
                return 0.07;
            default:
                return 0.03;
        }
    }

    /**
     * Retorna el tipo de ítem.
     *
     * @return una cadena que representa el tipo de ítem
     */
    protected String tipo() {
        return "Premium";
    }

    /**
     * Retorna una representación en cadena del ítem Premium.
     *
     * @return una cadena que representa el ítem Premium
     */
    public String toString() {
        return super.toString() + " - Colores: " + this.colores;
    }
}
