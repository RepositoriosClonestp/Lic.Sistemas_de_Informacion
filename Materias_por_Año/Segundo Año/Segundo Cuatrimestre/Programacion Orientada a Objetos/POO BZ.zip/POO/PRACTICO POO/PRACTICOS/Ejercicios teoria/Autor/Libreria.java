public class Libreria{ 
    public static void main (String args[]){ 
        Capitulo cap1 = new Capitulo(1, 15); 
        Capitulo cap2 = new Capitulo(2, 14); 
        Capitulo cap3 = new Capitulo(3, 25); 
         
        Libro miLibro = new Libro("Aprendiendo POO con Java");     
        miLibro.agregarCapitulo(cap1); 
        miLibro.agregarCapitulo(cap2); 
        miLibro.agregarCapitulo(cap3); 
        miLibro.mostrar(); 
     } 
}