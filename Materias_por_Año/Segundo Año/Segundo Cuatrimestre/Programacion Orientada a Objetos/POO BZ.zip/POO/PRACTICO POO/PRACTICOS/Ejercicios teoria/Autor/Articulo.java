public class Articulo{
    private int codigo;
    private String titulo;
    private String area;
    private Autor autor;
    
    public Articulo(int p_codigo, String p_titulo, String p_area,Autor p_autor){
        this.codigo = p_codigo;
        this.titulo = p_titulo;
        this.area = p_area;
        this.setAutor(p_autor);
    }
    
    public int getCodigo(){
        return codigo;
    }
    
    public String getTitulo(){
        return titulo;    
    }
    
    public String getArea(){
        return area;
    }
    
    public Autor getAutor(){
        return autor;
    }
    
    private void setCodigo(int p_codigo){
        this.codigo = p_codigo;
    }
    
    private void setTitulo(String p_titulo){
        this.titulo = p_titulo;
    }
    
    private void setArea (String p_area){
        this.area = p_area;
    }
    
    private void setAutor (Autor p_autor){
        this.autor = p_autor;
    }
       
    public void mostrar(){
        System.out.println("Articulo: Un gen abre nuevas posibilidades");
        System.out.println("Area: "+this.getArea());
        System.out.println("Autor: "+this.getAutor().getNombre());
        System.out.println("Institucion: "+this.getAutor().getInstitucion());
        System.out.println("mail: "+this.getAutor().getMail());
    }
}
