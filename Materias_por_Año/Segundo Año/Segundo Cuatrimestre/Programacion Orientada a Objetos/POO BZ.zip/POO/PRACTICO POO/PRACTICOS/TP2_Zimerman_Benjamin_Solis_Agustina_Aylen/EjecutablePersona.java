public class EjecutablePersona{
    public static void main(String[] args){
        Persona p1 = new Persona(42135687,"Benja","Zimer", 2003);
        p1.mostrar();
    }
}