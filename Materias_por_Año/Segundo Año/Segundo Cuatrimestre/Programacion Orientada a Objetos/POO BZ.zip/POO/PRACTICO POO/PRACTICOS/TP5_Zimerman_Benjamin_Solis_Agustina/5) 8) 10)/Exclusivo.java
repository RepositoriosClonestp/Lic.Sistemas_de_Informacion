
/**
 * Write a description of class Exclusivo here.
 * 
 * @author (Solis Agustina, Zimerman Benjamin) 
 * @version (2/10/24)
 */
public class Exclusivo extends Cargo
{
    private int horasDeInvestigacion; 
    private int horasDeExtension; 

    /**
     *Metodo Constructor: crea e inicializa objetos de la clase Exclusivo, subclase de Cargo
     *@param p_nombreC: nombre del cargo
     * @param p_sueldoB: sueldo del cargo
     * @param p_anioI: año en que el profesor asumio el cargo
     * @p_horas:horas trabajadas
     * @param p_horasI: horas de investigacion
     * @param p_horasE: horas de expansion
     */
    public Exclusivo(int p_horasI, int p_horasE, String p_nombreC, double p_sueldoB, int p_anioI, int p_horas )
    {
        super(p_nombreC,p_sueldoB,p_anioI,p_horas);
        this.setHorasI(p_horasI); 
        this.setHorasE(p_horasE); 
    }

    /**ACCESORS**/
    /**setters**/
    private void setHorasI(int p_horasI) {
        this.horasDeInvestigacion = p_horasI; 
    }
    
    private void setHorasE(int p_horasE) {
        this.horasDeExtension= p_horasE; 
    }
    
    /**getters**/
    public int getHorasI() {
        return this.horasDeInvestigacion; 
    }
    
    public int getHorasE() {
        return this.horasDeExtension; 
    }
    /**public void mostrarCargo(): imprime por pantalla los detalles del cargo**/
    public void mostrarCargo() {
        super.mostrarCargo(); 
        System.out.println("----Cargo de Caracter Exclusivo----"); 
        System.out.println("Horas de investigacion: " + this.getHorasI()); 
        System.out.println ("Horas de Extension: " + this.getHorasE());
    }
}
