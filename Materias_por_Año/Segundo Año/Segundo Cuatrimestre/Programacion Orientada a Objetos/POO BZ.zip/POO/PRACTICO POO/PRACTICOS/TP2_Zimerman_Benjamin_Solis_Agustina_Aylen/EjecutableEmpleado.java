public class EjecutableEmpleado
{
   public static void main(String [] args){
       Empleado e1 = new Empleado (2045678934, "Juan", "Perez", 1000000, 2020);//argumentos
       e1.mostrar();
       e1.mostrarLinea();
    }
}
