import java.util.Scanner;
public class Circunferencia7 {
    public static void main(String[] args) {//espera reccibir argumentos
    Scanner circf = new Scanner(System.in);//crea nueva instancia de la clase scanner llamada circf
    String c = "s";
    while(c.equalsIgnoreCase("s")){
        System.out.println("Ingrese radio de circunferencia: ");
       int r = circf.nextInt();
       double perimetro = 2*Math.PI*r;
       System.out.println("Perimetro de Circunferencia: "+perimetro);
       System.out.println("Calcular otra circunferencia?(s/n)");
       c = circf.next();
    }
    circf.close();
    }
}

