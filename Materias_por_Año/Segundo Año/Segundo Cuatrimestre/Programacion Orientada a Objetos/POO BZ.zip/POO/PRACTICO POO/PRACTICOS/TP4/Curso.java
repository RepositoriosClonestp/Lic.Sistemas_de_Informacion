/** CLASE CURSO BANCO
 * 
 * @author (Zimerman Benjamin, Solis Agustina A.) 
 * @version (11/9/24)
 */
import java.util.*;
public class Curso
{
    private String nombre;
    private HashMap <Integer, Alumno> alumnos;

    public Curso(String p_nombre){
        this.setNombre(p_nombre);
        this.setAlumnos(new HashMap <Integer, Alumno>());
    }

    public Curso(String p_nombre, HashMap <Integer, Alumno> p_alumnos){
        this.setNombre(p_nombre);
        this.setAlumnos(p_alumnos);
    }

    /**ACCESORS*/
    /**SETTERS*/
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }

    private void setAlumnos(HashMap <Integer, Alumno> p_alumnos){
        this.alumnos = p_alumnos;
    }

    /**GETTERS*/
    public String getNombre(){
        return this.nombre;
    }

    public HashMap <Integer, Alumno> getAlumnos(){
        return this.alumnos;
    }

    /**this.getAlumnos(): obtiene la colecciona alumnos.
    put(new Integer(p_alumno.getLu())),p_alumno: agrega el alumno a la colecion.
    new Integer(p_alumno.getLu()) crea un objeto integer con el nro de lu del alumno, llamandolo mediante el parametro p_alumno.
    p_alumno es el valor asociado a esa clave.
    Lu seria el valor de la clave*/
    public void inscribirAlumno(Alumno p_alumno){
        this.getAlumnos().put(new Integer(p_alumno.getLu()),p_alumno);
    }

    /**(Alumno): cast conversion.
    this.getAlumnos() obtiene coleccion de alumnos.
    remove(new Integer(p_lu)) elimina el alumno asociado a la clave p_lu.
    new Integer(p_lu): crea un objeto Integer con el nro Lu.
    Luego muestr el alumno eliminado*/
    public Alumno quitarAlumno(int p_lu){
        return (Alumno)this.getAlumnos().remove(new Integer(p_lu));
    }

    public int cantidadDeAlumnos(){
        /**Metodo cantidaDeAlumnos(): muestra la cantidad de alumnos.
         * @return cantidad de objetos Alumno en el HashMap Alumno
         * int cont = 0;
        for(Map.Entry <Integer, Alumno> mos : alumnos.entrySet()){
        cont += 1;
        }
        return cont;*/
        return this.getAlumnos().size();
    }
    
    /**Metodo estaInscripto (Alumno p_alumno):Verifica si el alumno esta inscripto – Busqueda por valor 
     * @return verdadero o falso **/
    public boolean estaInscripto(Alumno p_alumno){
        return this.getAlumnos().containsValue(p_alumno);
    }
    
    /**Metodo estaInscripto (Alumno p_alumno):Verifica si el alumno esta inscripto – Busqueda por clave/Key
     * @return verdadero o falso **/
    public boolean estaInscripto(int p_lu){
        return this.getAlumnos().containsKey(new Integer (p_lu));
    }
    
    /**Metodo buscarAlumno(int p_lu): recorre el HashMap y busca el key ingresado como parametro.
     * @return el alumno que corresponde a la lu pasada como parámetro **/
    public Alumno buscarAlumno(int p_lu){
        return (Alumno)this.getAlumnos().get(new Integer(p_lu));
    }
    
    /**Metodo imprimirPromedioDelAlumno(int p_lu): imprime por pantalla el promedio del alumno **/
    public void imprimirPromedioDelAlumno(int p_lu){

        System.out.println("Promedio: "+this.buscarAlumno(p_lu).promedio());
        
    }
    
    /**mostrarInscriptos(): imprime por pantalla a los alumnos inscriptos: nombre, apellido y lu**/
    public void mostrarInscriptos(){
        for(Map.Entry <Integer, Alumno> mos : alumnos.entrySet()){
            System.out.println(mos.getKey()+ " " +mos.getValue().nomYApe());
        }
    }
    
    /**verif(int p_lu, Alumno p_alumno): verifica si el alumno esta inscripto a traves de su lu y value alumno*/
    public void verif(int p_lu, Alumno p_alumno){
        if(this.estaInscripto(p_lu) == true && this.estaInscripto(p_alumno) == true){
            System.out.println("\nAlumno encontrado");
            p_alumno.mostrar();
        }else{
            System.out.println("No se encuentra inscripto el alumno: "+p_alumno.nomYApe());
        }
    }
}
