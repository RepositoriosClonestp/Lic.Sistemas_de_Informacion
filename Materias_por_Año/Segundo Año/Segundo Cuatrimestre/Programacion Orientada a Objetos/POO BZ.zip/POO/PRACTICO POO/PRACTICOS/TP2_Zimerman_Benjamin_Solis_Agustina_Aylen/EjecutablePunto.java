public class EjecutablePunto{
    public static void main (String [] args){
        /*Punto p1 = new Punto();
        p1.mostrar();**/
        Punto p2 = new Punto(7.5, 0.5);
        p2.mostrar();
        p2.coordenadas();
    }
}
