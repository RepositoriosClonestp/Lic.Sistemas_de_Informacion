/**
 * Clase Administracion Gerencia.
 * 
 * <p>La clase Administracion Gerencia se encarga de ejecutar el programa principal que maneja la gerencia de alojamientos.</p>
 * 
 * @autor Zimerman Benjamin
 * @autor Solis Agustina A.
 * @version 28/8/24
 */
public class AdministracionGerencia {

    /**
     * Método principal para la ejecución del programa.
     * 
     * @param args los argumentos de la línea de comandos
     */
    public static void main(String[] args) {

        /**Crear servicios*/
        Servicio internet = new Servicio("Internet", 250);
        Servicio lavanderia = new Servicio("Lavanderia", 130);
        Servicio auto = new Servicio("Auto", 1300);

        /** Crear un hotel y agregar servicios*/
        Hotel h1 = new Hotel("Single", "Hotel Guarani", 10000, 7, internet);
        h1.agregarServicio(internet);
        h1.agregarServicio(lavanderia);

        /**Crear la gerencia y agregar el hotel*/
        Gerencia ger = new Gerencia("Gerencia Principal", h1);
        ger.agregarAlojamiento(h1);

        /**Crear una cabaña y agregar servicios*/
        Cabaña c1 = new Cabaña(2, "Cabaña Los Alpes", 80, 5, auto);
        c1.agregarServicio(internet);
        c1.agregarServicio(auto);

        /** Agregar la cabaña a la gerencia*/
        ger.agregarAlojamiento(c1);

        /**Mostrar la liquidación de la gerencia*/
        ger.mostrarLiquidacion();
    }
}
