/**
 *Clase EJECUTABLE EmpleadoConJefe.
 * 
 * @author (Zimerman Benjamin-Solis Agustina) 
 * @version (5/09/24)
 */
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner; 

public class EjecutableEmpConJefe
{
   public static void main(String[] args){
       //entrada por teclado de los atributos del objeto Jefe de la clase EmpleadoConJefe: 
       Scanner scan= new Scanner (System.in); 
       System.out.println ("*Ingreso de datos del Gerente*");
       
       System.out.println ("CUIL: ");
       long cuilJ = scan.nextLong(); 
       
       System.out.println("Ingrese el nombre del Gerente Responsable: ");
       String nombreJ = scan.next(); 
        scan.nextLine(); 
        
       System.out.println ("Ingrese el apellido del Gerente responsable: ");
       String apellidoJ =scan.nextLine(); 
       
       System.out.println ("Ingrese el sueldo del Gerente: ");
       double sueldoJ = scan.nextDouble(); 
       
       System.out.println ("Año de Ingreso del Gerente: ");
       int anioJ= scan.nextInt(); 
       
       //Instanciacion objeto Calendar
        Calendar fecha1 = Calendar.getInstance(); 
        fecha1.set(2004,7,8);
        //System.out.println ("año ingreso" +fecha1.get(Calendar.YEAR));
       //Instanciacion objeto Empleado de la clase EmpleadoConJefe
       System.out.println ("*Ingreso de datos del Empleado*");
       System.out.println ("Cuil del Empleado: ");
       long cuilE = scan.nextLong(); 
       
       System.out.println ("Nombre del Empleado: ");
       String nombreE = scan.next(); 
       scan.nextLine(); 
       
       System.out.println ("Apellido del Empleado: ");
       String apellidoE = scan.next();
       
       
       System.out.println ("Sueldo del empleado: ");
       double importeE = scan.nextDouble(); 
       
       //System.out.println ("Año de ingreso del empleado: ");
       //int anioE = scan.nextInt(); 
       
       //Instanciacion objetos empleado y jefe 
       EmpleadoConJefe jefe1 = new EmpleadoConJefe (cuilJ, apellidoJ, nombreJ, sueldoJ, anioJ);  
       EmpleadoConJefe empleado1 = new EmpleadoConJefe (cuilE, apellidoE, nombreE, importeE, fecha1, jefe1);
       empleado1.mostrarPantalla();
       
       if (empleado1.getE_Jefe() != null) {
           System.out.println("Responde a : "+ jefe1.apeYNom() + ",Gerente General");
       }
       
       
       
       
   }
}
