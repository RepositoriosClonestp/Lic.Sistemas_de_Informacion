
/**
 * CLASE EJECUTABLE GESTION HOSPITAL:Un hospital público brinda como servicio hacia sus pacientes, autoridades judiciales, obras sociales, etc., enviarles los 
datos filiatorios, por correo postal, al domicilio declarado donde vive.
 * 
 * @author (Zimerman Benjamin, Solis Agustina A.) 
 * @version (30/8/24)
 */
import java.util.Scanner;
public class GestionHospital{
    public static void main(String [] args){
        Scanner scan = new Scanner(System.in);
        
        /**Ingreso por teclado de los datos del paciente**/
        System.out.println("Nombre paciente: ");
        String nom = scan.next();

        System.out.println("Nro. Hist. Clin: ");
        int nro = scan.nextInt();

        System.out.println("Domicilio: ");
        String dom = scan.next();

        System.out.println("Localidad Nacido: ");
        String ln = scan.next();
        
        System.out.println("Provincia: ");
        String pn = scan.next();
        Localidad locn = new Localidad(ln, pn);

        System.out.println("Localidad Vive: ");
        String lv = scan.next();
        
        System.out.println("Provincia: ");
        String pv = scan.next();
        
        /**Instanciacion de objetos paciente y localidad */
        Localidad locv = new Localidad(lv, pv);

        Paciente pac = new Paciente(nro, nom, dom, locn, locv);
        
        /**Ingreso por teclado de los datos del hospital*/
        System.out.println("Nombre Hospital: ");
        String hosp = scan.next();

        System.out.println("Nombre Director: ");
        String dir = scan.next();
        
        pac.mostrarDatosPantalla();
    }
}
