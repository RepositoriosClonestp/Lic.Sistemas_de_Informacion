/** Permite crear y manipular una cuenta de caja de ahorro. 
  * @author Juan Perez 
  * @version 1 
  */ 
 
public class CajaAhorro{ 
    private int codigo; 
    private double saldo; 
    private Persona titular;  
    private static int cantCajas; 
     
/** Constructor sin saldo inicial. 
  * @throws No dispara ninguna excepcion. 
  */ 
    public CajaAhorro(Persona p_titular) { 
        this.setTitular(p_titular); 
        this.setSaldo(0); 
        this.setCantCajas(this.cantCajas + 1); 
        this.setCodigo(this.cantCajas); // el ultimo numero de caja creada pasa a ser el codigo 
    } 
    
/** Constructor con saldo inicial. 
  */ 
    CajaAhorro(Persona p_titular, double p_saldo) { 
        this.setTitular(p_titular); 
        this.setSaldo(p_saldo); 
        this.setCantCajas(this.cantCajas + 1); 
        this.setCodigo(this.cantCajas); 
    } 
    
/** Retorna el codigo de la cuenta. 
 *  
Licenciatura en Sistemas de Información         16                                            Prof. Cristina Greiner 
  * @return Un valor de tipo int. 
  */ 
   public int getCodigo(){ 
     return this.codigo;   
   } 
   
/** Asigna p_codigo al codigo de la cuenta. 
  * @param int p_codigo. 
  * @return No devuelve ningún valor. 
  */ 
  private void setCodigo(int p_codigo){ 
     this.codigo = p_codigo;   
  } 
/** Retorna el titular de la cuenta. 
  * @return Un objeto de tipo Persona. 
  */ 
  public Persona getTitular(){ 
     return this.titular;   
  } 
  
/** Asigna p_titular al titular de la cuenta. 
  * @param Persona p_titular. 
  */ 
  private void setTitular(Persona p_titular){ 
     this.titular = p_titular;   
  } 
/** Retorna el saldo actual de la cuenta. 
  * @return Un valor de tipo double. 
  */ 
  public double getSaldo(){ 
     return this.saldo;   
  } 
 
  public void setSaldo(double p_saldo){ 
     this.saldo = p_saldo;   
  } 
/** Agrega p_monto al saldo actual de la cuenta. 
  * @param double p_monto. 
  */ 
  public void depositar(double p_monto){ 
    this.setSaldo(this.getSaldo() + p_monto);   
  } 
 
/** Devuelve el número de cajas de ahorro creadas. 
  * @return devuelve un entero. 
  */ 
    public static int cuantasCajas () { 
        return cantCajas;   // this hace referencia a un objeto por lo tanto no  
    }                      // puede ser usada en un método static  
/** Asigna un valor a la variable de clase cantCajas. 
  * @return no retorna nada. 
  */ 
public static void setCantCajas(int p_cajasCreadas) { 
        cantCajas = p_cajasCreadas;  // this hace referencia a un objeto. No  
}                                // puede ser usada en un método static  
public void  mostrar(){ 
     System.out.println("\n" + "****  metodo mostrar() de CajaAhorro  ****");  
     this.getTitular().mostrar(); 
     System.out.println("Codigo de cuenta: " + this.getCodigo());  
     System.out.println("Saldo: "            + this.getSaldo()); 
   } 
} // fin clase CajaAhorro

