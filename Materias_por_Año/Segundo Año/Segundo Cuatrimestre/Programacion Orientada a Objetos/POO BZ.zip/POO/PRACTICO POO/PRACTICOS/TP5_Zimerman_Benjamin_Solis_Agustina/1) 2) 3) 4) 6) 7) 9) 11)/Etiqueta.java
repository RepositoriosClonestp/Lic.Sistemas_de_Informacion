/**
 * Clase abstracta Etiqueta que representa una etiqueta con un costo.
 */
public abstract class Etiqueta {

    /**
     * Costo de la etiqueta.
     */
    private double costo;

    /**
     * Constructor de la clase Etiqueta.
     *
     * @param p_costo el costo de la etiqueta
     */
    public Etiqueta(double p_costo) {
        this.setCosto(p_costo);
    }

    /**
     * Establece el costo de la etiqueta.
     *
     * @param p_costo el nuevo costo de la etiqueta
     */
    protected void setCosto(double p_costo) {
        this.costo = p_costo;
    }

    /**
     * Obtiene el costo de la etiqueta.
     *
     * @return el costo de la etiqueta
     */
    public double getCosto() {
        return this.costo;
    }

    /**
     * Método abstracto para calcular el precio en base a una cantidad.
     *
     * @param q la cantidad
     * @return el precio calculado
     */
    public abstract double precio(int q);

    /**
     * Retorna una representación en cadena de la etiqueta.
     *
     * @return una cadena que representa la etiqueta
     */
    public String toString() {
        return "Costo: " + this.getCosto();
    }

    /**
     * Método abstracto que retorna el tipo de etiqueta.
     *
     * @return el tipo de etiqueta
     */
    protected abstract String tipo();
}
