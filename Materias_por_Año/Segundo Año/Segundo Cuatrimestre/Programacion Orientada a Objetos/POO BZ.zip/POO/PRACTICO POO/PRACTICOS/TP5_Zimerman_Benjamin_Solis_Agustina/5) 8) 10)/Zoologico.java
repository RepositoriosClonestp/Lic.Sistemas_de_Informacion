
/**
 * Write a description of class Zoologico here: 
La clase Zoológico por su parte tiene la responsabilidad de agregar un visitante, calcular la recaudación en un rango 
de fechas determinado, y proveer listados de visitantes en una fecha en particular. Debe permitir listar todos los 
visitantes sin discriminar, o un tipo en particular (“Delegación” o “Individuo”.) 
 * 
 * @author (Solis Agustina, Zimerman Benjamin) 
 * @version (16/10/24)
 */
import java.util.*;
import java.util.Calendar; 
public class Zoologico{
    private String nombre;
    private ArrayList <Visitante> visitantes;
    /**Constructor for objects of class Zoologico: crea e inicializa objetos de la clase Zoologico 
     * @param p_nombre: nombre del zoologico
     * @param p_visitante: objeto colaborador de la clase Visitante que inicializa el Arraylist de visitantes
    */
    public Zoologico(String p_nombre, Visitante p_visitante ){
        this.setNombre(p_nombre);
        this.setVisitantes(new ArrayList <Visitante>());
        this.nuevoVisitante(p_visitante); 
        this.quitarVisitante(p_visitante); 
    }
     /**Constructor for objects of class Zoologico: crea e inicializa objetos de la clase Zoologico 
     * @param p_nombre: nombre del zoologico
     * @param p_visitantes: Arraylist de visitantes
    */
    public Zoologico (String p_nombre,ArrayList <Visitante> p_visitantes){
        this.setNombre(p_nombre); 
        this.setVisitantes(p_visitantes);
    }
    
    /**ACCESORS**/
    /**setters*/
    private void setNombre(String p_nombre) {
        this.nombre= p_nombre;
    }
    private void setVisitantes( ArrayList <Visitante> p_visitantes) {
        this.visitantes = p_visitantes; 
    }
    
    /**getters**/
    public String getNombre() {
        return this.nombre;
    }
    public ArrayList <Visitante> getVisitantes() {
        return this.visitantes; 
    }
    
    /**METODOS**/
    /**public boolean nuevoVisitante(Visitante p_visitante): agrega el visitante ingresado como parametro al arraylist
       @return el arraylist con el parametro añadido*/
    public boolean nuevoVisitante(Visitante p_visitante) {
        return this.getVisitantes().add(p_visitante);
    }
    /**public boolean quitarVisitante (Visitante p_visitante): quita el visitante ingresado como parametro del arraylist**/
    public boolean quitarVisitante (Visitante p_visitante) {
        return this.getVisitantes().remove(p_visitante);
    }
    
    /**public void listarTipoVisitantePorFecha(Calendar p_fecha, String p_tipoVisitante):
     * muestra un listado de los visitantes del tipo ingresado como parametro en la fecha ingresada.
       */
    public void listarTipoVisitantePorFecha(Calendar p_fecha, String p_tipoVisitante) {
        for (Visitante unVisitante: this.getVisitantes()) {
            if (unVisitante.getFecha().compareTo(p_fecha) == 0 && unVisitante.tipoVisitante().equals(p_tipoVisitante)) {
                unVisitante.mostrar();
            }
        }
    }
    /**listarPorFecha(Calendar p_fecha, String p_visitante): metodo publico que muestra un listado de los individuos del ArrayList
     * que visitaron el zoologico en una fecha determinada.
       **/
    public void listarVisitantePorFecha(Calendar p_fecha) {
      for (Visitante unVisitante: this.getVisitantes()) {
          if (unVisitante.getFecha().compareTo(p_fecha) == 0) {
              unVisitante.mostrar(); 
          }
      }
    }
    
    /** public double recaudacion (Calendar p_fechaDesde, Calendar p_fechaHasta): metodo publico que calcula
         el monto total recaudado en un periodo de tiempo delimitado por dos fechas ingresadas como parametro
         @return el total recaudado
       **/
    public double recaudacion (Calendar p_fechaDesde, Calendar p_fechaHasta){
       double total = 0;
        for (Visitante unVisitante: this.getVisitantes()){
           if (!unVisitante.getFecha().before(p_fechaDesde) && !unVisitante.getFecha().after(p_fechaHasta)){
               total+=unVisitante.entrada(); 
           }
       }
       return total;
    }
     
    /** @override
       *public HashSet <Persona> listarPersona(): crea un HashSet con los individuos que conforman a la delegacion
       *@return listaVisitantes;
       */
    public HashSet <Persona> listarPersonasQueVisitaronElZoo() {
        HashSet <Persona> listaVisitantes = new HashSet<>();
        for (Visitante unVisitante:this.getVisitantes()) {
            listaVisitantes.addAll(unVisitante.listarPersona());
        }
        return listaVisitantes;
    }
}

    

