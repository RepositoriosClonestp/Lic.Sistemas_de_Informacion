 
/** Permite crear y manipular un objeto persona 
  * @author Juan Perez 
  */ 
public class Persona{ 
   private int dni; 
   private String nombre; 
    
   Persona(int p_dni, String p_nombre){ 
       this.setDni(p_dni); 
       this.setNombre(p_nombre); 
   } 
   private void setDni(int p_dni){ 
            this.dni = p_dni; 
   } 
   public int getDni(){ 
            return this.dni; 
   } 
   private void setNombre(String p_nombre){ 
            this.nombre = p_nombre; 
   } 
 
   public String getNombre(){ 
            return this.nombre; 
   } 
 
   /** Permite visualizar en pantalla las características de un objeto persona 
    */ 
   public void  mostrar(){ 
        System.out.println("*****   metodo mostrar() de Persona   *****");  
        System.out.println("DNI: "    + this.getDni());  
        System.out.println("Nombre: " + this.getNombre()); 
   } 
} // fin clase Persona 