
/**DEFINICION CLASE PUNTO**/

public class Punto{
    /**ATRIBUTOS DE LA CLASE**/
    private double x;
    private double y;
    /**METODO CONSTRUCTOR: crea e inicializa objetos de la clase Punto**/
    public Punto(){
        this.x = 0;
        this.y = 0;
    }
    /**METODO CONSTRUCTOR Punto (double x_p, double y_p): crea e inicializa objetos de la clase Punto**/
    public Punto(double x_p, double y_p){
        this.setX(x_p);
        this.setY(y_p);
    }
    
    /**SETTERS**/
    /**setX: permite modificar el valor del atributo x de tipo double**/
    private void setX(double x_p){
        this.x = x_p;
    }
    /**setY: permite modificar el valor del atributo y de tipo double**/
    private void setY(double y_p){
       this.y = y_p;
    }
    /**GETTERS**/
    /**getX: permite obtener el valor del atributo x de tipo double**/
    public double getX(){
        return x;
    }
    /**getY: permite obtener el valor del atributo y de tipo double**/
    public double getY(){
        return y;
    }
    /**METODO desplazar(double p_dx, double p_dy): metodo publico que permite actualizar los valores de x e y al desplazarlos (suma los valores x + p_dx e y+p_dy) **/
    public void desplazar(double p_dx, double p_dy){
        this.setX(this.getX() + p_dx);
        this.setY(this.getY() + p_dy);
    }
    /**METODO coordenadas (): asiga al atributo cadena un string que concatena los valores de los atributos x e y y lo devuelve**/
    public String coordenadas(){
        String cadena = "(" +this.getX()+ ", "+this.getY()+ ")";
        System.out.println(cadena);
        return cadena ;
    }
    
    /**METODO mostrar (): metodo publico que imprime por pantalla el string "Punto x: (valor de x) y:(valor de y)"**/
    public void mostrar(){
        System.out.println("Punto. X: "+this.getX()+ " Y: "+this.getY());
    }
}
