/**
 * CLASE elipse:
 * 
 * <p>La clase Elipse representa una elipse con un semieje mayor y un semieje menor específicos.</p>
 * 
 * @autor Zimerman Benjamin
 * @autor Solis Agustina Aylen
 * @version 2/10/24
 */
public class Elipse extends FiguraGeometrica {

    /**
     * Semieje mayor de la elipse.
     */
    private double sEjeMayor;

    /**
     * Semieje menor de la elipse.
     */
    private double sEjeMenor;

    /**
     * Constructor de la clase Elipse.
     * 
     * @param p_Centro el punto central de la elipse
     * @param p_EjeMayor el semieje mayor de la elipse
     * @param p_EjeMenor el semieje menor de la elipse
     */
    public Elipse(Punto p_Centro, double p_EjeMayor, double p_EjeMenor) {
        super(p_Centro);
        this.setSEjeMayor(p_EjeMayor);
        this.setSEjeMenor(p_EjeMenor);
    }

    /**
     * Establece el semieje mayor de la elipse.
     * 
     * @param p_EjeMayor el nuevo semieje mayor
     */
    private void setSEjeMayor(double p_EjeMayor) {
        this.sEjeMayor = p_EjeMayor;
    }

    /**
     * Establece el semieje menor de la elipse.
     * 
     * @param p_EjeMenor el nuevo semieje menor
     */
    private void setSEjeMenor(double p_EjeMenor) {
        this.sEjeMenor = p_EjeMenor;
    }

    /**
     * Obtiene el semieje mayor de la elipse.
     * 
     * @return el semieje mayor de la elipse
     */
    public double getSEjeMayor() {
        return this.sEjeMayor;
    }

    /**
     * Obtiene el semieje menor de la elipse.
     * 
     * @return el semieje menor de la elipse
     */
    public double getSEjeMenor() {
        return this.sEjeMenor;
    }

    /**
     * Retorna el nombre de la figura.
     * 
     * @return el nombre de la figura
     */
    public String nombreFigura() {
        System.out.println("*****Elipse*****");
        return "Elipse";
    }

    /**
     * Muestra las características de la elipse.
     */
    public void caracteristicas() {
        System.out.println("Centro: " + super.getOrigen().coordenadas() + " - Semieje Mayor: " + this.getSEjeMayor() + " - Semieje Menor: " + this.getSEjeMenor());
        System.out.println("Superficie: " + superficie());
    }

    /**
     * Calcula la superficie de la elipse.
     * 
     * @return la superficie de la elipse
     */
    public double superficie() {
        return Math.PI * this.getSEjeMayor() * this.getSEjeMenor();
    }

    /**
     * Permite desplazar la elipse a una nueva posición (X,Y) sin cambiar sus dimensiones.
     * 
     * @param p_dx la coordenada X del punto a donde se va a desplazar la elipse
     * @param p_dy la coordenada Y del punto a donde se va a desplazar la elipse
     */
    public void desplazar(double p_dx, double p_dy) {
        Punto origen = super.getOrigen();
        Punto newOrigen = new Punto(origen.getX() + p_dx, origen.getY() + p_dy);
        super.setOrigen(newOrigen);
    }

    /**
     * Obtiene la distancia entre las coordenadas de dos elipses en base a Pitágoras.
     * 
     * @param otraElipse el objeto auxiliar de la clase Elipse
     * @return la distancia entre la elipse emisor del mensaje y la nueva elipse auxiliar ingresada como parámetro
     */
    public double distanciaA(Elipse otraElipse) {
        Punto or1 = this.getOrigen();
        Punto or2 = otraElipse.getOrigen();
        double dx = or1.getX() - or2.getX();
        double dy = or1.getY() - or2.getY();
        double distancia = (Math.sqrt((Math.pow(dx, 2)) + (Math.pow(dy, 2))));
        return distancia;
    }

    /**
     * Devuelve la elipse mayor en base al análisis de sus superficies.
     * 
     * @param otraElipse el objeto auxiliar de la clase Elipse
     * @return la elipse de mayor superficie
     */
    public Elipse elMayor(Elipse otraElipse) {
        double rec1 = this.superficie();
        double rec2 = otraElipse.superficie();
        if (rec1 > rec2) {
            return this;
        } else {
            return otraElipse;
        }
    }
}
