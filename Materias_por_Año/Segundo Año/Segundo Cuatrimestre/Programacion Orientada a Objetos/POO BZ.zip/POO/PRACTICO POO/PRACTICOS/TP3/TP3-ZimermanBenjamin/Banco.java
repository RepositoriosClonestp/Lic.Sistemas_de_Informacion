/** CLASE EJECUTABLE BANCO
 * 
 * @author (Zimerman Benjamin, Solis Agustina A.) 
 * @version (28/8/24)
 */
import java.util.Scanner;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Banco {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        /**Ingreso por teclado de datos Cuenta Corriente y Caja de Ahorro */
        System.out.println("Nro de Cuenta: ");
        int nro = scan.nextInt();
        //scan.nextLine(); 

        System.out.println("\nSaldo: ");
        double sal = scan.nextDouble();
        //scan.nextLine();

        System.out.println ("\nImporte");
        double p_importe =scan.nextDouble(); 

        //Ingreso de datos Persona//
        System.out.println ("\n DNI: ");
        int dni= scan.nextInt(); 

        System.out.println("\nNombre: ");
        String nombre = scan.next();

        System.out.println("\nApellido:");
        String apellido = scan.next();
        scan.nextLine(); 

        System.out.println("\n Año de nacimiento"); 
        int año = scan.nextInt(); 
        scan.nextLine(); 

        /**Instanciacion objetos de la clase Persona,Fecha de Nacimiento, Caja de Ahorro y Cuenta Corriente*/
        Calendar fecha1 = Calendar.getInstance(); 
        fecha1.set(2024,9,7); 
        Persona tit = new Persona(dni, nombre, apellido, fecha1);
        CajaDeAhorro cda = new CajaDeAhorro(nro, tit, sal);
        CuentaCorriente ccor = new CuentaCorriente (nro, tit, sal,500.0);  

        /**MENU BANCO: se le solicita al usuario que ingrese por teclado si desea operar su Caja de Ahorro o Cuenta Corrinte, 
        luego, se le solicita ingresar cual de las operaciones disponibles desea realizar para activar los metodos correspondientes 
        de las clases CajaDeAhorro o CuentaCorriente.
         */ 
        System.out.println("\n\t***BANCO***");
        System.out.println ("Seleccione qué desea operar: a-Caja de ahorro, b-Cuenta Corriente");
        String p_cuenta = scan.next(); 
        scan.nextLine(); 

        boolean continuar = true;

        if (p_cuenta == "a") {
            while (continuar) {
                System.out.println("\nOpciones:");
                System.out.println("1) Depositar");
                System.out.println("2) Extraer");
                System.out.println("3) Salir");

                System.out.print("Ingrese una opcion: ");
                int opcion = scan.nextInt();
                scan.nextLine(); 

                switch (opcion) {
                    case 1:
                        System.out.print("Ingrese el monto a depositar: ");
                        double deposito = scan.nextDouble();
                        scan.nextLine(); 
                        cda.depositar(deposito);
                        cda.mostrar();

                        break;
                    case 2:
                        System.out.print("Ingrese el monto a extraer: ");
                        double extraccion = scan.nextDouble();
                        scan.nextLine(); 
                        cda.extraer(extraccion);
                        cda.mostrar();

                        break;
                    case 3:
                        continuar = false;
                        break;
                    default:
                        System.out.println("Opcion invalida. Intente nuevamente.");
                }
            }

        } else {
            while (continuar) {
                System.out.println("\nOpciones:");
                System.out.println("1) Depositar");
                System.out.println("2) Extraer");
                System.out.println("3) Salir");

                System.out.print("Ingrese una opcion: ");
                int opcion = scan.nextInt();

                switch (opcion) {
                    case 1: 
                        System.out.println ("Ha seleccionado realizar un Deposito en la Cuenta Corriente");
                        ccor.depositar(p_importe); 
                        ccor.mostrar(); 
                        break;

                    case 2: 
                        System.out.println ("Ha selecionado realizar una Extraccion en la Cuenta Corriente");
                        ccor.extraer(p_importe); 
                        ccor.mostrar(); 
                        break;

                    case 3:
                        continuar = false;
                        break;
                    default:
                        System.out.println("Opcion invalida. Intente nuevamente.");

                }
            }
        }
        scan.close(); 

        /**METODO esCumpleaños: si el metodo esCumpleaños es true, envia al usuario una tarjeta de feliz cumpleaños*/
        if(tit.esCumpleaños()) {
            System.out.println("FELIZ CUMPLEAÑOS!");
        }
    }
}
