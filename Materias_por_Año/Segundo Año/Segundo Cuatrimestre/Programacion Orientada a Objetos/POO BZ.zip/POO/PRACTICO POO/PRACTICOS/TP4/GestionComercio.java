
/**
 * Write a description of class GestionComercio here: clase ejecutable Comercio
 * 
 * @author (Solis Agustina, Zimerman Benjamin) 
 * @version (12/09/24)
 */
import java.util.*;
import java.util.Scanner;
public class GestionComercio
{
    public static void main (String [] args) {
        Comercio comercio1 = new Comercio ("Avanti SRL");
        Empleado e1 = new Empleado (1234567, "Juan", "Gonzalez", 60000, 2000); 
        Empleado e2 = new Empleado (5678342, "Horacio", "Morales", 50000, 1990); 
        Empleado e3= new Empleado (2569874, "Maria", "Jimenez", 35000, 2010); 
        Empleado e4 = new Empleado(3569853, "Luisa", "Perez", 40500, 2014); 
        
        comercio1.altaEmpleado(e1); 
        comercio1.altaEmpleado(e2); 
        comercio1.altaEmpleado(e3); 
        comercio1.altaEmpleado(e4); 
        
        comercio1.nomina();  
        
    }
}
