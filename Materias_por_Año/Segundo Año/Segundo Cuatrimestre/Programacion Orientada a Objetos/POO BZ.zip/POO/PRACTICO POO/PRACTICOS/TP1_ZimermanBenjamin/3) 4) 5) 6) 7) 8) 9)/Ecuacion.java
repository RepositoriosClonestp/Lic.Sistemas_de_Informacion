public class Ecuacion {
    public static void main(String[] args) {
        double pa = Double.parseDouble(args[0]);
        double pb = Double.parseDouble(args[1]);
        double pc = Double.parseDouble(args[2]);
        double d = (Math.pow(pb, 2) - (4 * pa * pc));
        double x1 = ((-pb + Math.sqrt(d)) / (2 * pa));
        double x2= ((-pb - Math.sqrt(d)) / (2 * pa));
        if (d < 0) {
            System.out.println("Nro imaginario");
        } else if (d > 0) {
        System.out.println("X1= " + x1 + " X2= " + x2);
        } else {
            System.out.println("Raiz única: " +x1);
        }
    }
} 