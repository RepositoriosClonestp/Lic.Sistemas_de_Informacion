public class PruebaArray { 
     public static void main (String[] args) { 
        // Arrays de objetos: 
        Numero[] a; // Referencia Null 
        Numero[] b = new Numero[5]; // Referencias Null 
        Numero[] c = new Numero[4]; 
        for (int i = 0; i < c.length; i++){ 
            c[i] = new Numero(); 
        } 
        // Inicialización de agregados: 
        Numero [] d = {new Numero(), new Numero(), new Numero()}; 
 
        // Inicialización dinámica de agregados: 
        a = new Numero[] {new Numero(), new Numero()}; 
        System.out.println("a.length = " + a.length); 
        System.out.println("b.length = " + b.length) ; 
        // Las referencias internas del array se inicializan automáticamente a null 
        for (int i = 0; i < b. length; i++){ 
            System.out.println ("b[" + i + "] = " + b[i]); 
        } 
        System.out.println ("c.length = " + c.length) ; 
        System.out.println ("d.length = " + d.length) ; 
        a = d; 
        System.out.println ("a.length = " + a.length) ; 
        // Arrays de datos primitivos: 
        int[] e = new int [0]; // Referencia null 
        int[] f = new int[5]; 
        int[] g = new int[4]; 
        for(int i = 0; i < g.length; i++){ 
            g[i] = i*i; 
        } 
        int[] h = { 11, 47, 93 } ; 
          System.out.println("e.length=" + e.length);  
                // Los datos primitivos de dentro del array se inicializan automáticamente a cero 
        for (int i = 0; i < f .length; i++){ 
            System.out.println ("f[" + i + "] = " + f[i]); 
        } 
        System.out.println ("g.length = " + g.length) ; 
        System.out.println ("h.length = " + h.length) ; 
        e = h; 
        System.out.println ("e.length = " + e.length) ; 
        e = new int[] { 1, 2 }; 
        System.out.println("e.1ength = " + e.length); 
    } 
}