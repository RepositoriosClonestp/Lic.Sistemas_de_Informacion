/**
 * Clase CuentaCorriente.
 * 
 * @author (Zimerman Benjamin-Solis Agustina) 
 * @version (1/09/24)
 */
public class CuentaCorriente extends CuentaBancaria{
    /**ATRIBUTOS**/
    private double limiteDescubierto; 

    /**METODOS CONSTRUCTORES: permiten crear e instanciar objetos de la clase CuentaCorriente
     * @param int p_nroCuenta: numero de la cuenta corriente. 
     * @param p_titular: objeto de la clase persona que contiene la informacion del tirular(nombre completo, dni, fecha de nacimiento)
     */
    public CuentaCorriente(int p_nroCuenta, Persona p_titular){
        super(p_nroCuenta, p_titular);
        this.setLimiteDescubierto(500.0); 
    }

    /**METODOS CONSTRUCTORES: permiten crear e instanciar objetos de la clase CuentaCorriente
     * @param int p_nroCuenta: numero de la cuenta corriente. 
     * @param p_titular: objeto de la clase persona que contiene la informacion del tirular(nombre completo, dni, fecha de nacimiento)
     * @param p_saldo: importe del saldo disponible en la cuenta corriente. 
     * @param p_limiteDescubierto: limite descubierto de la cuenta corriente
     */
    public CuentaCorriente(int p_nroCuenta, Persona p_titular, double p_saldo, double p_limiteDescubierto){
        super(p_nroCuenta, p_titular, p_saldo, p_limiteDescubierto); 
        this.setLimiteDescubierto(500.0); 
    }

    /**ACCESORS**/
    /**SETTERS: permiten modificar el estado de los atributos**/
    private void setLimiteDescubierto (double p_limite){
        this.limiteDescubierto = p_limite; 
    }

    /**GETTERS: permiten obtener el estado de los atributos y los devuelve**/
    public double getLimiteDescubierto(){
        return this.limiteDescubierto; 
    }

    /**METODO PUEDE EXTRAER: devuelve true si la suma del saldo y el limite descubierto es mayor al importe a retirar
     * @param p_importe: importe de dinero que se desea depositar.
     * @return true si la suma del saldo y el limite descubierto es mayor al importe a retirar
     **/
    protected boolean puedeExtraer(double p_importe) {
        if ((super.getSaldo() + this.getLimiteDescubierto()) > p_importe)
            return true; 
        else{
            return false; 
        }
    }
    
    /**METODO EXTRACCION:actualiza el valor del saldo al restarle el valor del importe ingresado como parametro 
     * @param p_importe: monto que se desea extraer.
     **/
    public void extraccion(double p_importe) {
        super.setSaldo(super.getSaldo() - p_importe);
    }

    /**METODO EXTRAER: si el metodo puedeExtraer() retorna true, activa el metodo extraccion(),que resta del importe del saldo el importe ingresado como parametro.
     * @param p_importe: importe del dinero que se desea extraer. 
     * @return el saldo final luego de realizada la extraccion
     **/
  
    public String xQueNoPuedeExtraer (double p_importe){
        if (puedeExtraer(p_importe) != true){
            String ss = ("El importe de extraccion sobrepasa el limite descubierto!");
            return ss;
        }else{
            return "ERROR";
        }
    }

    /**METODO DEPOSITAR(p_importe): agrega el importe ingresado al saldo actual
     * @param p_importe: importe de dinero que se desea depositar.
     */
    public double depositar(double p_importe){
        double d = super.depositar(p_importe);
        return d;
    }

    /**metodo mostrar(): imprime por pantalla los datos del titular*/
    public void mostrar () {
        System.out.println ("-\tCuenta Corriente \t-");
        System.out.println ("Nro.Cuenta:"+ super.getNroCuenta() + "-\tSaldo" + this.getSaldo()); 
        System.out.println ("Titular: "+super.getTitular().apeYNom());
        System.out.println("Descubierto" +this.getLimiteDescubierto());
    }
}

