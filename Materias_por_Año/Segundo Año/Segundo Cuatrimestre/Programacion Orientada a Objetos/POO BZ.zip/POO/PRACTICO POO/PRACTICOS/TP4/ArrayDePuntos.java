
/**
 * Ejercicio 1. ArraysDePuntos. Crear contenedor estatico de 6 elementos.
 * @author Zimerman Benjamin, Solis Agustina Aylen 
 * @version (11/9/24)
 */
import java.util.Scanner;
import java.util.*;
public class ArrayDePuntos
{
    public static void main (String [] args){
        Punto [] puntos = new Punto [6]; 
        Scanner scan = new Scanner(System.in);
        for(int i = 0; i < 6; i++){
            System.out.println("Ingrese coordenada X del punto "+(i+1));
            double x = scan.nextDouble();
            System.out.println("Ingrese coordenada Y del punto "+(i+1));
            double y = scan.nextDouble();
            puntos[i] = new Punto(x, y);
        }
        
        for (Punto punto : puntos) {
            System.out.println("Coordenadas: " + punto.coordenadas());
        }
        
        for (int i = 0; i < puntos.length-1; i++) {
            double distancia = puntos[i].distanciaA(puntos[i + 1]);
            System.out.println("Distancia entre punto " + (i + 1) + " y punto " + (i + 2) + ": " + distancia);
        }

    }

}
