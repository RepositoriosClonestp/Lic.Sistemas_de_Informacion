/**
 * CLASE PACIENTE
 * 
 * @author (Zimerman Benjamin, Solis Agustina A.) 
 * @version (30/8/24)
 */
public class Paciente{
    /**ATRIBUTOS*/
    private int historiaClinica;
    private String nombre;
    private String domicilio;
    private Localidad localidadNacido;
    private Localidad localidadVive;
    
    /**METODO CONSTRUCTOR: permite crear e instanciar objetos de la clase Paciente
     * @param p_historia: numero de la historia clinica del paciente
     * @param p_nombre: nombre del paciente
     * @param p_domicilio: direccion del paciente. 
     * @param p_localidadNacido: localidad de nacimiento del paciente
     * @param p_localidadVive: localidad de residencia del paciente. 
    */
    public Paciente(int p_historia, String p_nombre, String p_domicilio, Localidad p_localidadNacido, Localidad p_localidadVive){
        this.setHistClin(p_historia);
        this.setNombre(p_nombre);
        this.setDomicilio(p_domicilio);
        this.setLocNac(p_localidadNacido);
        this.setLocViv(p_localidadVive);
    }

    /**ACCESORS*/
    /**SETTERS*/
    /**setHistClin(int p_historia): actualiza el estado del atributo historiaClinica.
     * @param p_historia: numero de la historia clinica del paciente
    */
    private void setHistClin(int p_historia){
        this.historiaClinica = p_historia;        
    }
    
    /**setNombre(String p_nombre): actualiza el estado del atributo p_nombre
     * @param p_nombre: nombre de la persona
    */
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    /**setDomicilio(String p_domicilio):actualiza el estado del atributo domicilio 
     * @param p_domicilio: domicilio del paciente
    */
    private void setDomicilio(String p_domicilio){
        this.domicilio = p_domicilio;
    }
    
    /**setLocNac(Localidad p_LocalNac): actualiza el estado del atributo localidadNacido.
     * @param p_LocalNac = localidad de nacimiento del paciente. 
    */
    private void setLocNac(Localidad p_LocalNac){
        this.localidadNacido = p_LocalNac;
    }
    
    /**setLocViv(Localidad p_LocalViv): actualiza el estado del atributo localidadVive
     * @param p_LocalViv= localidad de residencia del paciente
    */
    private void setLocViv(Localidad p_LocalViv){
        this.localidadVive = p_LocalViv;
    }
    
    /**GETTERS*/
    /** getHistClin(): obtiene el valor del atributo historia clicina
    */
    public int getHistClin(){
        return this.historiaClinica;
    }
    
    /**getNombre():obtiene el valor del atributo nombre */
    public String getNombre(){
        return this.nombre;
    }
    
    /**getDom():obtiene el valor del atributo domicilio */
    public String getDom(){
        return this.domicilio;
    }
    
    /**getLocNac(): obtiene el valor del atributo localidadNacido*/
    public Localidad getLocNac(){
        return this.localidadNacido;
    }
    
    /**getLocViv(): obtiene el valor del atributo localidadVive*/
    public Localidad getLocViv(){
        return this.localidadVive;
    }
    
    /**mostrarDatosPantalla(): imprime por pantalla los valores de los atributos de Paciente, Historia Clinica y domicilio*/
    public void mostrarDatosPantalla(){
        System.out.println("Paciente: "+this.getNombre()+ "\tHistoria Clinica: "+this.getHistClin()+ "\tDomicilio: "+this.getDom());
    }
    
    
}
