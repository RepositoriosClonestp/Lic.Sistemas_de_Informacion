import java.util.*;

/**
 * Clase Hotel.
 * 
 * <p>La clase Hotel representa un hotel con un tipo específico de habitación.</p>
 * 
 * @author Zimerman Benjamin
 * @autor Solis Agustina A.
 * @version 28/8/24
 */
public class Hotel extends Alojamiento {

    /**
     * Tipo de habitación del hotel.
     */
    private String tipoHabitacion;

    /**
     * Constructor de la clase Hotel.
     * 
     * @param p_tipoHab el tipo de habitación
     * @param p_nombre el nombre del hotel
     * @param p_precio el precio base del alquiler
     * @param p_dAlq la cantidad de días de alquiler
     * @param p_servicios los servicios asociados
     */
    public Hotel(String p_tipoHab, String p_nombre, double p_precio, int p_dAlq, Servicio p_servicios) {
        super(p_nombre, p_precio, p_dAlq, p_servicios);
        this.setTipoHab(p_tipoHab);
    }

    /**
     * Establece el tipo de habitación del hotel.
     * 
     * @param p_tipoHab el nuevo tipo de habitación
     */
    private void setTipoHab(String p_tipoHab) {
        this.tipoHabitacion = p_tipoHab;
    }

    /**
     * Obtiene el tipo de habitación del hotel.
     * 
     * @return el tipo de habitación
     */
    public String getTipoHab() {
        return this.tipoHabitacion;
    }

    /**
     * Calcula el costo del alquiler del hotel.
     * 
     * @return el costo del alquiler
     */
    @Override
    public double costo() {
        return super.costo();
    }

    /**
     * Cuenta la cantidad de días alquilados para un tipo de alojamiento específico.
     * 
     * @param p_alojamiento el tipo de alojamiento
     * @return la cantidad de días alquilados
     */
    @Override
    public int contar(String p_alojamiento) {
        if (p_alojamiento.equals("Single")) {
            return (int) this.costo() + 20;
        } else if (p_alojamiento.equals("Doble")) {
            return (int) this.costo() + 35;
        } else {
            return (int) this.costo();
        }
    }

    /**
     * Realiza la liquidación del hotel.
     */
    @Override
    public void liquidar() {
        System.out.println("Habitación " + this.getTipoHab());
        System.out.println("Total: ------> $" + (this.costo() + this.costoServicios() + this.contar(this.getTipoHab())));
    }
}
