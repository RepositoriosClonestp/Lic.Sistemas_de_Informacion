
/**
 * Write a description of class AplicacionBanco here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.Scanner;
import java.util.*;
import java.util.Calendar;

public class AplicacionBanco
{
    public static void main (String [] args) {
        Localidad l1 = new Localidad ("Posadas", "Misiones");
        Calendar fI = Calendar.getInstance();
        fI.set(2023, Calendar.SEPTEMBER, 14);
        //Instanciacion objeto empleado
        Empleado e1 = new Empleado (1234556, "Juan", "Perez", 50000.0,fI);
        
        //Instanciacion objeto BANCO
        Banco b1 = new Banco ("Galicia", l1, 12, e1); 
        b1.setCuentas (new ArrayList()); 
        b1.agregarEmpleado(e1); 
        
        //Instaciacion objeto empleado
        Empleado e2 = new Empleado (6789100, "Maria", "Gomez", 20000.5, 2004); 
        b1.agregarEmpleado(e2); 
        //Instanciacion objeto empleado
        Empleado e3 = new Empleado (2344678, "Pedro", "Gonzalez", 30500.5, 2000); 
        b1.agregarEmpleado(e3); 
        
        
        //INSTANCIACION OBJETOS CUENTAS BANCARIAS
        //Instanciacion objetos titulares
        Persona titular1= new Persona(46380532,"Sofia", "Marquez", 1996); 
        Persona titular2 = new Persona(31252293, "Cecilia", "Soto", 1984); 
        Persona titular3 = new Persona(36666920, "Diego", "Gomez", 1990); 
        Persona titular4 = new Persona (42567890, "Pablo", "Perez", 2000);
        
        //Cuentas bancarias
        CuentaBancaria cuenta1 = new CuentaBancaria (123, titular1,50000, 200); 
        b1.agregarCuentaBancaria(cuenta1); 
        
        CuentaBancaria cuenta2= new CuentaBancaria(345, titular2, 60000,300);
        b1.agregarCuentaBancaria(cuenta2); 
        
        CuentaBancaria cuenta3= new CuentaBancaria (567, titular3, 0, 0);
        b1.agregarCuentaBancaria(cuenta3); 
        
        CuentaBancaria cuenta4= new CuentaBancaria (678, titular3, 20000,100); 
        b1.agregarCuentaBancaria(cuenta4); 
        
        CuentaBancaria cuenta5= new CuentaBancaria (890, titular4, 0, 0); 
        b1.agregarCuentaBancaria(cuenta5); 
        b1.mostrarResumen(); 
        
    }
}