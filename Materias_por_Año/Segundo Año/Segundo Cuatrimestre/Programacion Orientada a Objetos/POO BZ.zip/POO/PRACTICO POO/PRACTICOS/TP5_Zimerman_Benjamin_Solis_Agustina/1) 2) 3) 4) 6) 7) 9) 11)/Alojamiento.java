import java.util.*;

/**
 * Clase Alojamiento.
 * 
 * <p>La clase Alojamiento representa un alojamiento con servicios asociados.</p>
 * 
 * @autor Zimerman Benjamin
 * @autor Solis Agustina A.
 * @version 28/8/24
 */
public abstract class Alojamiento {
    
    /**
     * Nombre del alojamiento.
     */
    private String nombre;
    
    /**
     * Precio base del alojamiento.
     */
    private double precioBase;
    
    /**
     * Días de alquiler del alojamiento.
     */
    private int diasAlquiler;
    
    /**
     * Lista de servicios asociados al alojamiento.
     */
    private ArrayList<Servicio> servicios;

    /**
     * Constructor de la clase Alojamiento.
     * 
     * @param p_nombre el nombre del alojamiento
     * @param p_precio el precio base del alojamiento
     * @param p_dAlq la cantidad de días de alquiler
     * @param p_servicios la lista de servicios asociados
     */
    public Alojamiento(String p_nombre, double p_precio, int p_dAlq, ArrayList<Servicio> p_servicios) {
        this.setNombre(p_nombre);
        this.setPrecioBase(p_precio);
        this.setDiasAlqui(p_dAlq);
        this.setServicios(p_servicios);
    }

    /**
     * Constructor de la clase Alojamiento.
     * 
     * @param p_nombre el nombre del alojamiento
     * @param p_precio el precio base del alojamiento
     * @param p_dAlq la cantidad de días de alquiler
     * @param servicios el servicio asociado
     */
    public Alojamiento(String p_nombre, double p_precio, int p_dAlq, Servicio servicios) {
        this.setNombre(p_nombre);
        this.setPrecioBase(p_precio);
        this.setDiasAlqui(p_dAlq);
        this.setServicios(new ArrayList<Servicio>());
    }

    /**
     * Establece el nombre del alojamiento.
     * 
     * @param p_nombre el nuevo nombre del alojamiento
     */
    private void setNombre(String p_nombre) {
        this.nombre = p_nombre;
    }

    /**
     * Establece el precio base del alojamiento.
     * 
     * @param p_precio el nuevo precio base
     */
    protected void setPrecioBase(double p_precio) {
        this.precioBase = p_precio;
    }

    /**
     * Establece los días de alquiler del alojamiento.
     * 
     * @param p_dAlq la nueva cantidad de días de alquiler
     */
    protected void setDiasAlqui(int p_dAlq) {
        this.diasAlquiler = p_dAlq;
    }

    /**
     * Establece la lista de servicios asociados al alojamiento.
     * 
     * @param p_servicios la nueva lista de servicios
     */
    protected void setServicios(ArrayList<Servicio> p_servicios) {
        this.servicios = p_servicios;
    }

    /**
     * Obtiene el nombre del alojamiento.
     * 
     * @return el nombre del alojamiento
     */
    public String getNombre() {
        return this.nombre;
    }

    /**
     * Obtiene el precio base del alojamiento.
     * 
     * @return el precio base del alojamiento
     */
    public double getPrecioBase() {
        return this.precioBase;
    }

    /**
     * Obtiene los días de alquiler del alojamiento.
     * 
     * @return la cantidad de días de alquiler
     */
    public int getDiasAlqui() {
        return this.diasAlquiler;
    }

    /**
     * Obtiene la lista de servicios asociados al alojamiento.
     * 
     * @return la lista de servicios
     */
    public ArrayList<Servicio> getServicios() {
        return this.servicios;
    }

    /**
     * Agrega un servicio a la lista de servicios del alojamiento.
     * 
     * @param p_servicio el servicio a agregar
     * @return true si el servicio fue agregado exitosamente, false en caso contrario
     */
    public boolean agregarServicio(Servicio p_servicio) {
        return this.getServicios().add(p_servicio);
    }

    /**
     * Quita un servicio de la lista de servicios del alojamiento.
     * 
     * @param p_servicio el servicio a quitar
     * @return true si el servicio fue quitado exitosamente, false en caso contrario
     */
    public boolean quitarServicio(Servicio p_servicio) {
        return this.getServicios().remove(p_servicio);
    }

    /**
     * Cuenta la cantidad de días alquilados dependiendo del alojamiento.
     * 
     * @param p_alojamiento el tipo de alojamiento
     * @return la cantidad de días alquilados
     */
    public abstract int contar(String p_alojamiento);

    /**
     * Calcula el costo dependiendo del alojamiento.
     * 
     * @return el costo del alojamiento
     */
    public double costo() {
        return this.getPrecioBase() * this.getDiasAlqui();
    }

    /**
     * Lista los servicios asociados al alojamiento.
     */
    public void listarServicios() {
        for (Servicio servicio : this.getServicios()) {
            System.out.println(servicio.getDescripcion() + " : $" + servicio.getPrecio());
        }
    }

    /**
     * Calcula el costo total de los servicios asociados al alojamiento.
     * 
     * @return el costo total de los servicios
     */
    public double costoServicios() {
        double costo = 0;
        for (Servicio servicio : this.getServicios()) {
            costo += servicio.getPrecio();
        }
        return costo;
    }

    /**
     * Realiza la liquidación del alojamiento.
     */
    public void liquidar() {
        System.out.println("Alojamiento: " + this.getNombre());
        System.out.println("Costo por " + this.getDiasAlqui() + " días: $" + this.costo() + " alquiler");
        this.listarServicios();
    }
}
