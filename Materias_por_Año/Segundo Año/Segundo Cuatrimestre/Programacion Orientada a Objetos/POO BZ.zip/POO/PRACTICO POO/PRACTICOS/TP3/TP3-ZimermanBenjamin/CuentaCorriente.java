/**
 * Clase CuentaCorriente.
 * 
 * @author (Zimerman Benjamin-Solis Agustina) 
 * @version (1/09/24)
 */
public class CuentaCorriente
{
    /**ATRIBUTOS**/
    private int nroCuenta; 
    private double saldo; 
    private Persona titular; 
    private double limiteDescubierto; 

    /**METODOS CONSTRUCTORES: permiten crear e instanciar objetos de la clase CuentaCorriente
     * @param int p_nroCuenta: numero de la cuenta corriente. 
     * @param p_titular: objeto de la clase persona que contiene la informacion del tirular(nombre completo, dni, fecha de nacimiento)
    */
    public CuentaCorriente(int p_nroCuenta, Persona p_titular)
    {
       this.setNroCuenta(p_nroCuenta); 
       this.setTitular(p_titular); 
       this.setLimiteDescubierto(500.0); 
    }
    
    /**METODOS CONSTRUCTORES: permiten crear e instanciar objetos de la clase CuentaCorriente
     * @param int p_nroCuenta: numero de la cuenta corriente. 
     * @param p_titular: objeto de la clase persona que contiene la informacion del tirular(nombre completo, dni, fecha de nacimiento)
     * @param p_saldo: importe del saldo disponible en la cuenta corriente. 
     * @param p_limiteDescubierto: limite descubierto de la cuenta corriente
    */
    public CuentaCorriente(int p_nroCuenta, Persona p_titular, double p_saldo, double p_limiteDescubierto){
        this.setNroCuenta(p_nroCuenta); 
        this.setTitular(p_titular); 
        this.setSaldo(p_saldo); 
        this.setLimiteDescubierto(500.0); 
    }

    
    /**ACCESORS**/
    /**SETTERS: permiten modificar el estado de los atributos**/
    private void setNroCuenta (int p_nroCuenta){
        this.nroCuenta = p_nroCuenta; 
    }
    
    private void setSaldo (double p_saldo){
        this.saldo=p_saldo; 
    }
    
    private void setTitular (Persona p_titular){
        this.titular=p_titular;
    }
    
    private void setLimiteDescubierto (double p_limite){
        this.limiteDescubierto =p_limite; 
    }
    
    /**GETTERS: permiten obtener el estado de los atributos y los devuelve**/
    public int getNroCuenta(){
        return this.nroCuenta; 
    }
    
    public double getSaldo(){
        return this.saldo;
    }
    
    public Persona getTitular (){
        return this.titular; 
    }
    
    public double getLimiteDescubierto(){
        return this.limiteDescubierto; 
    }
    
    /**METODO DEPOSITAR(p_importe): agrega el importe ingresado al saldo actual
     * @param p_importe: importe de dinero que se desea depositar.
    */
    public void depositar(double p_importe){
        this.setSaldo(this.getSaldo() + p_importe); 
    }
    
    /**METODO PUEDE EXTRAER: devuelve true si la suma del saldo y el limite descubierto es mayor al importe a retirar
     * @param p_importe: importe de dinero que se desea depositar.
     * @return true si la suma del saldo y el limite descubierto es mayor al importe a retirar
    **/
    private boolean puedeExtraer(double p_importe) {
        if ((this.getSaldo() + this.getLimiteDescubierto()) > p_importe)
        return true; 
        else{
            return false; 
        }
    }
    
    /**METODO EXTRACCION:actualiza el valor del saldo al restarle el valor del importe ingresado como parametro 
     * @param p_importe: monto que se desea extraer.
    **/
    private void extraccion (double p_importe) {
        this.setSaldo(this.getSaldo() - p_importe);
    }
    
    /**METODO EXTRAER: si el metodo puedeExtraer() retorna true, activa el metodo extraccion(),que resta del importe del saldo el importe ingresado como parametro.
     * @param p_importe: importe del dinero que se desea extraer. 
     * @return el saldo final luego de realizada la extraccion
    **/
    public void extraer (double p_importe){
        if (puedeExtraer(p_importe)) {
            extraccion (p_importe);
            System.out.println ("Extracción Exitosa!");
        }else {
            System.out.println("El importe de extraccion sobrepasa el limite descubierto!");
        }
    }
    
    /**metodo mostrar(): imprime por pantalla los datos del titular*/
    public void mostrar () {
        System.out.println ("-\tCuenta Corriente \t-");
        System.out.println ("Nro.Cuenta:"+ this.getNroCuenta() + "-\tSaldo" + this.getSaldo()); 
        System.out.println ("Titular: "+this.titular.apeYNom());
        System.out.println("Descubierto" +this.getLimiteDescubierto());
        
    }
}




