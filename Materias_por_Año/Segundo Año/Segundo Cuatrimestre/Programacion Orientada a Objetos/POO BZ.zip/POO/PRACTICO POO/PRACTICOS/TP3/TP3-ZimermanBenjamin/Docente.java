/**
 * Ejercicio 5. CLASE DOCENTE.
 * 
 * @author (Zimerman Benjamin, Solis Agustina A.) 
 * @version ()
 */
public class Docente{
    /**ATRIBUTOS*/
    private String nombre;
    private String grado;
    private double sueldoBasico;
    private double asignacionFamiliar;
    
    /**METODO CONSTRUCTOR: permite crear e instanciar objetos de la clase docente
     * @param p_nombre: nombre del docente. 
     * @param p_grado: grado que esta a cargo del docente. 
     * @param p_sueldBas: importe del sueldo basico del docente. 
     * @param p_asigFam: importe de la asignacion familiar
    **/
    public Docente(String p_nombre, String p_grado, double p_sueldBas, double p_asigFam){
        this.setNombre(p_nombre);
        this.setGrado(p_grado);
        this.setSuelBas(p_sueldBas);
        this.setAsigFam(p_asigFam);
    }

    /**ACCESORS*/
    /**SETTERS: permiten medoficar los valores de los atributos*/
    private void setNombre(String p_nombre){
        this.nombre = p_nombre ;
    }

    private void setGrado(String p_grado){
        this.grado = p_grado;
    }

    private void setSuelBas(double p_suelBas){
        this.sueldoBasico = p_suelBas ;
    }

    private void setAsigFam(double p_asigFam){
        this.asignacionFamiliar = p_asigFam;
    }

    /**GETTERS: permiten obtener el valor de los atributos y devuelven estos mismos*/
    public String getNombre(){
        return this.nombre;
    }

    public String getGrado(){
        return this.grado;
    }

    public double getSuelBas(){
        return this.sueldoBasico;
    }

    public double getAsigFam(){
        return this.asignacionFamiliar;
    }
    
    /**Metodo calcularSaldo(): calcula el sueldo del docente, obtenido entre la suma del sueldo basico y la asignacion fmailiar
     * @return el sueldo total del docente al sumer el sueldo basico + asignacion familiar
    */
    public double calcularSueldo(){
        double total = this.getSuelBas() + this.getAsigFam();
        return total;
    }
}
