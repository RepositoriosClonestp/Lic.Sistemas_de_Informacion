
public class EjecutableLaboratorio
{
    public static void main(String [] args){
        Laboratorio l1 = new Laboratorio ("Colgate S.A.", "Junín 5209", "54-11-4239-8447");
        l1.mostrar();    
    }
}
