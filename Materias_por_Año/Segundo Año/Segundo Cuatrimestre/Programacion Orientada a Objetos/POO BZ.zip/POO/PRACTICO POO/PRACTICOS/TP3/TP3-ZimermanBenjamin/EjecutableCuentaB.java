/**
 * CLASE EJECUTABLECUENTAB.
 * @author (Zimerman Benjamin, Solis Agustina) 
 * @version (01/09/24)//
 */

import java.util.Scanner; 
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.InputMismatchException; 

public class EjecutableCuentaB
{
    public static void main (String [] args){
           
           /**Se instancia un nuevo objeto de la clase CuentaBancaria**/
           Persona titular1 = new Persona (46380532, "Juan", "Perez", 2000); 
           System.out.println("Ingrese el valor del importe:");
           
           Scanner sc = new Scanner(System.in);
           double p_importe = sc.nextDouble(); 
           System.out.println("Valor del importe ingresado: " + p_importe); 
           
           CuentaBancaria cuenta1 = new CuentaBancaria (1234, titular1, 25800.50, p_importe);
           cuenta1.mostrar(); 
           cuenta1.toStrinf();
           
           /**IMPLEMENTACION MENU DE METODOS DEPOSITAR Y EXTRAER**/
            Scanner scan = new Scanner(System.in); 
            boolean salir = false; 
            int opcion; 
            
            while (!salir) {
                System.out.println("\n***OPERAR LA CUENTA***");
                System.out.println("1. Realizar un DEPOSITO");
                System.out.println("2. Realizar una EXTRACCION");
                System.out.println("3.SALIR");
                    try {
                        System.out.println ("Seleccione una de las opciones anteriores (1 - 2 - 3)");
                        opcion = scan.nextInt(); 
                        
                        switch (opcion) {
                            case 1: 
                                System.out.println ("Ha seleccionado realizar un DEPOSITO: ");
                                cuenta1.depositar(p_importe); 
                                cuenta1.mostrar(); 
                                break; 
                            case 2: 
                                System.out.println ("Ha seleccionado realizar una EXTRACCION");
                                cuenta1.extraer(p_importe); 
                                cuenta1.mostrar(); 
                                break; 
                            case 3: 
                                salir = true; 
                                break; 
                                default: 
                                    System.out.println("El numero de opcion ingresado no es correcto");
                        }
                    } catch (InputMismatchException e) {
                        System.out.println ("Debe ingresar un numero");
                        scan.next(); 
                    }
                
            }
            
                
           ///**Se instancia otro objeto de la clase CuentaBancaria **/
           //Persona titular2 = new Persona (12345678, "Agustina", "Solis", 2004);
           //System.out.println("Ingrese el valor del importe: ");
           //double importe2 = scan.nextDouble();
           //CuentaBancaria cuenta2 = new CuentaBancaria (5678, titular2,10500.50, 2500.5 );
           //cuenta2.depositar(2500.5);
           //cuenta2.mostrar();
           //cuenta2.toStrinf();
    }
}
