import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.List;

public class BibliotecaGUI extends JFrame {
    private Biblioteca biblioteca;
    private JTextArea sociosTextArea, librosTextArea, prestamosTextArea;

    //Sección de Aspecto de la Interfaz: Pantalla, Cuadro y Botones/
    // Definir colores y fuentes como constantes
    private static final Color COLOR_PRINCIPAL = new Color(51, 105, 232);  // Azul principal
    private static final Color COLOR_FONDO = new Color(240, 242, 245);     // Gris muy claro
    private static final Color COLOR_TEXTO = new Color(33, 33, 33);        // Casi negro
    private static final Color COLOR_BOTON = new Color(64, 123, 255);      // Azul para botones
    private static final Font FUENTE_TITULO = new Font("Segoe UI", Font.BOLD, 14);
    private static final Font FUENTE_TEXTO = new Font("Segoe UI", Font.PLAIN, 12);
    private static final Font FUENTE_BOTON = new Font("Segoe UI", Font.BOLD, 12);

    public BibliotecaGUI() {
        biblioteca = new Biblioteca("Biblioteca Mariño");
        configurarVentanaPrincipal();
        configurarContenido();
    }

    private void configurarVentanaPrincipal() {
        setTitle("Biblioteca Mariño");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);  // Centra la ventana
        getContentPane().setBackground(COLOR_FONDO);

        // Configurar el aspecto del JFrame
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            SwingUtilities.updateComponentTreeUI(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void configurarContenido() {
        JTabbedPane tabbedPane = crearTabbedPane();
        add(crearPanelPrincipal(tabbedPane));
    }

    private JTabbedPane crearTabbedPane() {
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(FUENTE_TITULO);
        tabbedPane.setBackground(COLOR_FONDO);
        tabbedPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        tabbedPane.addTab("Socios", crearPanelSocios());
        tabbedPane.addTab("Libros", crearPanelLibros());
        tabbedPane.addTab("Préstamos", crearPanelPrestamos());
        tabbedPane.addTab("Lista de Socios", crearPanelListaSocios());
        tabbedPane.addTab("Lista de Libros", crearPanelListaLibros());

        return tabbedPane;
    }

    private JPanel crearPanelPrincipal(JTabbedPane tabbedPane) {
        JPanel panelPrincipal = new JPanel(new BorderLayout(10, 10));
        panelPrincipal.setBackground(COLOR_FONDO);
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Crear panel de título
        JPanel panelTitulo = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelTitulo.setBackground(COLOR_PRINCIPAL);
        JLabel titulo = new JLabel("Biblioteca Mariño");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titulo.setForeground(Color.WHITE);
        panelTitulo.add(titulo);

        // Agregar componentes al panel principal
        panelPrincipal.add(panelTitulo, BorderLayout.NORTH);
        panelPrincipal.add(tabbedPane, BorderLayout.CENTER);
        panelPrincipal.add(crearBotonSalir(), BorderLayout.SOUTH);

        return panelPrincipal;
    }

    private JPanel crearPanelSocios() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(COLOR_FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JButton btnAgregarSocio = crearBotonEstilizado("Agregar Socio");
        btnAgregarSocio.addActionListener(e -> agregarSocio());

        sociosTextArea = crearTextAreaEstilizada();

        panel.add(btnAgregarSocio, BorderLayout.NORTH);
        panel.add(new JScrollPane(sociosTextArea), BorderLayout.CENTER);

        return panel;
    }

    private JPanel crearPanelLibros() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(COLOR_FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JButton btnAgregarLibro = crearBotonEstilizado("Agregar Libro");
        btnAgregarLibro.addActionListener(e -> agregarLibro());

        librosTextArea = crearTextAreaEstilizada();

        panel.add(btnAgregarLibro, BorderLayout.NORTH);
        panel.add(new JScrollPane(librosTextArea), BorderLayout.CENTER);

        return panel;
    }

    private JPanel crearPanelPrestamos() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(COLOR_FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Panel superior para botones de préstamo
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        panelBotones.setBackground(COLOR_FONDO);

        JButton btnPrestar = crearBotonEstilizado("Prestar Libro");
        JButton btnDevolver = crearBotonEstilizado("Devolver Libro");
        JButton btnMostrar = crearBotonEstilizado("Mostrar Préstamos");

        btnPrestar.addActionListener(e -> prestarLibro());
        btnDevolver.addActionListener(e -> devolverLibro());
        btnMostrar.addActionListener(e -> mostrarPrestamos());

        panelBotones.add(btnPrestar);
        panelBotones.add(btnDevolver);

        prestamosTextArea = crearTextAreaEstilizada();

        panel.add(panelBotones, BorderLayout.NORTH);
        panel.add(new JScrollPane(prestamosTextArea), BorderLayout.CENTER);
        panel.add(btnMostrar, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel crearPanelListaSocios() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(COLOR_FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JTextArea listaSociosTextArea = crearTextAreaEstilizada();
        JButton btnActualizar = crearBotonEstilizado("Actualizar Lista de Socios");
        btnActualizar.addActionListener(e -> listaSociosTextArea.setText(biblioteca.listaDeSocios()));

        panel.add(new JScrollPane(listaSociosTextArea), BorderLayout.CENTER);
        panel.add(btnActualizar, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel crearPanelListaLibros() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(COLOR_FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JTextArea listaLibrosTextArea = crearTextAreaEstilizada();
        JButton btnActualizar = crearBotonEstilizado("Actualizar Lista de Libros");
        btnActualizar.addActionListener(e -> listaLibrosTextArea.setText(biblioteca.listaDeLibros()));

        panel.add(new JScrollPane(listaLibrosTextArea), BorderLayout.CENTER);
        panel.add(btnActualizar, BorderLayout.SOUTH);

        return panel;
    }

    private JButton crearBotonEstilizado(String texto) {
        JButton boton = new JButton(texto);
        boton.setFont(FUENTE_BOTON);
        boton.setBackground(COLOR_BOTON);
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setBorderPainted(false);
        boton.setOpaque(true);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Efectos hover
        boton.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    boton.setBackground(COLOR_BOTON.brighter());
                }

                public void mouseExited(java.awt.event.MouseEvent evt) {
                    boton.setBackground(COLOR_BOTON);
                }
            });

        return boton;
    }

    private JTextArea crearTextAreaEstilizada() {
        JTextArea textArea = new JTextArea();
        textArea.setFont(FUENTE_TEXTO);
        textArea.setForeground(COLOR_TEXTO);
        textArea.setBackground(Color.WHITE);
        textArea.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_PRINCIPAL.darker(), 1),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)
            ));
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        return textArea;
    }

    private JButton crearBotonSalir() {
        JButton btnSalir = new JButton("Salir");
        btnSalir.setFont(FUENTE_BOTON);
        btnSalir.setBackground(new Color(220, 53, 69)); // Rojo para el botón de salir
        btnSalir.setForeground(Color.WHITE);
        btnSalir.setFocusPainted(false);
        btnSalir.setBorderPainted(false);
        btnSalir.setOpaque(true);
        btnSalir.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnSalir.addActionListener(e -> System.exit(0));

        // Efectos hover para el botón de salir
        btnSalir.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    btnSalir.setBackground(new Color(200, 35, 51));
                }

                public void mouseExited(java.awt.event.MouseEvent evt) {
                    btnSalir.setBackground(new Color(220, 53, 69));
                }
            });

        return btnSalir;
    }

    //Sección de funcionalidad de los botones/
    private void agregarSocio() {
        // Mostrar opciones para elegir el tipo de socio
        String[] opciones = {"Estudiante", "Docente"};
        int tipoSeleccionado = JOptionPane.showOptionDialog(
                this,
                "Seleccione el tipo de socio a agregar:",
                "Tipo de Socio",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                opciones,
                opciones[0]
            );

        if (tipoSeleccionado == JOptionPane.CLOSED_OPTION) {
            return;
        }

        String nombre = JOptionPane.showInputDialog(this, "Ingrese el nombre del socio:");
        if (nombre == null || nombre.trim().isEmpty()){
            JOptionPane.showMessageDialog(this, "El nombre no puede estar vacío. Intente nuevamente.");
            return;
        }else if(!nombre.matches("[a-zA-Z\\s]+")){
            JOptionPane.showMessageDialog(this, "El nombre solo puede contener letras y espacios. Intente nuevamente.");
            return;
        }

        String dniInput = JOptionPane.showInputDialog(this, "Ingrese el DNI del socio:");
        if (dniInput == null || dniInput.trim().isEmpty()){
            JOptionPane.showMessageDialog(this, "El dni no puede estar vacío. Intente nuevamente.");
            return;
        }

        int dni;
        try {
            dni = Integer.parseInt(dniInput);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "DNI inválido. Intente nuevamente.");
            return;
        }

        if (biblioteca.buscarSocio(dni) != null) {
            JOptionPane.showMessageDialog(this, "El DNI ingresado ya está registrado. Intente con otro.");
            return;
        }

        if (tipoSeleccionado == 0) {
            String carrera = JOptionPane.showInputDialog(this, "Ingrese la carrera del estudiante:");
            if (carrera == null) return;
            biblioteca.nuevoSocioEstudiante(dni, nombre, carrera);
        } else if (tipoSeleccionado == 1) {
            String area = JOptionPane.showInputDialog(this, "Ingrese el área del docente:");
            if (area == null) return;
            biblioteca.nuevoSocioDocente(dni, nombre, area);
        }

        sociosTextArea.setText("¡Socio agregado correctamente!");
    }

    private void agregarLibro() {
        // Solicitar título del libro
        String titulo = JOptionPane.showInputDialog(this, "Ingrese el título del libro:");
        if (titulo == null) return; // Cancelar si presiona "Cancelar"

        // Solicitar autor del libro (editorial)
        String editorial = JOptionPane.showInputDialog(this, "Ingrese la editorial del libro:");
        if (editorial == null) return; // Cancelar si presiona "Cancelar"

        // Solicitar la edición del libro
        String edicion = JOptionPane.showInputDialog(this, "Ingrese la edición del libro:");
        if (edicion == null) return; // Cancelar si presiona "Cancelar"

        int verificarEdicion;
        try {
            verificarEdicion = Integer.parseInt(edicion);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Edición inválida. Intente nuevamente.");
            return;
        }

        // Solicitar el año de publicación del libro
        String anio = JOptionPane.showInputDialog(this,  "Ingrese el año de publicación del libro:");
        if (anio == null) return; // Cancelar si presiona "Cancelar"

        int verificarAnio;
        try {
            verificarAnio = Integer.parseInt(anio);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Año inválido. Intente nuevamente.");
            return;
        }

        // Agregar libro a la bibliotecaa
        biblioteca.nuevoLibro(titulo, verificarEdicion, editorial, verificarAnio);

        // Mensaje de confirmación
        librosTextArea.setText("Libro agregado correctamente!");
    }

    private void prestarLibro() {
        // Verificar si hay libros y socios disponibles
        if (biblioteca.getLibro().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "No hay libros registrados en la biblioteca.", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (biblioteca.getSocio().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "No hay socios registrados en la biblioteca.", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Crear lista de libros disponibles
        List<String> librosDisponibles = new ArrayList<>();
        for (Libro libro : biblioteca.getLibro()) {
            if (!libro.prestado()) {
                librosDisponibles.add(libro.getTitulo());
            }
        }

        if (librosDisponibles.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "No hay libros disponibles para préstamo en este momento.", 
                "Información", 
                JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // Mostrar selector de libros
        String tituloLibro = (String) JOptionPane.showInputDialog(
                this,
                "Seleccione el libro a prestar:",
                "Préstamo de Libro",
                JOptionPane.QUESTION_MESSAGE,
                null,
                librosDisponibles.toArray(),
                librosDisponibles.get(0)
            );

        if (tituloLibro == null) return; // Usuario canceló la selección

        Libro libro = biblioteca.buscarLibro(tituloLibro);
        if (libro == null) {
            JOptionPane.showMessageDialog(this, 
                "Error al encontrar el libro seleccionado.", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Mostrar lista de socios
        String socioDNI = JOptionPane.showInputDialog(this, 
                "Ingrese el DNI del socio:\n\n" + biblioteca.listaDeSocios());

        if (socioDNI == null || socioDNI.trim().isEmpty()) return;

        int dni;
        try {
            dni = Integer.parseInt(socioDNI);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, 
                "DNI inválido. Ingrese solo números.", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        Socio socio = biblioteca.buscarSocio(dni);
        if (socio == null) {
            JOptionPane.showMessageDialog(this, 
                "No se encontró ningún socio con el DNI ingresado.", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        
        
        // Verificar límite de préstamos del socio
        

        try {
            biblioteca.prestarLibro(new GregorianCalendar(), socio, libro);

            // Actualizar la información en la interfaz
            prestamosTextArea.append(String.format(
                    "Préstamo realizado con éxito!\n" +
                    "Socio: %s (DNI: %d)\n" +
                    "Libro: %s\n" +
                    "Fecha: %s\n\n",
                    socio.getNombre(),
                    socio.getDniSocio(),
                    libro.getTitulo(),
                    new Date().toString()
                ));

            // Actualizar las listas
            SwingUtilities.invokeLater(() -> {
                        librosTextArea.setText(biblioteca.listaDeLibros());
                        sociosTextArea.setText(biblioteca.listaDeSocios());
                });

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error al realizar el préstamo: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void devolverLibro() {
        String librosDisponibles = biblioteca.listaDeLibros();
        String libroDevuelto = JOptionPane.showInputDialog(this, "Ingrese el título del libro a devolver:" + librosDisponibles);
        if (libroDevuelto == null || libroDevuelto.isEmpty()){
            return;
        }
        // Aquí buscaríamos el libro que corresponde a la devolución
        Libro libro1 = biblioteca.buscarLibro(libroDevuelto);
        if (libro1 != null) {
            try {
                // Intenta devolver el libro
                biblioteca.devolverLibro(libro1);
                
                prestamosTextArea.append("El libro '" + libroDevuelto + "' ha sido devuelto.\n");
            } catch (LibroNoPrestadoException e) {
                // Capturar la excepción si el libro no está prestado
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "No se ha encontrado el libro.");
        }
    }

    private void mostrarPrestamos() {
        try {
            StringBuilder resultado = new StringBuilder();

            // Recorre todos los libros y extrae sus préstamos
            for (Libro libro : biblioteca.getLibro()) {
                System.out.println("Procesando libro: " + libro.getTitulo()); // Depuración

                ArrayList<Prestamo> prestamos = libro.getPrestamos();

                // Verifica que la lista de préstamos no sea nula ni vacía
                if (prestamos != null && !prestamos.isEmpty()) {
                    for (Prestamo prestamo : prestamos) {
                        resultado.append("Libro: ").append(libro.getTitulo())
                        .append(" - ").append(prestamo.toString()).append("\n");
                    }
                }
            }

            // Si no se añadió ningún préstamo al resultado, muestra el mensaje
            if (resultado.length() == 0) {
                resultado.append("No hay préstamos.");
            }

            // Actualiza el área de texto con los resultados
            prestamosTextArea.setText(resultado.toString());

        } catch (Exception e) {
            // Imprime el stack trace del error en la consola
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Ocurrió un error al mostrar los préstamos: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
                    BibliotecaGUI gui = new BibliotecaGUI();
                    gui.setVisible(true);
            });
        }
}