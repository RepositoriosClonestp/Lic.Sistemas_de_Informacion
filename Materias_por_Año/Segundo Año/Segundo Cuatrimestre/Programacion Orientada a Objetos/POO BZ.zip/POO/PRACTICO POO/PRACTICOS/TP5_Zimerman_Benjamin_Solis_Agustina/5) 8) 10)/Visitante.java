
/**
 * Write a description of class Visitante here: Un zoológico desea llevar registro de las entradas que vende. El valor de la entrada depende del tipo de visitante, que 
puede ser: Individuo o Delegación. La clase Persona colabora con Individuo para prestarle sus servicios. De cada 
visitante se registra nombre y fecha de la visita. Una delegación tiene un nombre que la identifica y está formada por 
una colección de individuos. La entrada por individuo es de $10. El costo de la entrada de una delegación es la suma 
de las entradas de sus integrantes, menos un 10% de descuento.
 * 
 * @author (Solis Agustina, Zimerman Benjamin) 
 * @version (16/10/24)
 */
import java.util.*;
import java.util.Calendar;
public abstract class Visitante
{
    private String nombre; 
    private Calendar fechaVisita; 

    /**
     * Constructor for objects of class Visitante
     *  @param p_fecha:  fecha de la visita del visitante al zoologico
     *  @param p_nombre: nombre del visitante
     */
    public Visitante(String p_nombre, Calendar p_fecha){
        this.setNombre(p_nombre); 
        this.setFecha(p_fecha); 
    }

    /**ACCESORS*/
    /**setters*/
    protected void setNombre(String p_nombre) {
        this.nombre = p_nombre;
    }
    
    protected void setFecha(Calendar p_fecha){
        this.fechaVisita = p_fecha; 
    }
    
    /**getters*/
    public String getNombre() {
        return this.nombre; 
    }
    
    public Calendar getFecha() {
        return this.fechaVisita; 
    }
    
    /**METODOS*/
    public abstract void mostrar(); 
    public abstract double entrada(); 
    public abstract void listarPorFecha(Calendar p_fecha, String p_visitante);
    public abstract String tipoVisitante(); 
    public abstract HashSet <Persona> listarPersona(); 
}
