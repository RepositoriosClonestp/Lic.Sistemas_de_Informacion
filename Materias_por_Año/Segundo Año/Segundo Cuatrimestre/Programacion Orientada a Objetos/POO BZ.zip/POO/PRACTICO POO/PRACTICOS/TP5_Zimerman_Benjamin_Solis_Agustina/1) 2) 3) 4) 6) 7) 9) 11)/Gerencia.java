import java.util.*;

/**
 * Clase Gerencia.
 * 
 * La clase Gerencia se encarga de gestionar los alojamientos alquilados.</p>
 * 
 * @author Zimerman Benjamin
 * @author Solis Agustina A.
 * @version 28/8/24
 */
public class Gerencia {

    /**
     * Nombre de la gerencia.
     */
    private String nombre;

    /**
     * Lista de alojamientos alquilados.
     */
    private ArrayList<Alojamiento> alojamientosAlquilados;

    /**
     * Constructor de la clase Gerencia.
     * 
     * @param p_nombre el nombre de la gerencia
     * @param p_alojamiento el alojamiento a ser agregado a la lista de alojamientos alquilados
     */
    public Gerencia(String p_nombre, Alojamiento p_alojamiento) {
        this.setNombre(p_nombre);
        this.setAlojamiento(new ArrayList<>());
    }

    /**
     * Constructor de la clase Gerencia.
     * 
     * @param p_nombre el nombre de la gerencia
     * @param p_alojamiento la lista de alojamientos alquilados
     */
    public Gerencia(String p_nombre, ArrayList<Alojamiento> p_alojamiento) {
        this.setNombre(p_nombre);
        this.setAlojamiento(p_alojamiento);
    }

    /**
     * Establece el nombre de la gerencia.
     * 
     * @param p_nombre el nuevo nombre de la gerencia
     */
    private void setNombre(String p_nombre) {
        this.nombre = p_nombre;
    }

    /**
     * Establece la lista de alojamientos alquilados.
     * 
     * @param p_alojamiento la nueva lista de alojamientos alquilados
     */
    private void setAlojamiento(ArrayList<Alojamiento> p_alojamiento) {
        this.alojamientosAlquilados = p_alojamiento;
    }

    /**
     * Obtiene el nombre de la gerencia.
     * 
     * @return el nombre de la gerencia
     */
    public String getNombre() {
        return this.nombre;
    }

    /**
     * Obtiene la lista de alojamientos alquilados.
     * 
     * @return la lista de alojamientos alquilados
     */
    public ArrayList<Alojamiento> getAlojamientos() {
        return this.alojamientosAlquilados;
    }

    /**
     * Agrega un alojamiento a la lista de alojamientos alquilados.
     * 
     * @param p_alojamiento el alojamiento a ser agregado
     * @return true si el alojamiento fue agregado exitosamente, false en caso contrario
     */
    public boolean agregarAlojamiento(Alojamiento p_alojamiento) {
        return this.getAlojamientos().add(p_alojamiento);
    }

    /**
     * Quita un alojamiento de la lista de alojamientos alquilados.
     * 
     * @param p_alojamiento el alojamiento a ser quitado
     * @return true si el alojamiento fue quitado exitosamente, false en caso contrario
     */
    public boolean quitarAlojamiento(Alojamiento p_alojamiento) {
        return this.getAlojamientos().remove(p_alojamiento);
    }

    /**
     * Cuenta el número de alojamientos de un tipo específico.
     * 
     * @param tipoAlojamiento el tipo de alojamiento (por ejemplo, "Hotel" o "Cabaña")
     * @return el número de alojamientos del tipo especificado
     */
    public int contarAlojamiento(String tipoAlojamiento) {
        int sum = 0;
        for (Alojamiento alojamiento : this.getAlojamientos()) {
            if (tipoAlojamiento.equals("Hotel") && alojamiento instanceof Hotel) {
                sum++;
            } else if (tipoAlojamiento.equals("Cabaña") && alojamiento instanceof Cabaña) {
                sum++;
            }
        }
        return sum;
    }

    /**
     * Realiza la liquidación de todos los alojamientos alquilados.
     */
    public void liquidar() {
        for (Alojamiento alojamiento : this.getAlojamientos()) {
            alojamiento.liquidar();
        }
    }

    /**
     * Muestra la liquidación de todos los alojamientos alquilados.
     */
    public void mostrarLiquidacion() {
        this.liquidar();
        System.out.println("Alojamiento tipo Cabaña ----> " + this.contarAlojamiento("Cabaña"));
        System.out.println("Alojamiento tipo Hotel ----->" + this.contarAlojamiento("Hotel"));
    }
}
