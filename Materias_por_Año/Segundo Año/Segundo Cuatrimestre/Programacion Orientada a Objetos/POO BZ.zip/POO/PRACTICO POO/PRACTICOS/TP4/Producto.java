/**
 * Ejercicio 2 Clase Producto
 * @author Zimerman Benjamin, Solis Agustina Aylen 
 * @version (11/9/24)
 */
public class Producto
{
    private int codigo; 
    private String rubro; 
    private String descripcion; 
    private double costo; 
    private int stock = 0; 
    private double porcPtoRepo;
    private int existMinima; 
    private Laboratorio lab; 
    
    /**METODOS CONSTRUCTORES:Crean e inicializan objetos de la clase Producto**/
     /**Metodo Constructor: Crea e inicializa objetos de la clase Producto tomando como parametro, 2 Strings,2 ints, 2 doubles y un objeto de clase Laboratorio*
        @param p_codigo: codigo del producto. 
        @param p_rubro: rubro al que pertenece el producto, ej: perfumeria, farmacia, etc. 
        @param p_desc: descripcion general del producto. 
        @param p_costo: precio del producto. 
        @param p_porcPtoRepo. 
        @param p_existMinima: compra minima requerida del producto en particular. 
        @param p_lab: Laboratorio del que se compra el determinado producto
        */
    public Producto(int p_codigo, String p_rubro, String p_desc, double p_costo, double p_porcPtoRepo, int p_existMinima, Laboratorio p_lab){
        this.setCodigo(p_codigo);
        this.setRubro (p_rubro); 
        this.setDescrip (p_desc);
        this.setCosto (p_costo);
        this. setPorcPR (p_porcPtoRepo); 
        this.setExistMin (p_existMinima);
        this.setLaboratorio (p_lab);
        this.setStock(0);
    }
    
    /**Metodo Constructor: Crea e inicializa objetos de la clase Producto tomando como parametro, 2 Strings,1 int, 1double y un objeto de clase Laboratorio*
        @param p_codigo: codigo del producto. 
        @param p_rubro: rubro al que pertenece el producto, ej: perfumeria, farmacia, etc. 
        @param p_desc: descripcion general del producto.
        @param p_lab: Laboratorio del que se compra el determinado producto*/
    public Producto (int p_codigo, String p_rubro, String p_desc, double p_costo, Laboratorio p_lab) {
        this.setCodigo(p_codigo);
        this.setRubro (p_rubro); 
        this.setDescrip (p_desc);
        this.setCosto (p_costo);
        this.setLaboratorio (p_lab);
        this.setStock(0); 
    }

   /**SETTERS**/
   /**SetCodigo(int p_codigo): metodo privado que permite modificar el estado del atributo codigo**/
    private void setCodigo(int p_codigo){
        this.codigo = p_codigo;
    }
    
    /**SetRubro(String p_rubro): metodo privado que permite modificar el estado del atributo rubro**/
    private void setRubro(String p_rubro){
        this.rubro = p_rubro;
    }
    
    /**setDescrip(String p_desc): metodo privado que permite modificar el estado del atributo descripcion*/
    private void setDescrip(String p_desc){
        this.descripcion = p_desc;
    }
    
    /**setCosto(double p_costo): metodo privado que permite modificar el estado del atributo costo*/
    private void setCosto(double p_costo){
        this.costo = p_costo;
    }
    
    /**setStock(int p_stock): metodo privado que permite modificar el estado del atributo stock*/
    private void setStock(int p_stock){
        this.stock = p_stock;
    }
    
    /**setPorcPR(double p_porcPtoRepo): metodo privado que permite modificar el estado del atributo porcPtoRepo*/
    private void setPorcPR(double p_porcPtoRepo){
        this.porcPtoRepo = p_porcPtoRepo;
    }
    
    /**setExistMin(int p_existMinima): metodo privado que permite modificar el estado del atributo existMinima*/
    private void setExistMin(int p_existMinima){
        this.existMinima = p_existMinima;
    }
    
    /**setLaboratorio (Laboratorio p_lab) : metodo privado que permite modificar el estado del atributo lab de clase Laboratorio**/
    private void setLaboratorio(Laboratorio p_lab){
        this.lab = p_lab;
    }

    /**GETTERS**/
    /**getCodigo(): obtiene el valor del atributo codigo de tipo int
    @return el codigo del producto*/
    public int getCodigo () {
        return this.codigo; 
    }
    
    /**getRubro(): obtiene el valor del atributo rubro de tipo String
       @return el rubro del producto*/
    public String getRubro(){
        return this.rubro; 
    }
    
    /**getDescripcion(): obtiene el valor del atributo descripcion de tipo String
       @return la descripcion del producto*/
    public String getDescripcion (){
        return this.descripcion; 
    }
    
    /**getCosto(): obtiene el valor del atributo costo de tipo double
       @return el costo del producto*/
    public double getCosto () {
        return this.costo; 
    }
    
    /**getStock(): obtiene el valor del atributo stock de tipo int
    @return el stock del producto*/
    public int getStock (){
        return this.stock; 
    }
    
    /**getPorcPtoRepo(): obtiene el valor del atributo porcPtoRepo de tipo double
    @return porcPtoRepo*/
    public double getPorcPtoRepo (){
        return this.porcPtoRepo;
    }
    
    /**getExistMinima(): obtiene el valor del atributo existMinima de tipo int
    @return existMinima*/
    public int getExistMinima () {
        return this.existMinima;
    }
    
    /**getLab(): obtiene el valor del atributo lab de clase laboratorio
       @return los datos del laboratorio*/
    public Laboratorio getLab () {
        return this.lab; 
    }
    
    /**METODO ajuste(): permite actualizar el valor del atributp stock**/
    public void ajuste (int p_cantidad){
        this.setStock (p_cantidad); 
    }
    
    /**METODO precioLista(): devuelve el valor resultante de agregar un 12% al precio de costo**/
    public double precioLista(){
        return (this.getCosto() + (this.getCosto () *0.12) ); 
    }
    
    /**METODO precioContado:devuelve el valor que representa el precio por pago contado: resta un 5% al precio de lista**/
    public double precioContado (){
        return (this.precioLista() - (this.precioLista()  *0.05));
    }
    
    /**METODO stockValorizado(): devuelve el resultado de multiplicar el stock por el precio de costo + un 12%**/
    public double stockValorizado () {
        return ((this.getStock() * this.getCosto()) + (this.getCosto () * 0.12));
    }
    
    /**METODO ajustarPtoRepo(): premite asignar un nuevo valor a porcPtoRepo **/
    public void ajustarPtoRepo (double p_porce) {
        this.setPorcPR(p_porce); 
    }
    /**METODO ajustarExistMin(): permite agregar un nuevo valor a existMinima**/
    public void ajustarExistMin(int p_cantidad){
        this.setExistMin(p_cantidad); 
    }
    
    /**METODO mostrar linea**/
     public void mostrarLinea(){
        System.out.println(this.getDescripcion()+ "         " +this.precioLista()+ "            " +this.precioContado());
    }  
}
