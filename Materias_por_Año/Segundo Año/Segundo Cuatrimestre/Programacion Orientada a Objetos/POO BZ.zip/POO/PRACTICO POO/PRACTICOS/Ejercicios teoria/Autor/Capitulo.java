public class Capitulo{ 
    private int numeroCapitulo; 
    private int cantidadPaginas; 
    public Capitulo(int p_numero, int p_cantiPag) { 
        this.setNumeroCapitulo(p_numero); 
        this.setCantidadPaginas(p_cantiPag); 
    } 

    public void setNumeroCapitulo(int p_numero) { 
        this.numeroCapitulo = p_numero;   
    } 

    public void setCantidadPaginas(int p_cantiPag) { 
        this.cantidadPaginas = p_cantiPag;   
    } 

    public int getNumeroCapitulo() { 
        return this.numeroCapitulo;   
    } 

    public int getCantidadPaginas() { 
        return this.cantidadPaginas;   
    } 

    public void mostrar(){ 
        System.out.println("Capítulo " + this.getNumeroCapitulo() + " - " 
            + this.getCantidadPaginas() + " pág."); 
} 
}