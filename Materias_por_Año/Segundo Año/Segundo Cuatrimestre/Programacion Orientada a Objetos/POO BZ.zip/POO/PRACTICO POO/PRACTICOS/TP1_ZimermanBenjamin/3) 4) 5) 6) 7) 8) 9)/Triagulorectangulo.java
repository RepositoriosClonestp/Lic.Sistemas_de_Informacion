public class Triagulorectangulo {

    public static void main (String [] args){
        double a = Double.parseDouble(args[0]);//Hipotenusa
        double b = Double.parseDouble(args[1]);//Cateto 1
        double c = Double.parseDouble(args[2]);//Cateto 2
        double pit_a =(Math.pow(2, a));
        double pit_bc = ((Math.pow(2, b)) + (Math.pow(2, c)));

        if(pit_a == pit_bc){
            System.out.println("Triangulo Rectangulo: " +pit_a);

        }else {
            System.out.println("No es triangulo rectangulo.");
            System.out.println("Hipotenusa= " +pit_a+ ". Suma del cuadrado de los catetos= "+pit_bc);
        }
       
    }
}
