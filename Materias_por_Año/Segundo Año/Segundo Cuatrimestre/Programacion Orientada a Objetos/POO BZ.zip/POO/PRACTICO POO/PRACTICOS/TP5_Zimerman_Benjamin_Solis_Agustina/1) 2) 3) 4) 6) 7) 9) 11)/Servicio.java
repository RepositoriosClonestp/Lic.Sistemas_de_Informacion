/**
 * Clase Servicio.
 * 
 * <p>La clase Servicio representa un servicio con una descripción y un precio.</p>
 * 
 * @autor Zimerman Benjamin
 * @autor Solis Agustina A.
 * @version 28/8/24
 */
public class Servicio {

    /**
     * Descripción del servicio.
     */
    private String descripcion;

    /**
     * Precio del servicio.
     */
    private double precio;

    /**
     * Constructor de la clase Servicio.
     * 
     * @param p_descripcion la descripción del servicio
     * @param p_precio el precio del servicio
     */
    public Servicio(String p_descripcion, double p_precio) {
        this.setDescripcion(p_descripcion);
        this.setPrecio(p_precio);
    }

    /**
     * Establece la descripción del servicio.
     * 
     * @param p_descripcion la nueva descripción del servicio
     */
    private void setDescripcion(String p_descripcion) {
        this.descripcion = p_descripcion;
    }

    /**
     * Establece el precio del servicio.
     * 
     * @param p_precio el nuevo precio del servicio
     */
    private void setPrecio(double p_precio) {
        this.precio = p_precio;
    }

    /**
     * Obtiene la descripción del servicio.
     * 
     * @return la descripción del servicio
     */
    public String getDescripcion() {
        return this.descripcion;
    }

    /**
     * Obtiene el precio del servicio.
     * 
     * @return el precio del servicio
     */
    public double getPrecio() {
        return this.precio;
    }
}
