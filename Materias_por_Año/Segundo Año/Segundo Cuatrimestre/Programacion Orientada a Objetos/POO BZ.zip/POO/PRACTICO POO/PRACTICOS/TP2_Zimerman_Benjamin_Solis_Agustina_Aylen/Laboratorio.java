/**DEFINICION CLASE LABORATORIO**/
public class Laboratorio{
    /**ATRIBUTOS DE LA CLASE**/ 
    private String nombre;
    private String domicilio;
    private String telefono;
    private int compraMinima;
    private int diaEntrega;
    /**METODO CONSTRUCTOR: crea e inicializa objetos de la clase LABORATORIO teniendo como firma 3 String y 2 int como tipo de dato*/

    public Laboratorio(String p_nombre, String p_domicilio, String p_telefono, int p_compraMin, int p_diaEnt){
        this.setNombre(p_nombre);
        this.setDomicilio(p_domicilio);
        this.setTelefono(p_telefono);
        this.setCompMin(p_compraMin);
        this.setDiaEnt(p_diaEnt);    
    }

    /**METODO CONSTRUCTOR: crea e inicializa objetos de la clase LABORATORIO teniendo como firma 3 String como tipo de dato*/
    public Laboratorio(String p_nombre, String p_domicilio, String p_telefono){
        this.setNombre(p_nombre);
        this.setDomicilio(p_domicilio);
        this.setTelefono(p_telefono);
    }

    /**SETTERS*/
    /**setNombre(): modifica el valor del atributo nombre de tipo String */   
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }

    /**setDomicilio(): modifica el valor del atributo domicilio de tipo String*/   
    private void setDomicilio(String p_domicilio){
        this.domicilio = p_domicilio;
    }

    /**setTelefono(): modifica el valor del atributo telefono de tipo String*/  
    private void setTelefono(String p_telefono){
        this.telefono = p_telefono;
    }

    /**setCompMin(): modifica el valor del atributo compramMinima de tipo int*/   
    private void setCompMin(int p_compraMin){
        this.compraMinima = p_compraMin;
    }

    /**setDiaEnt(): modifica el valor del atributo diaEntrega de tipo int */   
    private void setDiaEnt(int p_diaEnt){
        this.diaEntrega = p_diaEnt;
    }

    /**GETTERS*/
    /**getNombre(): obtiene el valor del atributo nombre de tipo String **/
    public String getNombre(){
        return nombre;
    }

    /**getDomicilio(): obtiene el valor del atributo domicilio de tipo String **/
    public String getDomicilio(){
        return domicilio;
    }

    /**getTelefono(): obtiene el valor del atributo telefono de tipo  **/
    public String getTelefono(){
        return telefono;
    }

    /**getCompraMinima(): obtiene el valor del atributo compraMinima de tipo int **/
    public int getCompraMinima(){
        return compraMinima;
    }

    /**getDiaEntrega(): obtiene el valor del atributo diaEntrega de tipo int  **/
    public int getDiaEntrega(){
        return diaEntrega;
    }

    /**METODO EN CASO DE QUE LA EMPRESA VARIE SU POLITICA O REGLAS DE NEGOCIOS QUE PERMITEN MODIFICAR LOS ATRIBUTOS ASIGNANDOLE NUEVOS VALORES. Metodo que devuelve compra minima*/
    public void nuevaCompraMinima(int p_compraMin){
        this.getCompraMinima();
    }

    /**METODO EN CASO DE QUE LA EMPRESA VARIE SU POLITICA O REGLAS DE NEGOCIOS QUE PERMITEN MODIFICAR LOS ATRIBUTOS ASIGNANDOLE NUEVOS VALORES. Metodo que devuelve nuevo dia de entrega*/
    public void nuevoDiaEntrega(int p_diaEnt){
        this.setDiaEnt(p_diaEnt);
    }

    /**Metodo mostrar: imprime por pantalla los valores de los atributos en base al estado del objeto */
    public void mostrar(){
        System.out.println("Laboratorio: "+this.nombre);
        System.out.println("Domicilio: "+this.domicilio);
        System.out.println("Telefono: "+this.telefono);
    }
}