import java.util.Calendar;
import java.util.GregorianCalendar;
/**Paquetes de Java importados para el calculo del año**/
/**DEFINICION CLASE PERSONA**/
public class Persona {
    /**ATRIBUTOS DE LA CLASE**/ 
    private int nroDni;
    private String nombre;
    private String apellido;
    private int anioNacimiento;

    /**METODO CONSTRUCTOR: crea e inicializa objetos de la clase EMPLEADO*/
    public Persona(int p_dni, String p_nombre, String p_apellido, int p_anio) {
        this.setDNI(p_dni);//Doble encapsulamiento, 
        this.setNombre(p_nombre);
        this.setApellido(p_apellido);
        this.setAnio(p_anio);
    }

    /**SETTERS**/
    /**setDni(): modifica el valor DNI del atributo de tipo int*/
    private void setDNI(int p_dni) {
        this.nroDni = p_dni;
    }
    
    /**setNombre(): modifica el valor del atributo nombre de tipo String*/
    private void setNombre(String p_nombre) {
        this.nombre = p_nombre;
    }

    /**setApellido(): modifica el valor del atributo apellid de tipo String*/
    private void setApellido(String p_apellido) {
        this.apellido = p_apellido;
    }

    /**setAnio(): modifica el valor del atributo anioNacimiento de tipo int*/
    private void setAnio(int p_anio) {
        this.anioNacimiento = p_anio;
    }

    /**GETTERS */
    /**getDni(): obtiene el valor del atributo Dni de tipo int  **/
    public int getDni() {
        return nroDni;
    }
    
    /**getNombre(): obtiene el valor del atributo nombre de tipo String **/
    public String getNombre() {
        return nombre;
    }
    
    /**getApellido(): obtiene el valor del atributo apellido de tipo String **/
    public String getApellido() {
        return apellido;
    }
    
    /**getAnio(): obtiene el valor del atributo anioNacimiento de tipo int **/
    public int getAnio() {
        return anioNacimiento;
    }

    /**METODO nomYAPE(): metodo publico que Concatena nombre y apelido**/
    public String nomYApe(){
        return this.getNombre()+ ", " +this.getApellido();
    }

    /**METODO apeYNom (): metodo publico que concatena aprllido y nombre**/
    public String apeYNom(){
        return this.getApellido()+ ", " +this.getNombre();
    }

    /**METODO EDAD: metodo publico que devuelve un int y permite calcular la edad de la persona a la fecha**/
    public int edad() {
        Calendar fechaHoy = new GregorianCalendar();/**Nueva variable fecha de hoy*/
        int anioHoy = fechaHoy.get(Calendar.YEAR);/**Asigno valor entero a la fecha*/
        return anioHoy - this.getAnio();/**Resto al año actual el de nacimiento*/
    }

    /**Metodo mostrar: imprime por pantalla los valores de los atributos en base al estado del objeto */
    public void mostrar() {
        System.out.println("DNI: " +this.getDni());
        System.out.println("Nombre y apellido: " +nomYApe());
        System.out.println("Edad: " +edad() + " años");
    }
}
