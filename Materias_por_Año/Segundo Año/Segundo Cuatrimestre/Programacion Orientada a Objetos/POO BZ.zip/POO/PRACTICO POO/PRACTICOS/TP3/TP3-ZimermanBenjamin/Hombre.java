
/**
 * Ejercicio 10.CLASE HOMBRE.
 * 
 * @author (Zimerman Benjamin, Solis Agustina) 
 * @version (6/09/24)
 */
public class Hombre
{   /**ATRIBUTOS*/
    private String nombre;
    private String apellido;
    private int edad;
    private String estadoCivil;
    private Mujer esposa;
    
    /**METODO CONSTRUCTOR: permite crear e instanciar objetos de la clase hombre
     * @param p_nombre: nombre del hombre.
     * @param p_apellido: apellido del hombre
     * @param p_edad: edad del hombre
    */
    public Hombre(String p_nombre, String p_apellido, int p_edad){
        this.setNombre(p_nombre);
        this.setApellido(p_apellido);
        this.setEdad(p_edad);
        this.setEstCiv("Soltero");
    }
    
    /**METODO CONSTRUCTOR: permite crear e instanciar objetos de la clase hombre
     * @param p_nombre: nombre del hombre.
     * @param p_apellido: apellido del hombre
     * @param p_edad: edad del hombre
     * @param p_esposa: esposa del hombre.
    */
    public Hombre(String p_nombre, String p_apellido, int p_edad, Mujer p_esposa){
        this.setNombre(p_nombre);
        this.setApellido(p_apellido);
        this.setEdad(p_edad);
        this.setEsposa(p_esposa);
    }
    
    /**ACCESORS*/
    /**setNombre(String p_nombre): actualiza el estado del atributo nombre
     * @param p_nombre: nombre del hombre
    */
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    /**setApellido(String p_apellido):actualiza el estado del atributo apellido
     * @param p_apellido: apellido del hombre 
    */
    private void setApellido(String p_apellido){
        this.apellido = p_apellido;
    }
    
    /**setEdad(int p_edad): actualiza el estado del atributo edad
     * @param p_edad: edad del hombre
    */
    private void setEdad(int p_edad){
        this.edad = p_edad;
    }
    
    /**setEstCiv(String p_estCiv): actualiza el estado del atributo estadoCivil.
     * @param p_estCiv: estado civil del hombre
    */
    private void setEstCiv(String p_estCiv){
        this.estadoCivil = p_estCiv;
    }
    
    /**setEsposa(Mujer p_esposa): actualiza el estado del atributo esposa
     * @param p_esposa: esposa del hombre
    */
    private void setEsposa(Mujer p_esposa){
        this.esposa = p_esposa;
    }

    /**GETTERS*/
    /**getNombre(): obtiene el estado del atributo nombre
       @return: nombre
    */
   
    public String getNombre(){
        return this.nombre;
    }
    
    /**getApellido():obtiene el estado del atributo apellido.
     * @return apellido;
    */
    public String getApellido(){
        return this.apellido;
    }
    
    
    /**getEdad(): obtiene el estado del atributo edad
     * @return edad.
    **/
    public int getEdad(){
        return this.edad;
    }
    
    /**getEstCiv(): obtiene el estado del atributo estadoCivil
     * @return estadoCivil
    */
    public String getEstCiv(){
        return this.estadoCivil;
    }
    
    /**getEsposa(): obtiene el estado del atributo esposa
     * @return esposa
    */
    public Mujer getEsposa(){
        return this.esposa;
    }
    
    /**Metodo divorcio(): actualiza el estado civil del hombre: si esta casad, modifica el atributo EstCiv a soltero y setea el 
       atributo esposa a null*/
    public void divorcio(){
        if(this.getEstCiv() == "Casado"){
            this.setEstCiv("Soltero");
            this.esposa.divorcio();
            this.setEsposa(null);
        }
    }
    
    /** metodo casarseCon(Hombre p_hombre): asigna el objeto p_mujer al atributo esposa del hombre y modifica 
       su atributo EstCiv a casado 
       @param p_mujer: objeto mujer.
       */
    public void casarseCon(Mujer p_mujer) {
        if (this.getEsposa() == null) {
            this.setEstCiv("Casado");
            this.setEsposa(p_mujer);
            p_mujer.casarseCon(this);
        }
    }
    
    /**metodo datos(): concatena en un string los estados de los atributos nombre, apellido y edad
     * @return un srting con dicha concatenacion
    */
    public String datos(){
        return this.getNombre()+ " " +this.getApellido()+ " de " +this.getEdad()+ " años";
    }
    
      /**mostrarEstadoCivil(): imprime por pantalla el estado del atributo EstCiv**/
    public void mostrarEstadoCivil(){
        System.out.println("Estado civil: "+this.getEstCiv());
    }
    
      /**casadaCon(): imprime por pantalla el estado del atributo datos y Esposa*/
    public void casadoCon(){
        System.out.println(this.datos()+ " esta casado con "+this.getEsposa().datos());
    }
}

