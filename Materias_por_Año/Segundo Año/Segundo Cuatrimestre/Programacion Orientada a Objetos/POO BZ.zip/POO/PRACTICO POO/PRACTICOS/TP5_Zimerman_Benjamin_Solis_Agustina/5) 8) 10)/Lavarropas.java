
/**
 * Write a description of class Lavarropas here.
 * 
 * @author (Solis Agustina, Zimerman Benjamin) 
 * @version (10/10/24)
 */
public class Lavarropas extends ArtefactoHogar {
    private int programas; 
    private float kilos; 
    private boolean automatico; 
    private int cuotas; 
    private float interes;
    /**
     * Constructor for objects of class Lavarropas: crea e inicializa objetos de la clase Lavarropas
     * @param: p_marca: marca del electrodomedisto
       @param p_stock. stock disponible
       @param p_precio: precio del equipo
       @param p_programas: cantidad de programas de lavado
       @param p_kilos: kilos que puede lavar
       @param p_auto: true si es automatico, false en caso contrario
       **/
    public Lavarropas(int p_programas, float p_kilos, boolean p_auto,String p_marca, int p_stock, float p_precio){
      super(p_marca, p_stock, p_precio); 
      this.setProgramas(p_programas); 
      this.setKilos(p_kilos);
      this.setAutomatico(p_auto); 
    }
    
    
    /**ACCESORS**/
    /**setters**/
    private void setProgramas(int p_programas){
        this.programas = p_programas; 
    }
    private void setKilos (float p_kilos) {
        this.kilos = p_kilos;
    }
    
    private void setAutomatico(boolean p_auto) {
        this.automatico = p_auto; 
    }
    
    private void setCuotas(int p_cuotas){
        this.cuotas = p_cuotas; 
    }
    
    private void setInteres(float p_interes) {
        this.interes = p_interes; 
    }
    
    /**getters*/
    public int getProgramas (){
        return this.programas; 
    }
    
    public float getKilos() {
        return this.kilos; 
    }
    
    public int getCuotas(){
        return this.cuotas; 
    }
    
    public boolean getAutomatico () {
        return this.automatico; 
    }
    
    public float getInteres(){
        return this.interes; 
    }
    
    /**METODOS*/
    /**public float creditoConAdicional(int p_cuotas, float p_interes): 
       calcula el valor total de las cuotas de un lavarropas: si no es automatico, se le descuenta un 2% a cada cuota
       @return precio final de cada cuota**/
    public float creditoConAdicional(int p_cuotas, float p_interes){
         float total=0; 
         if (this.getAutomatico() == false){
             total=super.cuotaCredito(p_cuotas, p_interes) - (2 * this.getCuotas()/100);
            } else {
                total = super.cuotaCredito(p_cuotas, p_interes);  
            }
         return total; 
     }
     /**public void imprimir(): imprime por pantalla la marca, stock y precio del producto, 
        asi como tambien eñ estado de sus atributos programas, kilos y automatico**/
    public void imprimir (int p_cuotas, float p_interes){
        System.out.println ("***LAVARROPAS***");
        super.imprimir();
        System.out.println ("Programas: "+this.getProgramas());
        System.out.println ("Kilos: "+this.getKilos());
        if (this.getAutomatico() == true){
            System.out.println ("Automatico: SI");
            System.out.println ("Valor Cuota: "+super.cuotaCredito(p_cuotas, p_interes));
            System.out.println ("Valor Cuota con Adicional:" +this.creditoConAdicional (p_cuotas, p_interes));
        }else {
            System.out.println ("Automatico: NO");
            System.out.println ("Valor Cuota: "+super.cuotaCredito(p_cuotas, p_interes));
            System.out.println ("Valor Cuota con Adicional:" +this.creditoConAdicional (p_cuotas, p_interes));
        
        }
    }
}
