/**
 * Ejercicio 5.CLASE EJECUTABLE SECRETARIA
 * 
 * @author (Zimerman Benjamin, Solis Agustina A.) 
 * @version ()
 */
import java.util.Scanner;
public class Secretaria{
    public static void main(String [] args){
        Scanner scan = new Scanner(System.in);

        System.out.println("\nIngrese Nombre de la escuela: ");
        String nomb = scan.nextLine();
        System.out.println("\nIngrese Domicilio de la escuela: ");
        String dom = scan.nextLine();
        System.out.println("\nIngrese Director de la escuela: ");
        String dir = scan.nextLine();

        System.out.println("\nIngrese un Docente: ");
        String doc = scan.nextLine();

        System.out.println("\nIngrese Sueldo Basico: ");
        double sb = scan.nextDouble();

        System.out.println("\nIngrese Asigancion Familiar: ");
        double af = scan.nextDouble();
        
        System.out.println("\nIngrese grado: ");
        String gr = scan.nextLine();

        Docente docen = new Docente(doc, gr, sb, af);
        
        Escuela esc = new Escuela(nomb, dom, dir, docen);
        
        esc.imprimirRecibo(docen);
        
        scan.close();
    }
}
