/**
 * Clase Comun que hereda de Etiqueta.
 */
public class Comun extends Etiqueta {

    /**
     * Plus adicional de la etiqueta.
     */
    private double plus;

    /**
     * Constructor de la clase Comun.
     *
     * @param p_plus el plus adicional de la etiqueta
     * @param p_costo el costo de la etiqueta
     */
    public Comun(double p_plus, double p_costo) {
        super(p_costo);
        this.plus = p_plus;
    }

    /**
     * Calcula el precio en base a la cantidad con descuentos aplicados.
     *
     * @param q la cantidad
     * @return el precio calculado con descuentos
     */
    public double precio(int q) {
        return q - (q * descuento(q));
    }

    /**
     * Calcula el descuento en base a la cantidad.
     *
     * @param q la cantidad
     * @return el descuento calculado
     */
    private double descuento(int q) {
        if (q >= 1 && q <= 10) {
            return 0;
        } else if (q >= 11 && q <= 50) {
            return 0.02;
        } else if (q >= 51 && q <= 100) {
            return 0.05;
        } else {
            return 0.01;
        }
    }

    /**
     * Retorna el tipo de etiqueta.
     *
     * @return una cadena que representa el tipo de etiqueta
     */
    protected String tipo() {
        return "Comun";
    }

    /**
     * Retorna una representación en cadena del ítem Comun.
     *
     * @return una cadena que representa el ítem Comun
     */
    public String toString() {
        return super.toString() + " - Plus: " + this.plus;
    }
}
