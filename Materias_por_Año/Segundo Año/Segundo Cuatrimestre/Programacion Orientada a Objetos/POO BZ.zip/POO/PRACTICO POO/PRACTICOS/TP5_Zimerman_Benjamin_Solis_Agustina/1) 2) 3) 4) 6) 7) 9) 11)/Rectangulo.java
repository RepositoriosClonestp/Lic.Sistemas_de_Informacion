/**
 * CLASE RECTANGULO: 
 *
 * @author Zimerman Benjamin, Solis Agustina Aylen
 * @version (2/10/24)
 */
 
public class Rectangulo extends FiguraGeometrica{
    /**ATRIBUTOS*/

    private double ancho;
    private double alto;

    /**METODO CONSTRUCTOR: permite crear e inicializar objetos de la clase Rectangulo
    @param p_origen: esquina inferior izquierda del rectangulo, que es un objeto de clase Punto (X,Y)
    @param p_ancho: ancho del rectangulo
    @param p_alto: altura del rectangulo*/
    public Rectangulo(Punto p_origen, double p_ancho, double p_alto){
        super(p_origen);
        this.setAncho(p_ancho);
        this.setAlto(p_alto);
    }

    /**METODO CONSTRUCTOR: permite crear e inicializar objetos de la clase Rectangulo
    @param p_ancho: ancho del rectangulo
    @param p_alto: altura del rectangulo
     */
    public Rectangulo(double p_ancho, double p_alto){
        super(new Punto (0, 0));
        this.setAncho(p_ancho);
        this.setAlto(p_alto);
    }

    /**ACCESORS*/
    /**SETTERS*/
    private void setAncho(double p_ancho){
        this.ancho = p_ancho;
    }

    private void setAlto(double p_alto){
        this.alto = p_alto;
    }

    /**GETTERS*/
    public double getAncho(){
        return this.ancho;
    }

    public double getAlto(){
        return this.alto;
    }

    /**METODO DESPLAZAR: permite dezplazar al rectangulo a una nueva posicion (X,Y) sin cambiar sus dimensiones
    @param double dx: coordenada X del punto a donde se va a desplazar el rectangulo
    @param double dy: coordenada Y del punto a donde se va a desplazar el rectangulo*/
    public void desplazar(double dx, double dy) { 
        Punto origen = super.getOrigen();
        Punto newOrigen = new Punto(origen.getX() + dx, origen.getY() + dy);
        super.setOrigen(newOrigen);        
    } 

    /**Metodo superficie():  calculo de la superficie del rectangulo*/
    public double superficie(){
        return this.getAlto() * this.getAncho();
    }

    /**Metodo perimetro():  calculo del perimetro del rectangulo*/
    public double perimetro(){
        return ((this.getAlto() * 2) + (this.getAncho() * 2));
    }

    /**Metodo distanciaA: obtiene la distancia entre las coordenadas de los 2 circulos en base a pitagoras
    @param otroRectangulo: objeto auxiliar de la clase Rectangulo
    @return distancia entre el rectangulo emisor del mensaje y el nuevo rectangulo auxiliar ingresado como parametro*/
    public double distanciaA(Rectangulo otroRectangulo){
        Punto or1 = this.getOrigen();
        Punto or2 = otroRectangulo.getOrigen();

        double dx = or1.getX() - or2.getX();
        double dy = or1.getY() - or2.getY();
        double distancia = (Math.sqrt((Math.pow(dx, 2 )) + (Math.pow(dy, 2))));
        return distancia;
    }

    /**Metodo elMayor devuelve el rectangulo mayor en base al analisis de sus superficies
    @param otroRectangulo: objeto auxiliar de la clase Rectangulo
    @return el rectangulo de mayor superficie
     */    
    public Rectangulo elMayor(Rectangulo otroRectangulo){
        double rec1 = this.superficie();
        double rec2 = otroRectangulo.superficie();

        if (rec1 > rec2) {
            return this;
        } else {
            return otroRectangulo;
        }
    }    

    /**METODO MOSTRAR DATOS*/
    public void caracteristicas() {
        this.nombreFigura();
        System.out.println("Origen: "+super.coordenadas()+ " - Alto: " +this.getAlto()+ " - Ancho: "+this.getAncho());
        System.out.println("Superficie: "+superficie()+ " - Perimetro: "+perimetro());
    }

    public String nombreFigura() {
        System.out.println("*****Rectángulo*****");
        return "Rectángulo"; // Puedes devolver el nombre de la figura como cadena si lo necesitas
    }

    
}
