/**
 * Ejercicio 2 Ejecutable Punto
 * @author Zimerman Benjamin, Solis Agustina Aylen 
 * @version (27/8/24)
 */

public class EjecutablePunto {
    public static void main(String[] args) {
        if (args.length != 4) {
            System.out.println("Debe proporcionar 4 argumentos: x1, y1, x2, y2");
            return;
        }

        double x1 = Double.parseDouble(args[0]);
        double y1 = Double.parseDouble(args[1]);
        double x2 = Double.parseDouble(args[2]);
        double y2 = Double.parseDouble(args[3]);

        Punto p1 = new Punto(x1, y1);
        Punto p2 = new Punto(x2, y2);

        double dist = p1.distanciaA(p2);
        System.out.println("Distancia entre los puntos: " + dist);
        p1.mostrar();
        p2.mostrar();
    }
}