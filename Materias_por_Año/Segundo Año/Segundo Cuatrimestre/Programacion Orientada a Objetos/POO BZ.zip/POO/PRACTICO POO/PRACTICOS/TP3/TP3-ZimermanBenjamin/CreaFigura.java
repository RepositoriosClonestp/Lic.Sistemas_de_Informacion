/**
 * CLASE EJECUTABLE CREA FIGURA, Ejercicio 3 y 4
 *
 * @author Zimerman Benjamin, Solis Agustina Aylen
 * @version (28/8/24)
 */

import java.util.Scanner;
import java.util.Random;
import java.util.ArrayList;

public class CreaFigura
{
    public static void main(String [] args){
        Scanner scan = new Scanner(System.in);
        Random rand = new Random();
        System.out.println("        ----------CIRCULOS---------- \n");

        /**Se instancia nuevo objeto 1° de la clase Circulo*/
        double r1 = rand.nextDouble() * 100.0;/**Atributo Radio random*/
        Punto c1 = new Punto(0, 0);/**Atributo Centro inicializado en la coordenada (0, 0)*/
        Circulo circ1 = new Circulo(r1, c1);/**Instanciacion del objeto llamado circ1*/
        
        //circ1.caracteristicas();/**Se imprime las caracteristicas del circ 1*/

        circ1.desplazar(-240.0, -230.0);/**Se desplaza el objeto circ1 240 unidades a la izquierda y 230 unidades hacia abajo*/
        System.out.println("Caracteristicas del primer circulo creado: ");        
        circ1.caracteristicas();/**Se imprime las caracteristicas del circ 1*/
        
        /**Se instancia nuevo objeto 2° de la clase Circulo*/
        double r2 = rand.nextDouble() * 100.0;/**Atributo Radio random*/
        Punto c2 = new Punto(5.2, 0.5);/**Atributo Centro inicializado en la coordenada (0, 0)*/
        Circulo circ2 = new Circulo(r2, c2);/**Instanciacion del objeto llamado circ2*/

        //circ2.caracteristicas();/**Se imprime las caracteristicas del circ 2*/

        Circulo mayor = circ1.elMayor(circ2);/**Se */
        System.out.println("\nCaracteristicas del mayor de los circulos creados: ");
        mayor.caracteristicas();/**Imprime las caracteristicas del circulo mas grande respecto a sus radios*/

        System.out.println("\nDistancia entre los centros de los círculos: " + circ1.distanciaA(circ2));/**Distancia entre los circulos respecto sus centros*/

        /**EJECUTABLE DEL EJERCICIO 4*/

        System.out.println("\n        ----------RECTANGULOS---------- \n");

        /**Se intancia nuevo objeto 1° de la clase Rectangulo*/
        Punto o1 = new Punto(0, 0);/**Atributo de clase Punto inicializado en coordenadas (0, 0)*/
        double ancho1 = rand.nextDouble() * 100.0;/**Atributo Ancho aleatorio*/
        double alto1 = rand.nextDouble() * 100.0;/**Atributo Alto aleatorio*/

        Rectangulo rec1 = new Rectangulo(o1, ancho1, alto1);/**Instanciacion del objeto rec1*/

        rec1.desplazar(40, -20);/**Se desplaza el objeto 40 unidades a la derecha y 20 unidades hacia abajo*/

        rec1.caracteristicas();/**Caracteristicas del objeto*/

        /**Se intancia nuevo objeto 2° de la clase Rectangulo*/
        Punto o2 = new Punto(7.4, 4.5);/**Atributo Origen de clase Punto inicializado en coordenadas (7.4, 4.5)*/
        double ancho2 = rand.nextDouble() * 100.0;/**Atributo Ancho aleatorio*/
        double alto2 = rand.nextDouble() * 100.0;/**Atributo Alto aleatorio*/

        Rectangulo rec2 = new Rectangulo(o2, ancho2, alto2);/**Instanciacion del objeto rec2*/
        //rec2.caracteristicas();

        Rectangulo mayorR = rec1.elMayor(rec2);
        System.out.println("\nCaracteristicas del mayor de los rectanuglos creados: ");
        mayorR.caracteristicas();/**Imprime caracteristicas del mayor*/

        System.out.println("\nDistancia entre los rectangulos: " + rec1.distanciaA(rec2));/**Imprime distancia entre los origenes de los recctanuglos*/

        scan.close();
    }
}