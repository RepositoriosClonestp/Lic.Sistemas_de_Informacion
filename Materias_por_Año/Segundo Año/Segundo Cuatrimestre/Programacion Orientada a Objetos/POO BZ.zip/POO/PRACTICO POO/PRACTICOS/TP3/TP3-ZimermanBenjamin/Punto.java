/**
 * Ejercicio 2. Punto
 * @author Zimerman Benjamin, Solis Agustina Aylen 
 * @version (27/8/24)
 */
/**DEFINICION CLASE PUNTO: reutilizacion de la clase Punto ya definida para agregarle nuevos comportamientos**/

public class Punto{
    /**ATRIBUTOS DE LA CLASE**/
    private double x;
    private double y;
    
    /**METODO CONSTRUCTOR: crea e inicializa objetos de la clase Punto**/
    public Punto(){
        this.x = 0;
        this.y = 0;
    }

    /**METODO CONSTRUCTOR Punto (double x_p, double y_p): crea e inicializa objetos de la clase Punto*
       @param x_p: coordenada X del punto
       @param y_p: coordenada P del punto*/
    public Punto(double x_p, double y_p){
        this.setX(x_p);
        this.setY(y_p);
    }

    /**SETTERS**/
    /**setX: permite modificar el valor del atributo x de tipo double**/
    private void setX(double x_p){
        this.x = x_p;
    }

    /**setY: permite modificar el valor del atributo y de tipo double**/
    private void setY(double y_p){
        this.y = y_p;
    }
    
    /**GETTERS**/
    /**getX: permite obtener el valor del atributo x de tipo double*
    @return valor del atributo x*/
    public double getX(){
        return x;
    }

    /**getY: permite obtener el valor del atributo y de tipo double*
    @return valor del atributo Y*/
    public double getY(){
        return y;
    }

    /**METODO desplazar(double p_dx, double p_dy): metodo publico que permite actualizar los valores de x e y al desplazarlos (suma los valores x + p_dx e y+p_dy) **/
    public void desplazar(double p_dx, double p_dy){
        this.setX(this.getX() + p_dx);
        this.setY(this.getY() + p_dy);
    }

    /**METODO coordenadas (): asiga al atributo cadena un string que concatena los valores de los atributos x e y y lo devuelve
    @return un String con las coordenadas del punto (X,Y)**/
    public String coordenadas(){
        String cadena = "(" +this.getX()+ ", "+this.getY()+ ")";
        System.out.println(cadena);
        return cadena ;
    }
    
    /**METODO distanciaA (Punto p_ptoDistante): calcula la distancia desde él mismo (el objeto que recibe el mensaje) hasta otro objeto Punto que es recibido como parámetro.  
    @return: la distancia entre el punto receptor del mensaje y el punto ingresado como parametro */
    public double distanciaA(Punto p_ptoDistante){
        double dx2 = this.getX() - p_ptoDistante.x;
        double dy2 = this.getY() - p_ptoDistante.y;
        double distancia = (Math.sqrt((Math.pow(dx2, 2 )) + (Math.pow(dy2, 2))));
        return distancia;
    }

    /**METODO mostrar (): metodo publico que imprime por pantalla el string "Punto x: (valor de x) y:(valor de y)"**/
    public void mostrar(){
        System.out.println("Punto. X: "+this.getX()+ " Y: "+this.getY());
    }
}

