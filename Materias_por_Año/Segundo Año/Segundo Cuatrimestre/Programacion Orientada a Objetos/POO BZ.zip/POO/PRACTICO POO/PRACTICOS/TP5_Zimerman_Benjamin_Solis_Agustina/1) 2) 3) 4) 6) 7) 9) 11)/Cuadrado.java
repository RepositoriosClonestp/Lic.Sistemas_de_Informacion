/**
 * CLASE RECTANGULO:
 * 
 * <p>La clase Cuadrado representa un cuadrado, que es una extensión de la clase Rectangulo.</p>
 * 
 * @autor Zimerman Benjamin
 * @autor Solis Agustina Aylen
 * @version 2/10/24
 */
public class Cuadrado extends Rectangulo {

    /**
     * Lado del cuadrado.
     */
    double lado;

    /**
     * Constructor de la clase Cuadrado.
     * 
     * @param p_origen el punto de origen del cuadrado
     * @param p_lado el lado del cuadrado
     */
    public Cuadrado(Punto p_origen, double p_lado) {
        super(p_origen, p_lado, p_lado);
        this.setLado(p_lado);
    }

    /**
     * Establece el lado del cuadrado.
     * 
     * @param p_lado el nuevo lado del cuadrado
     */
    private void setLado(double p_lado) {
        this.lado = p_lado;
    }

    /**
     * Obtiene el lado del cuadrado.
     * 
     * @return el lado del cuadrado
     */
    private double getLado() {
        return this.lado;
    }

    /**
     * Retorna el nombre de la figura.
     * 
     * @return el nombre de la figura
     */
    public String nombreFigura() {
        System.out.println("*****Cuadrado*****");
        return "Cuadrado";
    }

    /**
     * Muestra las características del cuadrado.
     */
    public void caracteristicas() {
        super.caracteristicas();
    }

    /**
     * Calcula la superficie del cuadrado.
     * 
     * @return la superficie del cuadrado
     */
    public double superficie() {
        return super.superficie();
    }
}
