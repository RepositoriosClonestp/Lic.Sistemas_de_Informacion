public class Autor{
        private String nombre;
        private String institucion;
        private String mail;
        /**CONSTRUCTOR*/
    public Autor (String p_autor, String p_institucion, String p_mail){
        this.nombre = p_autor;
        this.institucion = p_institucion;
        this.mail = p_mail;
    }
    
    private void setNombre (String p_nombre){
        this.nombre = p_nombre;
    }
    
    private void setInstitucion(String p_institucion){
        this.institucion = p_institucion;
    }
    
    private void setMail(String p_mail){
        this.mail = p_mail;
    }
    
    public String getNombre (){
        return nombre;
    }
    
    public String getInstitucion(){
        return institucion;
    }
    
    public String getMail (){
        return mail;
    }
    
    public void mostrar (){
        System.out.println("Autor: "+ this.getNombre());
        System.out.println("Institucion: "+this.getInstitucion());
        System.out.println("mail: "+this.getMail());
       
    }
}