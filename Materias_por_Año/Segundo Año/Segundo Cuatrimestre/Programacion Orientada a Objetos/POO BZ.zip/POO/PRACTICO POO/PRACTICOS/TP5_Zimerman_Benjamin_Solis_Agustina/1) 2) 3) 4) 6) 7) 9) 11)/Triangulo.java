/**
 * Clase Triangulo.
 * 
 * <p>La clase Triangulo representa un triángulo con una base y una altura específicas.</p>
 * 
 * @autor Zimerman Benjamin
 * @autor Solis Agustina Aylen
 * @version 2/10/24
 */
public class Triangulo extends FiguraGeometrica {

    /**
     * Base del triángulo.
     */
    private double base;

    /**
     * Altura del triángulo.
     */
    private double altura;

    /**
     * Constructor de la clase Triangulo.
     * 
     * @param p_base la base del triángulo
     * @param p_altura la altura del triángulo
     * @param p_punto el punto de origen del triángulo
     */
    public Triangulo(double p_base, double p_altura, Punto p_punto) {
        super(p_punto);
        this.setBase(p_base);
        this.setAltura(p_altura);
    }

    /**
     * Establece la base del triángulo.
     * 
     * @param p_base la nueva base del triángulo
     */
    private void setBase(double p_base) {
        this.base = p_base;
    }

    /**
     * Establece la altura del triángulo.
     * 
     * @param p_altura la nueva altura del triángulo
     */
    private void setAltura(double p_altura) {
        this.altura = p_altura;
    }

    /**
     * Obtiene la base del triángulo.
     * 
     * @return la base del triángulo
     */
    public double getBase() {
        return this.base;
    }

    /**
     * Obtiene la altura del triángulo.
     * 
     * @return la altura del triángulo
     */
    public double getAltura() {
        return this.altura;
    }

    /**
     * Retorna el nombre de la figura.
     * 
     * @return el nombre de la figura
     */
    public String nombreFigura() {
        String s = "***Triangulo***";
        return s;
    }

    /**
     * Calcula la superficie del triángulo.
     * 
     * @return la superficie del triángulo
     */
    public double superficie() {
        return (this.getBase() * this.getAltura()) / 2;
    }

}
