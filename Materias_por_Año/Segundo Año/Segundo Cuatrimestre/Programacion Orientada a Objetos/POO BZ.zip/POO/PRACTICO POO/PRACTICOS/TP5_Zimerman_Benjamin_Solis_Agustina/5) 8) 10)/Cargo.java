
/**
 * Write a description of class Cargo here.
 * 
 * @author (Solis Agustina, Zimerman Benjamin) 
 * @version (2/10/24)
 */

import java.util.Calendar;
import java.util.GregorianCalendar;

public class Cargo {
    private String nombreCargo; 
    private double sueldoBasico; 
    private int anioIngreso; 
    private int horasdeDocencia; 
    
    /**Metodo constructor: crea e inicializa objetos de clase Cargo: 
     * @param p_nombreC: nombre del cargo
     * @param p_sueldoB: sueldo del cargo
     * @param p_anioI: año en que el profesor asumio el cargo
     * @p_horas:horas trabajadas
       **/
    public Cargo (String p_nombreC, double p_sueldoB, int p_anioI, int p_horas) {
        this.setnombreCargo(p_nombreC); 
        this.setSueldoB(p_sueldoB);
        this.setAnio(p_anioI); 
        this.setHoras(p_horas);  
    }
    
    /**ACCESORS**/
    /**setters**/
    private void setnombreCargo(String p_nombreC){
        this.nombreCargo = p_nombreC;
    }
    
    private void setSueldoB(double p_sueldoB) {
        this.sueldoBasico = p_sueldoB; 
    }
    
    private void setAnio(int p_anioI) {
        this.anioIngreso = p_anioI; 
    }
    
    private void setHoras(int p_horas) {
        this.horasdeDocencia = p_horas; 
    }
    
    /**getters**/
    public String getNombreC() {
        return this.nombreCargo; 
    }
    
    public double getSueldoB() {
        return this.sueldoBasico; 
    }
    
    public int getAnioI() {
        return this.anioIngreso; 
    }
    
    public int getHoras() {
        return this.horasdeDocencia; 
    }
    
    /**METODOS**/
    /**antiguedad(): permite calcular la antiguedad del profesor en el cargo
       return cantidad de años en el cargo*/
    public int antiguedad() {
        Calendar fechaHoy = new GregorianCalendar();/**Nueva variable fecha de hoy*/
        int anioHoy = fechaHoy.get(Calendar.YEAR);/**Asigno valor entero a la fecha*/
        return anioHoy - this.getAnioI();/**Resto el año actual con el año de ingreso**/
    }
    
    /** public double adicionalAntiguedad(): metodo que aumenta un 1% el sueldo del docente por cada año de antiguedad en el cargo
       @return ,omto adicional**/
    public double adicionalAntiguedad(){
        int anti = antiguedad();
        double adicional=0; 
        for (anti=0; anti < 100; anti++) {
            adicional = this.getSueldoB() * 0.01; 
        }
        return adicional; 
    }
    
    /** public double sueldoDelCargo(): 
       @return el sueldo total: adicional + sueldo basico**/
    public double sueldoDelCargo() {
        return this.getSueldoB() + adicionalAntiguedad(); 
    }
    /**public void mostrarCargo(): imprime por pantalla los detalles del cargo**/
    public void mostrarCargo() {
        System.out.println ("---------------------------");
        System.out.println ("CARGO SIMPLE");
        System.out.println(this.getNombreC() + "\t-" + "Sueldo Basico: " +this.getSueldoB() + "\t-" + "Sueldo Cargo: "+sueldoDelCargo() + "\t-"+"Antiguedad:"+antiguedad() + "años");
        System.out.println ("Horas Docencia: 10");
        System.out.println ("---------------------------");
    }
}
