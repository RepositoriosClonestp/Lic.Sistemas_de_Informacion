/**
 * Ejercicio 3. CLASE CIRCULO: Se desea trabajar con un generador de figuras geométricas, y se inicia con el modelado de círculos, considerando para 
ello las características que lo definen, tales como el centro (objeto de clase Punto) y el radio.
 *
 * @author Zimerman Benjamin, Solis Agustina Aylen
 * @version (28/8/24)
 */
public class Circulo {
    /**Atributos*/
    private double radio;
    private Punto centro;

    /**Constructor implicito: inicializa el estado de los atributos Centro de clase Punto en (0,0) y el estado del atributo radio en 0*/
    public Circulo() {
        this.centro = new Punto(0, 0);
        this.radio = 0;
    }

    /**Constructor explicito
    @param p_radio: radio del circulo
    @param p_centro: centro del radio (X,Y)*/
    public Circulo(double p_radio, Punto p_centro) {
        this.setRadio(p_radio); 
        this.setCentro (p_centro); 
    }

    /**ACCESORS*/
    /**SETTERS*/
    
    /**setRadio(double p_radio): metodo privado que permite modificar el estado del atributo radio
       @param p_radio*/
    private void setRadio (double p_radio) {
        this.radio = p_radio;
    }

    /**setCentro(Punto p_centro): metodo privado que permite modificar el estado del atributo centro.
       @param p_centro*/
    private void setCentro (Punto p_centro){
        this.centro = p_centro; 
    }

    /**GETTERS*/
    /**getRadio(): obtiene el valor del atributo radio de tipo double
       @return radio*/
    public double getRadio (){
        return this.radio; 
    }
    
    /**getCentro(): obtiene el valor del atributo centro de tipo Punto
       @return centro*/
    public Punto getCentro () {
        return this.centro;
    }

    /**Metodo desplazar(double dx, double dy): se intancia el centro sumando los nuevos valores a los actuales y actualiza el valor de cada coordenada*/
    public void desplazar(double dx, double dy) {
        centro = new Punto(centro.getX() + dx, centro.getY() + dy);
        this.setCentro(centro);
    }

    /**Metodo perimetro():calcula el perimetro del circulo
       @return el perimetro del circulo, que es un valor double*/
    public double perimetro() {
        return 2 * Math.PI * radio;
    }

    /**Metodo superficie(): calcula la superficie del circulo
       @return la superficie del circulo*/
    public double superficie(){
        return Math.PI * Math.pow(radio, 2);
    }

    /**Metodo distanciaA: obtiene la distancia entre las coordenadas de los 2 circulos en base a pitagoras
       @param otroCirculo: circulo auxiliar
       @return la distancia entre los dos circulos*/
    public double distanciaA(Circulo otroCirculo){
        Punto centro1 = this.getCentro();
        Punto centro2 = otroCirculo.getCentro();

        double dx = centro1.getX() - centro2.getX();
        double dy = centro1.getY() - centro2.getY();
        double distancia = (Math.sqrt((Math.pow(dx, 2 )) + (Math.pow(dy, 2))));
        return distancia;
    }

    /**Metodo elMayor(Circulo otroCirculo): devuelve el circulo mayor en base al analisis de sus radios
       @param otroCirculo: circulo auxiliar
       @return devuelve el atributo circulo de mayor radio*/
    public Circulo elMayor(Circulo otroCirculo){
        double r1 = this.getRadio();
        double r2 = otroCirculo.getRadio();

        if (r1 > r2) {
            return this;
        } else {
            return otroCirculo;
        }
    }

    /**Metodo caracteristicas(): Imprime caracteristicas del circulo correspondiente*/
    public void caracteristicas() {
        System.out.println("Centro: (X: "+ centro.getX() + ", Y: " + centro.getY() + ") - Radio: " + radio);
        System.out.println("Superficie: "+superficie()+ " - Perimetro: "+perimetro());
    }
}
