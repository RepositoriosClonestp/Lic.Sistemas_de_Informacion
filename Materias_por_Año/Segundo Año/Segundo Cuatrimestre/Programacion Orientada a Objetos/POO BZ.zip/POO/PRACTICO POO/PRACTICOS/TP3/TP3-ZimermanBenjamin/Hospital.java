/**
 * CLASE HOSPITAL
 * 
 * @author (Zimerman Benjamin, Solis Agustina A.) 
 * @version (30/8/24)
 */
public class Hospital{
   private String nombreHospital;
   private String nombreDirector;
   
   public Hospital(String p_nomHos, String p_nomDir){
       this.setNomHos(p_nomHos);
       this.setNomDir(p_nomDir);
   }
   
   private void setNomHos(String p_nomHos){
       this.nombreHospital = p_nomHos;
   }
   
   private void setNomDir(String p_nomDir){
       this.nombreDirector = p_nomDir;
   }
   
   public String getNomHos(){
       return nombreHospital;
   }
   
   public String getNomDir(){
       return nombreDirector;
   }
   
   public void consultasDatosFilatorios(Paciente p_paciente){
       System.out.println("Hospital: "+this.getNomHos());
       System.out.println("Director: "+this.getNomDir());
   }
   
   
}
