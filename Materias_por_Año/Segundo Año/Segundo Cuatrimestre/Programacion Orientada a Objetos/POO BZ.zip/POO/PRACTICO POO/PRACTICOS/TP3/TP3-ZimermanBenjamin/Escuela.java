/**
 * Ejercicio 5. CLASE ESCUELA.
 * 
 * @author (Zimerman Benjamin, Solis Agustina A.) 
 * @version ()
 */
public class Escuela{
    /**ATRIBUTOS*/
    private String nombre;
    private String domicilio;
    private String director;
    private Docente docente;

    /**METODO CONSTRUCTOR: permite crear e instanciar objetos de la clase Escuela
     * @param p_nombre: nombre de la institucion.
     * @param p_domicilio: direccion de la escuela. 
     * @param p_director: nombre del director de la escuela. 
     * @param p_docente: objeto de clase Docente
    */
    public Escuela(String p_nombre, String p_domicilio, String p_director, Docente p_docente){
        this.setNombre(p_nombre);
        this.setDomicilio(p_domicilio);
        this.setDirector(p_director);
        this.setDocente(p_docente);
    }

    /**ACCESORS*/
    /**SETTERS: permiten modificar el estado de los atributos*/
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }

    private void setDomicilio(String p_domicilio){
        this.domicilio = p_domicilio;
    }

    private void setDirector(String p_director){
        this.director = p_director;
    }

    private void setDocente(Docente p_docente){
        this.docente = p_docente;
    }

    /**GETTERS: permiten obtener el valor de los atributos y devuelven estos mismos*/
    public String getNombre(){
        return this.nombre;
    }

    public String getDomicilio(){
        return this.domicilio;
    }

    public String getDirector(){
        return this.director;
    }

    public Docente getDocente(){
        return this.docente;
    }

    /**METODO imprimirRecibo(Docente p_docente): imprime por pantalla los detalles del recibo del sueldo del docente
     * @param p_docente: objeto de clase Docente. 
    */
    public void imprimirRecibo(Docente p_docente){
        System.out.println("Escuela: "+this.getNombre()+ "   Domicilio: " +this.getDomicilio()+ "   Director: " +this.getDirector());
        System.out.println("Docente: "+p_docente.getNombre());
        System.out.println("Sueldo:............... $"+p_docente.getSuelBas());
        System.out.println("Sueldo Basico:............... $ "+p_docente.getSuelBas());
        System.out.println("Asignacion Familiar:............... $ "+p_docente.getAsigFam());
    }
}        
