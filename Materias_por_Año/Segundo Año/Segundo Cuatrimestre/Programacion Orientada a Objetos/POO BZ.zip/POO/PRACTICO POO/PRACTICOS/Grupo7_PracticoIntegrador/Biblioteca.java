/**
 * Class Biblioteca.
 * Representa una biblioteca con su nombre, lista de libros y lista de socios.
 * 
 * @author (tu nombre)
 * @version (29-10-24)
 */
import java.util.*;

public class Biblioteca {
    /** Atributos de la clase */

    /** Nombre de la biblioteca */
    private String nombre;

    /** Lista de libros disponibles en la biblioteca */
    private ArrayList<Libro> libros;

    /** Mapa que relaciona el DNI de los socios con sus respectivos objetos Socio */
    private HashMap<Integer, Socio> socios;

    /**
     * Constructor Biblioteca.
     * Inicializa la biblioteca con un nombre, una lista vacía de libros y una lista vacía de socios.
     *
     * @param p_nombre Nombre de la biblioteca
     */
    public Biblioteca(String p_nombre) {
        this.setNombre(p_nombre);
        this.setLibro(new ArrayList<Libro>());
        this.setSocio(new HashMap<Integer, Socio>());
    }

    /**
     * Constructor Biblioteca.
     * Inicializa la biblioteca con un nombre, una lista de libros y una lista de socios.
     *
     * @param p_nombre Nombre de la biblioteca
     * @param p_libros Lista de libros de la biblioteca
     * @param p_socios Lista de socios de la biblioteca
     */
    public Biblioteca(String p_nombre, ArrayList<Libro> p_libros, HashMap<Integer, Socio> p_socios) {
        this.setNombre(p_nombre);
        this.setLibro(p_libros);
        this.setSocio(p_socios);
    }

    /** 
     * Establece el nombre de la biblioteca.
     * 
     * @param p_nombre Nombre de la biblioteca
     */
    private void setNombre(String p_nombre) {
        this.nombre = p_nombre;
    }

    /** 
     * Establece la lista de libros de la biblioteca.
     * 
     * @param p_libro Lista de libros
     */
    private void setLibro(ArrayList<Libro> p_libro) {
        this.libros = p_libro;
    }

    /** 
     * Establece el mapa de socios de la biblioteca.
     * 
     * @param p_socio Mapa de socios
     */
    private void setSocio(HashMap<Integer, Socio> p_socio) {
        this.socios = p_socio;
    }

    /** 
     * Obtiene el nombre de la biblioteca.
     * 
     * @return Nombre de la biblioteca
     */
    public String getNombre() {
        return this.nombre;
    }

    /** 
     * Obtiene la lista de libros de la biblioteca.
     * 
     * @return Lista de libros
     */
    public ArrayList<Libro> getLibro() {
        return this.libros;
    }

    /** 
     * Obtiene el mapa de socios de la biblioteca.
     * 
     * @return Mapa de socios
     */
    public HashMap<Integer, Socio> getSocio() {
        return this.socios;
    }

    /**
     * Agrega un libro a la biblioteca.
     *
     * @param p_libro Libro a agregar
     * @return true si se agregó exitosamente, false en caso contrario
     */
    public boolean agregarLibro(Libro p_libro) {
        return this.getLibro().add(p_libro);
    }

    /**
     * Quita un libro de la biblioteca.
     *
     * @param p_libro Libro a quitar
     * @return true si se quitó exitosamente, false en caso contrario
     */
    public boolean quitarLibro(Libro p_libro) {
        return this.getLibro().remove(p_libro);
    }

    /**
     * Agrega un nuevo socio a la biblioteca.
     *
     * @param p_socio Socio a agregar
     */
    public void agregarSocio(Socio p_socio) {
        this.getSocio().put(p_socio.getDniSocio(), p_socio);
    }

    /**
     * Quita un socio de la biblioteca.
     *
     * @param p_dni DNI del socio a quitar
     * @return El socio eliminado, o null si no existía
     */
    public Socio quitarSocio(int p_dni) {
        return this.getSocio().remove(p_dni);
    }

    /**
     * Crea un nuevo libro y lo agrega a la biblioteca si no existe.
     *
     * @param p_titulo Título del libro
     * @param p_edicion Edición del libro
     * @param p_editorial Editorial del libro
     * @param p_anio Año de publicación del libro
     */
    public void nuevoLibro(String p_titulo, int p_edicion, String p_editorial, int p_anio){
        Libro libro = new Libro(p_titulo, p_edicion,p_editorial, p_anio);
        System.out.println("Libro "+p_titulo+ " - Edicion: "+p_edicion+ " - Editorial:"+p_editorial+ " - Año: "+p_anio);
        if (libros.contains(p_titulo)){
            System.out.println("Ya pertenece a la biblioteca \n ");          
        }else{
            this.agregarLibro(libro);
            System.out.println("Fue agregado a la biblioteca");
        }
    }

    /**
     * Agrega un nuevo socio estudiante a la biblioteca.
     *
     * Este método crea un nuevo objeto Estudiante con los datos proporcionados y
     * lo agrega a la colección de socios si no existe ya un socio con el mismo DNI.
     *
     * @param p_dniSocio El DNI del nuevo socio estudiante.
     * @param p_nombre El nombre del nuevo socio estudiante.
     * @param p_carrera La carrera del nuevo socio estudiante.
     */
    public void nuevoSocioEstudiante(int p_dniSocio, String p_nombre, String p_carrera){
        Estudiante estudiante = new Estudiante(p_dniSocio, p_nombre, 20, p_carrera);
        System.out.println("Dni: "+p_dniSocio+ " - Socio: "+p_nombre+ " - Carrera: "+p_carrera);
        if (socios.containsKey(p_dniSocio)){
            System.out.println("Estudiante: " +p_nombre+" ya es socio");
        }else{
            this.agregarSocio(estudiante);
            System.out.println("Estudiante: " +p_nombre+" fue agregado");
        } 
    }

    /**
     * Agrega un nuevo socio docente a la biblioteca.
     *
     * Este método crea un nuevo objeto Docente con los datos proporcionados y
     * lo agrega a la colección de socios si no existe ya un socio con el mismo DNI.
     *
     * @param p_dniSocio El DNI del nuevo socio docente.
     * @param p_nombre El nombre del nuevo socio docente.
     * @param p_carrera La carrera del nuevo socio docente.
     */
    public void nuevoSocioDocente(int p_dniSocio, String p_nombre, String p_carrera){

        Docente docente = new Docente(p_dniSocio, p_nombre, 20, p_carrera);
        System.out.println("Dni: "+p_dniSocio+ " - Socio: "+p_nombre+ " - Carrera: "+p_carrera);
        if (socios.containsKey(p_dniSocio)){
            System.out.println("Docente: " +p_nombre+ " ya es socio");
        }else{
            this.agregarSocio(docente);
            System.out.println("Docente: " +p_nombre+ " fue agregado");
        } 

    }

    /**
     * Presta un libro a un socio.
     *
     * Este método verifica si el socio puede pedir un libro y si el libro
     * no está prestado. Si el socio es un "Estudiante" o "Docente", se
     * establece la fecha de devolución correspondiente. Si todas las condiciones
     * son satisfactorias, se registra el préstamo.
     *
     * @param p_fechaRetiro La fecha en que se retira el libro.
     * @param p_socio El socio que solicita el préstamo.
     * @param p_libro El libro que se desea prestar.
     * @return true si el préstamo se realizó con éxito, false en caso contrario.
     */
    public boolean prestarLibro(Calendar p_fechaRetiro, Socio p_socio, Libro p_libro) {
        Calendar fechaDev = new GregorianCalendar();
        boolean resp = false;

        if (p_socio != null) {
            if(p_socio.soyDeLaClase().equals("Estudiante") ){
                fechaDev.add(Calendar.DAY_OF_MONTH, 20);

            }else if(p_socio.soyDeLaClase().equals("Docente")){
                {
                    fechaDev.add(Calendar.DAY_OF_MONTH, 5);
                }
            }

            if (p_socio.puedePedir() || !p_libro.prestado()) {
                p_socio.agregarPrestamo(new Prestamo(p_libro, p_socio, p_fechaRetiro, fechaDev));
                p_libro.agregarPrestamo(new Prestamo(p_libro, p_socio, p_fechaRetiro, fechaDev));
                resp = true;
            } 
            resp = false;
        }
        return resp;
    }

    /**
     * Devuelve un libro a la biblioteca.
     *
     * Este método verifica si el libro proporcionado está prestado. Si no lo está,
     * se lanza una excepción. Si el libro está prestado, se busca el préstamo
     * correspondiente y se elimina. Si no se encuentra un préstamo asociado al libro,
     * se lanza una excepción indicando que el libro no tiene el préstamo solicitado.
     *
     * @param p_libro El libro que se desea devolver.
     * @throws LibroNoPrestadoException Si el libro no está prestado o no tiene un préstamo asociado.
     */

    public void devolverLibro(Libro p_libro) throws LibroNoPrestadoException {
        //Calendar fechaHoy = Calendar.getInstance(); 
        if (!p_libro.prestado()) {
            throw new LibroNoPrestadoException ("El libro" + p_libro.getTitulo() + "\t no se puede prestar ya que se encuentra en la biblioteca"); 
        } else {
            for (Libro unLibro: this.getLibro()) {
                for (Prestamo unPrestamo: unLibro.getPrestamos()) {
                    if(unPrestamo.getLibro().equals(p_libro)) {
                        unLibro.removePrestamo(unPrestamo);
                    }
                }

            }
        }
        throw new LibroNoPrestadoException ("El libro" + p_libro.getTitulo() + "no tiene el prestamo solicitado");
    }

    /**
     * Busca un socio por su DNI.
     *
     * Este método busca un socio en la colección de socios utilizando
     * el DNI proporcionado como parámetro. Si no se encuentra un socio
     * con el DNI especificado, se devuelve null.
     *
     * @param p_dni El DNI del socio que se desea buscar.
     * @return El objeto Socio correspondiente al DNI proporcionado, o null si no se encuentra.
     */
    public Socio buscarSocio(int p_dni){
        return (Socio)this.getSocio().get(new Integer(p_dni));
    }

    /*
    public Libro buscarLibro(String p_titulo){
    return (Libro)this.getLibro().get(new Integer(p_titulo));
    }
     */
    public Libro buscarLibro(String p_titulo){
        for (Libro libro : libros){
            if(libro.getTitulo().equals(p_titulo)){
                return libro;
            }
        }
        return null;
    }

    /**
     * Cuenta la cantidad de socios de un tipo específico.
     *
     * Este método recorre todos los socios y cuenta cuántos de ellos
     * pertenecen a la clase especificada por el parámetro p_objeto.
     *
     * @param p_objeto El tipo de socio que se desea contar (por ejemplo, "Docente").
     * @return La cantidad de socios que pertenecen al tipo especificado.
     */
    public int cantidadDeSociosPorTipo(String p_objeto){
        int cant = 0;

        for(Socio socio : this.getSocio().values()){
            if(socio.soyDeLaClase().equalsIgnoreCase(p_objeto)){
                cant += 1;
            }
        }
        return cant;
    }

    /**
     * Obtiene una lista de préstamos que están vencidos.
     *
     * Este método recorre todos los libros y sus respectivos préstamos, 
     * verificando si cada préstamo ha vencido en comparación con la fecha actual.
     *
     * @return Una lista de objetos Prestamo que están vencidos.
     */public ArrayList<Prestamo> prestamosVencidos() {
        ArrayList<Prestamo> prestamosVencidos = new ArrayList<>();
        Calendar fechaActual = new GregorianCalendar();

        for (Libro libro : this.getLibro()) {
            for (Prestamo prestamo : libro.getPrestamos()) {
                if (prestamo.vencido(fechaActual)) {
                    prestamosVencidos.add(prestamo);
                }
            }
        }
        return prestamosVencidos;
    }

    /**
     * Obtiene una lista de docentes que son responsables.
     *
     * Este método recorre todos los socios y filtra aquellos que son docentes y que cumplen con
     * la condición de ser responsables.
     *
     * @return Una lista de objetos Docente que son responsables.
     */
    public ArrayList <Docente> docentesResponsables(){
        ArrayList <Docente> docentesResp = new ArrayList();
        for(Socio socio: this.getSocio().values()){

            if (socio.soyDeLaClase().equals("Docente")) {
                Docente unDocente = (Docente)socio;
                if(unDocente.esResponsable()){
                    docentesResp.add(unDocente);
                }
            }
        }
        return docentesResp;
    }

    /**
     * Determina quién tiene actualmente un libro prestado.
     *
     * @param p_libro El libro del cual se desea conocer quién lo tiene prestado.
     * @return El nombre del socio que tiene el libro prestado.
     * @throws LibroNoPrestadoException Si el libro no está prestado o no se encuentra información sobre el préstamo.
     * @throws IllegalArgumentException Si el libro proporcionado es nulo.
     */
    public String quienTieneElLibro(Libro p_libro) throws LibroNoPrestadoException {
        //Verificamos que el libro esta prestado
        if (!p_libro.prestado()) {
            throw new LibroNoPrestadoException("El libro '" + p_libro.getTitulo() + "' se encuentra en la biblioteca\n");
        }

        // Si el libro esta prestado, buscamos el ultimo prestamo para obtener el socio
        ArrayList<Prestamo> prestamos = p_libro.getPrestamos();
        if (!prestamos.isEmpty()) {
            Prestamo ultimoPrestamo = prestamos.get(prestamos.size() - 1);
            return ultimoPrestamo.getSocios().getNombre(); // Retornamos el nombre del socio
        }

        // Si no se encuentra ningún prestamo (aunque deberia encontrarse si el libro esta prestado)
        throw new LibroNoPrestadoException("No se encontra informacion sobre quien tiene el libro '" + p_libro.getTitulo() + "'");
    }

    /**
     * Genera una lista de los nombres de los docentes responsables.
     *
     * @return Una cadena que representa la lista de nombres de los docentes responsables.
     */
    public String listaDocentesResponsables(){
        String listaResp = ""; 
        for (Docente docResponsable: this.docentesResponsables()) {
            listaResp = listaResp + docResponsable.getNombre(); 
        }
        return listaResp;
    }

    /**
     * Genera una lista de todos los socios registrados en la biblioteca.
     * Cada entrada incluye el DNI del socio, su nombre y la cantidad de libros que ha prestado.
     *
     * @return Una cadena que representa la lista de socios, con detalles de cada uno.
     */
    public String listaDeSocios(){
        StringBuilder listaS = new StringBuilder(); 
        for (Map.Entry <Integer,Socio> mos: socios.entrySet()) {
            listaS.append("D.N.I: ").append(mos.getKey()).append("||").append(mos.getValue().getNombre()).append("\t||").append("Libros Prestados:").append(mos.getValue().cantLibrosPrestados()).append("\n\n");
        }
        return listaS.toString();
    }

    /**
     * Genera una lista de todos los libros en la biblioteca,
     * indicando si cada libro está prestado o no.
     *
     * @return Una cadena que representa la lista de libros, incluyendo su estado de préstamo.
     */
    public String listaDeLibros() {
        int i = 0; 
        String listaL = ""; 
        for (Libro unLibro : this.getLibro()) {
            i++;
            if (!unLibro.prestado()) {
                listaL = listaL + i + ") " + "Titulo: " + unLibro.getTitulo() + "\t|| Prestado: (NO)" + "\n\n";
                continue; 
            } else {
                listaL = listaL + i + ") " + "Titulo: " + unLibro.getTitulo() + "\t|| Prestado: (SI)" + "\n\n";
            }
        }
        return listaL;
    }

    /**
     * Genera una lista de todos los títulos de los libros en la biblioteca.
     * Cada entrada incluye el índice, el título del libro, la editorial, la edición y el año de publicación.
     *
     * @return Una cadena que representa la lista de títulos de los libros, formateada con detalles.
     */

    public String listaDeTitulos () {
        int i = 0; 
        String listaTitulos = ""; 
        for (Libro unLibro:this.getLibro()){
            i++;
            listaTitulos = listaTitulos + i +")"+ unLibro.toString() + ",\t Editorial: " + unLibro.getEditorial() + ",\tEdicion" + unLibro.getEdicion() + ",\tAño de Publicacion: " + unLibro.getAnio() + "\n";
        }
        return listaTitulos; 
    }

}

