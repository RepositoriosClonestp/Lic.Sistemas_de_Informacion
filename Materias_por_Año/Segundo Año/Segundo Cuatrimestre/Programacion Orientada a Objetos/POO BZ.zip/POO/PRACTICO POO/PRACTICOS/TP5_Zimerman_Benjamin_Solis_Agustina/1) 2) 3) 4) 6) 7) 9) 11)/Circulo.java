/**
 * CLASE RECTANGULO:
 * 
 * <p>La clase Circulo representa un círculo, que es una extensión de la clase Elipse.</p>
 * 
 * @autor Zimerman Benjamin
 * @autor Solis Agustina Aylen
 * @version 2/10/24
 */
public class Circulo extends Elipse {

    /**
     * Perímetro del círculo.
     */
    double perim;

    /**
     * Constructor de la clase Circulo.
     * 
     * @param p_origen el punto de origen del círculo
     * @param p_perim el perímetro del círculo
     */
    public Circulo(Punto p_origen, double p_perim) {
        super(p_origen, p_perim, p_perim);
        this.setperim(p_perim);
    }

    /**
     * Establece el perímetro del círculo.
     * 
     * @param p_perim el nuevo perímetro del círculo
     */
    private void setperim(double p_perim) {
        this.perim = p_perim;
    }

    /**
     * Obtiene el perímetro del círculo.
     * 
     * @return el perímetro del círculo
     */
    private double getperim() {
        return this.perim;
    }

    /**
     * Retorna el nombre de la figura.
     * 
     * @return el nombre de la figura
     */
    public String nombreFigura() {
        System.out.println("*****Circulo*****");
        return "Circulo";
    }

    /**
     * Muestra las características del círculo.
     */
    public void caracteristicas() {
        this.nombreFigura();
        System.out.println("Superficie: " + super.superficie());
    }

    /**
     * Calcula la superficie del círculo.
     * 
     * @return la superficie del círculo
     */
    public double superficie() {
        return super.superficie();
    }
}
