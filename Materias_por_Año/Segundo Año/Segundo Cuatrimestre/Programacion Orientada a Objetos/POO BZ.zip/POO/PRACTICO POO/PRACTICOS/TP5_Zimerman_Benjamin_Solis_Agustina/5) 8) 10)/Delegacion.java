
/**
 * Write a description of class Delegacion here.
 * 
 * @author (Solis Agustina, Zimerman Benjamin) 
 * @version (16/10/24)
 */
import java.util.*; 
import java.util.Calendar;
public class Delegacion extends Visitante
{
    private ArrayList <Individuo> integrantes; 
    /**
     * Constructor for objects of class Delegacion: crea e inicializa objetos de la clase Delegacion.
     * @param p_nombre: nombre de la delegacion
     * @param p_individuo: individuo integrante de la delegacion
     */
    public Delegacion(String p_nombre, Calendar p_fecha, Individuo p_individuo)
    {
        super(p_nombre, p_fecha); 
        this.setIndividuos(new ArrayList <Individuo>());
        this.inscribirIndividuo(p_individuo);
        this.quitarIndividuo(p_individuo);
    }
    
    /**
     * Constructor for objects of class Delegacion: crea e inicializa objetos de la clase Delegacion.
     * @param p_nombre: nombre de la delegacion
     * @param p_fecha: fecha de la visita de la delegacion al zoologico
     * @param p_individuos: coleccion de individuos integrantes de la delegacion
     */
    public Delegacion (String p_nombre, Calendar p_fecha, ArrayList <Individuo> p_individuos)
    {
        super(p_nombre, p_fecha); 
        this.setIndividuos(p_individuos); 
    }
    
    /**ACCESORS**/
    public void setIndividuos (ArrayList <Individuo> p_integrantes){
        this.integrantes = p_integrantes;
    }
    
    public ArrayList <Individuo> getIndividuos(){
        return this.integrantes;
    }
    
    public boolean inscribirIndividuo(Individuo p_individuo){
        return this.getIndividuos().add(p_individuo);
    }
    
    public boolean quitarIndividuo(Individuo p_individuo){
        return this.getIndividuos().remove(p_individuo);
    }
    
    /**METODOS**/
    /** @override
     * public String tipoVisitante(): metodo publico que retorna un String con el tipo de Visitante que corresponda
       @return delegacion*/
    public String tipoVisitante() {
        return "delegacion";
    }
    
    /** @override
       *public HashSet <Persona> listarPersona(): crea un HashSet con los individuos que conforman a la delegacion
       *@return listadeIntegrantes;
       */
    public HashSet <Persona> listarPersona() {
        HashSet<Persona> listadeIntegrantes = new HashSet<>(); 
        for (Individuo integrantes: this.getIndividuos()) {
            listadeIntegrantes.add(integrantes.getPersona());
        }
        return listadeIntegrantes;
    }
    
    /**@override
     * public double entrada(): metodo publico que recorre el ArrayList de Individuos de la Delegacion y 
       acumula en una var auxiliar (total) el valor total de las entradas. 
       @return total;
       */
    public double entrada() {
        double total = 0; 
        for(int i=0; i<this.getIndividuos().size(); i++) {
            total +=((Individuo)this.getIndividuos().get(i)).entrada();
        }
        return total; 
    }
    
    /**@override
     * listarPorFecha(Calendar p_fecha, String p_visitante): metodo publico que muestra un listado de los individuos del ArrayList
     * que visitaron el zoologico en una fecha determinada, 
       **/
    public void listarPorFecha(Calendar p_fecha, String p_visitante) {
        System.out.println("--------------------------");
        System.out.println ("Delegacion: "+ this.getNombre());
        System.out.println ("Integrantes: ");
        for (Individuo integrantes:this.getIndividuos()) {
            if (integrantes.getFecha().compareTo(p_fecha) == 0 && integrantes.tipoVisitante().equals(p_visitante)){
                integrantes.mostrar();
            }
        }
    }
    
    /** @override
     * public void mostrar(): imprime por pantalla los nombres,dni y edad de los individuos que conforman la delegacion,
     asi como tambien su cantidad de integrantes y el precio tital de las entradas a pagar.
       */
    public void mostrar() {
        System.out.println("--------------------------");
        System.out.println ("Delegacion: "+ this.getNombre());
        System.out.println ("Integrantes: ");
        for (Individuo integrantes:this.getIndividuos() ){
            integrantes.mostrar();
        }
        System.out.println("Entradas:"+ this.entrada());
        System.out.println ("Cantidad de Integrantes: "+this.cantidadDeIntegrantes());
    }
    
    /** public int cantidadDeIntegrantes(): calcula la cantidad de integrantes de la delegacion  
     * @return cantidad de individuos
       */
    public int cantidadDeIntegrantes() {
        return this.getIndividuos().size();
    }
}
