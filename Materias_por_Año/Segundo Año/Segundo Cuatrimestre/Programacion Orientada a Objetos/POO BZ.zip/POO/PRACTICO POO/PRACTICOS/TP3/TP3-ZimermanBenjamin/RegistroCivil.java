/**
 * Ejercicio 10.CLASE EJECUTABLE REGISTRO CIVIL.
 * 
 * @author (Zimerman Benjamin, Solis Agustina) 
 * @version (6/09/24)
 */
import java.util.Scanner;
public class RegistroCivil {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        /**Datos mujer*/
        
        System.out.println("Nombre mujer: ");
        String nm = scan.next();
        scan.nextLine();

        System.out.println("Apellido mujer: ");
        String am = scan.next(); 

        System.out.println("Edad mujer: ");
        int em = scan.nextInt(); 
        
        Mujer m = new Mujer (nm, am, em);
        
        /**INSTANCIACION OBJETO MUJER*/
        //Mujer m = new Mujer("Juana","Espinoza",4);

        /**Datos hombre*/
        System.out.println("Nombre hombre: ");
        String nh = scan.next(); 

        System.out.println("Apellido hombre: ");
        String ah = scan.next(); 

        System.out.println("Edad hombre: ");
        int eh = scan.nextInt();
        
        Hombre h = new Hombre(nh, ah, eh);
       
        /**Instanciacion de objeto HOMBRE*/
        /*Hombre h = new Hombre("Ariel","Rios",5);*/

        System.out.println("Ingrese opcion: ");
        System.out.println(" 1) Se casa M->H.\n 2) Se casa H->M \n 3) Se divorcia M->H. \n 4) Se divorcia H->M. \n 5) Salir.");
        int opl = scan.nextInt();
        do{
            switch (opl) {
                case 1:
                    System.out.println("Acta de matrimonio de: ");
                    if(m.getEstCiv() == "Soltera"){
                        m.casarseCon(h);
                        m.casadaCon();

                        //h.casarseCon(m);
                        //h.casadoCon();
                        //h.mostrarEstadoCivil();
                        //m.mostrarEstadoCivil();
                    }else{
                        System.out.println("No esta soltero por ende no puede casarse");
                    }
                    break;

                case 2:
                    System.out.println("Acta de matrimonio de: ");
                    if(h.getEstCiv() == "Soltero"){
                        h.casarseCon(m);
                        h.casadoCon();

                        //h.casarseCon(m);
                        //m.casarseCon(h);
                        //h.mostrarEstadoCivil();
                        //m.mostrarEstadoCivil();
                    }else{
                        System.out.println("No esta soltero por ende no puede casarse");
                    }
                    break;
                case 3:
                    if(m.getEstCiv() == "Casada"){
                        m.divorcio();
                        //h.divorcio();

                        System.out.println("Se divorciaron: "+m.datos()+ " y " +h.datos()); 
                        h.mostrarEstadoCivil();
                        m.mostrarEstadoCivil();
                    }else{
                        System.out.println("No esta casado por ende no puede divorciarse");
                    }
                    break;

                case 4:
                    if(h.getEstCiv() == "Casado"){

                        h.divorcio();
                        //m.divorcio();

                        System.out.println("Se divorciaron: "+h.datos()+ " y " +m.datos()); 
                        m.mostrarEstadoCivil();
                        h.mostrarEstadoCivil();
                    }else{
                        System.out.println("No esta casado por ende no puede divorciarse");
                    }
                    break;

                default:
                    System.out.println("Opción inválida. Programa cerrado.");
                    opl = 5; 
                    break;
            }
            System.out.println(" 1) Se casa M->H.\n 2) Se casa H->M \n 3) Se divorcia M->H. \n 4) Se divorcia H->M. \n 5) Salir.");
            opl = scan.nextInt();
        }while(opl != 5);
        System.out.println("Programa cerrado.");
        scan.close();
    }
}
