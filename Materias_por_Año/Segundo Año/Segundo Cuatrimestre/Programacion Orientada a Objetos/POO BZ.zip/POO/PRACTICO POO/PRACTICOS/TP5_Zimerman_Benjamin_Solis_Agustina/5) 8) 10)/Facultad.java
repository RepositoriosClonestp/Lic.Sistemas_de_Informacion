
/**
 * Write a description of class Facultad here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.*;

public class Facultad{
    private String nombre; 
    private ArrayList <Profesor> profesores; 
    
    /**Metodo Constructor: crea e inicializa objetos de la clase Facultad
       @param p_nombre: nombre de la facultad
       @param p_profe: objeto Profesor que inicializa el arraylist de profesores**/
    public Facultad(String p_nombre, Profesor p_profe){
        this.setNombre(p_nombre); 
        this.setProfes(new ArrayList <Profesor>()); 
        this.agregarProfe(p_profe); 
        this.quitarProfe(p_profe); 
    }
    
    /**Metodo Constructor: crea e inicializa objetos de la clase Facultad
       @param p_nombre: nombre de la facultad
       @param p_profes: arraylist de profesores**/
    public Facultad (String p_nombre, ArrayList <Profesor> p_profes){
        this.setNombre(p_nombre); 
        this.setProfes(p_profes);  
    }
    
    /**ACCESORS**/
    /**setters***/
    private void setNombre(String p_nombre) {
        this.nombre= p_nombre; 
    }
    
    private void setProfes (ArrayList <Profesor> p_profes) {
        this.profesores = p_profes; 
    }
    
    /**getters**/
    public String getNombre() {
        return this.nombre; 
    }
    
    public ArrayList <Profesor> getProfes() {
        return this.profesores; 
    }
    
    /**METODS**/
    /**agregarProfe (Profesor p_profe): agrega un objeto de la clase Profesor al arraylist de profesores
       @return el arraylist con el profesor ingresado como parametro**/
    public boolean agregarProfe (Profesor p_profe) {
        return this.getProfes().add(p_profe); 
    }
    
    /**quitarProfe(Profesor p_profe):elimina un objeto de la clase Profesor al arraylist de profesores
       @return el arraylist sin el profesor ingresado como parametro **/
    public boolean quitarProfe (Profesor p_profe){
        return this.getProfes().remove(p_profe); 
    }
    
    /**public void nominaProfesores(): imprime por pantalla una nomina con los nombres, dni y sueldos de los profesores **/
    public void nominaProfesores() {
        double total = 0; 
        System.out.println ("**** NOMINA FACULTAD:" + this.getNombre() + "****");
        
        for (Profesor profesores: this.getProfes()){
            profesores.mostrarLinea(); 
        }
        
        System.out.println ("--------------------------------");
        System.out.println ("Total a pagar $:"+this.totalAPagar());
    }
    /**public double totalAPagar(): calcula el total a pagar sumando los sueldos de todos los profesores contenidos en el arraylist
       profesores
       @return monto total que debe pagar la facultad en sueldos*/
    public double totalAPagar() {
        double total = 0; 
        for (Profesor profesores: this.getProfes()) {
            total += profesores.sueldoTotal(); 
        }
        return total; 
    }
    /**public void listarProfesCargos(): imprime por pantalla los datos y cargos de los profesores**/
    public void listarProfesCargos() {
        for (Profesor profesores: this.getProfes()) {
            profesores.mostrar(); 
        }
    }
}

