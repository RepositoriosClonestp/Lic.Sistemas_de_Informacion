 
public class Numero { 
    private static long contador;  
    private final long id = contador++; 
    public String toString() { return "Entero "+id; } 
} 
 
