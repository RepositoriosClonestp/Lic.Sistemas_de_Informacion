
/**
 * Write a description of class Comercio here.
 * 
 * @author (Solis Agustina, Benjamin Zimmerman) 
 * @version (12/09/2024)
 */
import java.util.*; 

public class Comercio
{
    private String nombre; 
    private HashMap <Long, Empleado> empleados;
    
    /**Metodo Constructor: permite crear e instanciar objetos de la clase Comercio
     * @param p_nombre: nombre del empleado.
       **/
    public Comercio (String p_nombre) {
        this.setNombre(p_nombre); 
        this.setEmpleados(new HashMap <Long, Empleado> ()); 
    }
    
    /**Metodo Constructor: permite crear e instanciar objetos de la clase Comercio
     * @param p_nombre: nombre del empleado.
     * @param p_empleados: HashMap de elementos de clase Empleado y Keys integer. 
       **/
    public Comercio (String p_nombre, HashMap <Long, Empleado> p_empleados) {
        this.setNombre (p_nombre); 
        this.setEmpleados(p_empleados); 
    }
    
    /**ACCESORS**/
    /**Setters**/
    private void setNombre(String p_nombre) {
        this.nombre=p_nombre; 
    }
    
    public void setEmpleados(HashMap <Long, Empleado> p_empleados) {
        this.empleados= p_empleados; 
    }
    
    /**Getters**/
    /** getNombre(): devuelve el nombre del empleado
     * @return nombre del empleado*/
    public String getNombre(){
        return this.nombre;
    }
    
    /**getEmpleados: devuelve el HashMap de empleados
       @return elementos de clase Empleado dentro del HashMap empleados**/
    public HashMap <Long, Empleado> getEmpleados () {
        return this.empleados; 
    }
    
    /**Metodo altaEmpleadoo(Empleado p_empleado): permite agregar un empleado al comercio**/
    /**
     * this.getEmpleados): obtiene la colecciona empleados.
     * put(new Integer(p_empleado.getCuil())),p_empleado: agrega el empleado a la colecion.
     * (new Integer(p_empleado.getCuil()) crea un objeto integer con el nro de cuil del empleado, llamandolo mediante el parametro p_empleado.
    p_empleado es el valor asociado a la clave cuil.
    **/
    public void altaEmpleado(Empleado p_empleado) {
        this.getEmpleados().put(new Long(p_empleado.getCuil()), p_empleado); 
    }
    
    /**(Empleado): cast conversion.
    this.getEmpleados() obtiene coleccion de empleados.
    remove(new Integer(p_cuil)) elimina el objeto empleado asociado a la clave p_cuil.
    new Integer(p_cuil): crea un objeto Integer con el nro del atributo cuil.
    @return el empleado eliminado*/
    public Empleado bajaEmpleado (Long p_cuil) {
        return (Empleado)this.getEmpleados().remove(new Long(p_cuil));
    }
    
    /**Metodo cantudadDeEmpleados(): obtiene el numero de empleados del comercio
       @return la cantidad de objetos Empleado en el HashMap empleados**/
    public int cantidadDeEmpleados() {
        return this.getEmpleados().size(); 
    }
    
    /**Metodo esEmpleado(int p_cuil):Verifica si el empleado pertenece al comercio – Busqueda por clave 
     * @return verdadero o falso **/
    public boolean esEmpleado(Long p_cuil) {
        return this.getEmpleados().containsKey(new Long (p_cuil));
    }
    
    /**Metodo buscarEmpleado(int p_cuil): recorre el HashMap y busca el key ingresado como parametro.
     * @return el empleado que corresponde al cuil pasado como parámetro **/
    public Empleado buscarEmpleado(Long p_cuil) {
      return (Empleado) this.getEmpleados().get(new Long (p_cuil));   
    }
    
    /**Metodo sueldoNeto(int p_cuil): imprime el sueldo neto del empleado cuyo cuil fue ingresado como parametro**/
    public void sueldoNeto (Long p_cuil) {
        System.out.println ("Sueldo Neto: " +this.buscarEmpleado(p_cuil).neto());
    }
    
    /**Metodo nomina(): imprime por pantalla los valores de los atributos cuil, nombre, apellido y sueldo neto de los objetos Empleado**/
    public void nomina() {
        System.out.println ("Nomina de empleados de:" + getNombre());
        for (Map.Entry <Long,Empleado> mos: empleados.entrySet()){
            System.out.println (mos.getKey() + "\t" + mos.getValue().apeYNom() + "\t"+ mos.getValue().neto());
        }
    }
}
