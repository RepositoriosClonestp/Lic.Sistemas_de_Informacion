import java.util.*;

/**
 * CLASE JARDIN
 * 
 * <p>La clase Jardin representa un jardín que contiene una colección de figuras geométricas.</p>
 * 
 * @autor Zimerman Benjamin
 * @autor Solis Agustina Aylen
 * @version 2/10/24
 */
public class Jardin {

    /**
     * ATRIBUTOS
     */
    private String nombre;
    private ArrayList<FiguraGeometrica> figuras;

    /**
     * Constructor de la clase Jardin.
     * 
     * @param p_nombre el nombre del jardín
     * @param p_figuras la figura geométrica inicial
     */
    public Jardin(String p_nombre, FiguraGeometrica p_figuras) {
        this.setNombre(p_nombre);
        this.setFiguras(new ArrayList<FiguraGeometrica>());
        this.agregarFigura(p_figuras);
    }

    /**
     * Constructor de la clase Jardin.
     * 
     * @param p_nombre el nombre del jardín
     */
    public Jardin(String p_nombre) {
        this.setNombre(p_nombre);
    }

    /**
     * Establece el nombre del jardín.
     * 
     * @param p_nombre el nuevo nombre del jardín
     */
    private void setNombre(String p_nombre) {
        this.nombre = p_nombre;
    }

    /**
     * Establece la lista de figuras geométricas del jardín.
     * 
     * @param p_figuras la nueva lista de figuras geométricas
     */
    public void setFiguras(ArrayList<FiguraGeometrica> p_figuras) {
        this.figuras = p_figuras;
    }

    /**
     * Obtiene el nombre del jardín.
     * 
     * @return el nombre del jardín
     */
    public String getNombre() {
        return this.nombre;
    }

    /**
     * Obtiene la lista de figuras geométricas del jardín.
     * 
     * @return la lista de figuras geométricas
     */
    public ArrayList<FiguraGeometrica> getFiguras() {
        return this.figuras;
    }

    /**
     * Agrega una figura geométrica a la lista del jardín.
     * 
     * @param p_figura la figura geométrica a agregar
     * @return true si la figura fue agregada exitosamente, false en caso contrario
     */
    public boolean agregarFigura(FiguraGeometrica p_figura) {
        return this.getFiguras().add(p_figura);
    }

    /**
     * Calcula la cantidad de litros de pintura necesarios para cubrir las figuras en el jardín.
     * 
     * @return la cantidad de litros de pintura necesarios
     */
    private double cuantosLitros() {
        double litros;
        litros = (this.cuantosMetros() * 4) / 20;
        return litros;
    }

    /**
     * Calcula la cantidad de latas de pintura necesarias para cubrir las figuras en el jardín.
     * 
     * @return la cantidad de latas de pintura necesarias
     */
    public int cuantasLatas() {
        int latas;
        latas = (int) Math.ceil(this.cuantosLitros() / 4);
        return latas;
    }

    /**
     * Calcula el total de metros cuadrados a cubrir en el jardín.
     * 
     * @return el total de metros cuadrados
     */
    public double cuantosMetros() {
        double totalMetros = 0;
        for (int i = 0; i < this.getFiguras().size(); i++) {
            totalMetros += ((FiguraGeometrica) this.getFiguras().get(i)).superficie();
        }
        return totalMetros;
    }

    /**
     * Muestra el detalle de las figuras en el jardín.
     */
    public void detalleFiguras() {
        for (int i = 0; i < this.getFiguras().size(); i++) {
            ((FiguraGeometrica) this.getFiguras().get(i)).nombreFigura();
            System.out.println("Superficie: " + (((FiguraGeometrica) this.getFiguras().get(i)).superficie()));
        }
    }
}
