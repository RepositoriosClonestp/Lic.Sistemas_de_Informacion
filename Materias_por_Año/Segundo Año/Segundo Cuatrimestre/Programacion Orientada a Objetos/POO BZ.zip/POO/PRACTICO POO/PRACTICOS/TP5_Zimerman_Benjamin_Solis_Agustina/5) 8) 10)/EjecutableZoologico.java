
/**
 * Write a description of class EjecutableZoologico here: Se solicita implementar una clase ejecutable para realizar lo siguiente: 
a)    Instanciar un zoológico con el nombre “El Caribú” 
b)   Instanciar tres individuos que asistieron al zoológico, uno de ellos en forma independiente y los otros dos 
formando parte de la delegación “PAMI”, el día 22/09/2024 
c) Crear la delegación “PAMI”, que asistió el día indicado, e inscribir a los dos individuos. 
d)   Listar todos los visitantes que acudieron al zoológico el día 22/09/2024 
e)    Listar la recaudación del último mes 
f)    
Listar las delegaciones que acudieron el día 22/09/2024 
 * 
 * @author (Solis Agustina, Zimerman Benjamin) 
 * @version (16/10/24)
/ */
import java.util.*; 
import java.util.Calendar; 

public class EjecutableZoologico{
    public static void main(String[] args) {
        /**Instanciacion fechas*/
        Calendar fecha1 = Calendar.getInstance(); 
        fecha1.set(2024,9,22); 
        Calendar fechaD = Calendar.getInstance(); 
        fechaD.set(2024,8,22);
        Calendar fechaH = Calendar.getInstance(); 
        fechaH.set(2024,9,23);
        
        /**Instanciacion objetos del tipo Visitante*/
        //public Persona(int p_dni, String p_nombre, String p_apellido, int p_anio)
        //public Individuo(Persona p_persona, String p_nombre, Calendar p_fecha)
        // public Delegacion (String p_nombre, Calendar p_fecha, ArrayList <Individuo> p_individuos)
        //public Delegacion(String p_nombre, Calendar p_fecha, Individuo p_individuo)
        Persona p1= new Persona (31252293, "Maria", "Gonzalez", 1996);
        Persona p2= new Persona(2244555, "Julian", "Castro", 1964);
        Persona p3= new Persona (25666777, "Sofia", "Belucci", 1968);
        Individuo v1 = new Individuo(p1, "Maria Gonzalez", fecha1);
        Individuo v2 = new Individuo (p2, "Julian Castro", fecha1); 
        Individuo v3 = new Individuo (p3, "Sofia Belucci", fecha1); 
        
        /**Instanciacion objeto Delegacion**/
        Delegacion pami = new Delegacion ("PAMI", fecha1, v1);
        pami.setIndividuos(new ArrayList());
        pami.inscribirIndividuo(v1); 
        pami.inscribirIndividuo(v3);
        pami.mostrar();
        /**Instanciacion objeto Zoologico**/
        Zoologico EC = new Zoologico("EL CARIBU", pami);
        EC.nuevoVisitante(v1);
        EC.nuevoVisitante(v2);
        EC.nuevoVisitante(v3);
        EC.listarVisitantePorFecha(fecha1); 
        EC.recaudacion (fechaD,fechaH); 
        System.out.println("Recaudacion ultimo mes:"+EC.recaudacion (fechaD,fechaH));
        
    }
}
