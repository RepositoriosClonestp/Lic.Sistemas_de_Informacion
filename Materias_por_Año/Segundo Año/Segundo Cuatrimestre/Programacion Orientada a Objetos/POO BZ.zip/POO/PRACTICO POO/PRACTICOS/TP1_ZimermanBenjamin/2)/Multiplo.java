
public class Multiplo
{
    private static int i=0;
    public static void main (String [] args){
    for(i=11; i<=37 ;i++){
           System.out.println(i*4); 
    }
    System.out.println("150");
    }
}
