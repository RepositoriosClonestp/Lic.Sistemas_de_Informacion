
public class EjecutableCliente{
    public static void main (String [] args){
        Cliente c1 = new Cliente(1234567, "Perez", "Juan", 200.00);
        c1.mostrar();
    }
}
