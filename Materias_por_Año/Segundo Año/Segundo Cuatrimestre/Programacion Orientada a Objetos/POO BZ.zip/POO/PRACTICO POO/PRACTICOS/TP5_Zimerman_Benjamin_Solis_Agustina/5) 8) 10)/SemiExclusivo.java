
/**
 * Write a description of class SemiExclusivo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SemiExclusivo extends Cargo
{
   private int horasDeInvestigacion; 

    /**
     * Constructor for objects of class SemiExclusivo
     * @param p_nombreC: nombre del cargo
     * @param p_sueldoB: sueldo del cargo
     * @param p_anioI: año en que el profesor asumio el cargo
     * @p_horas:horas trabajadas
     * @param p_horasI: horas de investigacion
     */
    public SemiExclusivo(int p_horasI, String p_nombreC, double p_sueldoB, int p_anioI, int p_horas) {
        super(p_nombreC,p_sueldoB,p_anioI,p_horas);
        this.setHorasI(p_horasI); 
    }
    
    /**Accesors**/
    private void setHorasI(int p_horasI) {
        this.horasDeInvestigacion = p_horasI; 
    }
    public int getHorasI() {
        return this.horasDeInvestigacion; 
    }
    
    /**public void mostrarCargo(): imprime por pantalla los detalles del cargo**/
    public void mostrarCargo() {
        super.mostrarCargo(); 
        System.out.println("----Cargo de Caracter Exclusivo----"); 
        System.out.println("Horas de investigacion: " + this.getHorasI()); 
    }
}
