
/**
 *Clase EmpleadoConJefe.
 * 
 * @author (Zimerman Benjamin-Solis Agustina) 
 * @version (5/09/24)
 */
import java.util.Calendar;
import java.util.GregorianCalendar;

public class EmpleadoConJefe
{
    /**ATRIBUTOS DE LA CLASE**/
    private long cuil;
    private String apellido;
    private String nombre;
    private double sueldoBasico;
    private Calendar fechaIngreso;
    private int anioIngreso;
    private EmpleadoConJefe e_jefe; 

    /** METODO CONSTRUCTOR: permite crear e instanciar objetos de la clase EmpleadoConJefe
     * @param p_cuil: cuil del empleado
     * @param p_nombre: nombre del empleado
     * @param p_apellido: apellido del empleado. 
     * @param p_importe: sueldo del empleado
     * @param p_fecha: fecha de ingreso del empleado
     * @param p_jefe: objeto de la clase EmpleadoConJefe que modela el jefe del empleado
    */
    public EmpleadoConJefe(long p_cuil, String p_apellido, String p_nombre, double p_importe,Calendar p_fecha, EmpleadoConJefe p_jefe)
    {
        this.setCuil (p_cuil); 
        this.setApe(p_apellido); 
        this.setNom(p_nombre); 
        this.setImporte(p_importe); 
        this.setEmpleadoconJefe(p_jefe); 
        this.setFechaIngreso(p_fecha);
        
    }
    
    /** METODO CONSTRUCTOR: permite crear e instanciar objetos de la clase EmpleadoConJefe
     * @param p_cuil: cuil del empleado
     * @param p_nombre: nombre del empleado
     * @param p_apellido: apellido del empleado. 
     * @param p_importe: sueldo del empleado
     * @param p_fecha: fecha de ingreso del empleado
    */
    public EmpleadoConJefe (long p_cuil,String p_apellido, String p_nombre, double p_importe, Calendar p_fecha){
        this.setCuil (p_cuil); 
        this.setApe(p_apellido); 
        this.setNom(p_nombre); 
        this.setImporte(p_importe); 
        this.setFechaIngreso(p_fecha); 
    
    }
    
    /** METODO CONSTRUCTOR: permite crear e instanciar objetos de la clase EmpleadoConJefe
     * @param p_cuil: cuil del empleado
     * @param p_nombre: nombre del empleado
     * @param p_apellido: apellido del empleado. 
     * @param p_importe: sueldo del empleado
     * @param p_anio: año de ingreso del empleado.
    */
    public EmpleadoConJefe (long p_cuil,String p_apellido, String p_nombre, double p_importe, int p_anio){
        this.setCuil (p_cuil); 
        this.setApe(p_apellido); 
        this.setNom(p_nombre); 
        this.setImporte(p_importe); 
        this.setAnio (p_anio); 
        this.fechaIngreso= Calendar.getInstance();
        this.fechaIngreso.set(Calendar.YEAR,p_anio); 
    }

    /**ACCESORS**/
    
    /**SETTERS**/
     /**SetCuil (long p_cuil): modifica el valor del atributo Cuil de tipo long
        @param p_cuil**/
    private void setCuil(long p_cuil){
        this.cuil = p_cuil;
    }
     /**setApe (String p_apellido): modifica el valor del atributo apellido de tipo String
        @param p_apellido**/
    private void setApe(String p_apellido){
        this.apellido = p_apellido;
    }
     /**setNom (String p_nombre): modifica el valor del atributo nombre de tipo String
        @param p_nombre**/
    private void setNom(String p_nombre){
        this.nombre = p_nombre;
    }
    
    /**setAnio (in p_anio): modifica el valor del atributo año de tipo int 
       @param p_anio**/
    private void setAnio(int p_anio){
        this.anioIngreso = p_anio;
    }
    
     /**setImporte (double p_importe): modifica el valor el atributo importe de tipo double
        @param p_importe**/
    private void setImporte(double p_importe){
        this.sueldoBasico = p_importe;
    }
    
    /**setFechaI: actualiza los datos del atributo fechaIngreso
    @param p_fecha: feha de ingreso del empleado*/
    private void setFechaIngreso (Calendar p_fecha) {
        this.fechaIngreso = p_fecha; 
    }
    
    /**setEmpleadoconJefe(EmpleadoConJefe p_jefe): actualiza los datos del atributo e_jefe
       @param p_jefe*/
    private void setEmpleadoconJefe(EmpleadoConJefe p_jefe) {
        this.e_jefe = p_jefe; 
    }
    
    /**GETTERS**/
      /**getCuil: obtiene el valor del atributo cuil de tipo long 
         @return valor del cuil**/
    public long getCuil(){
        return this.cuil;
    }
     /**getApellido: obtiene el valor del atributo apellido de tipo String
        @return apellido del empleado/jefe**/
    public String getApellido(){
        return this.apellido;
    }
     /**getNombre: obtiene el valor del atributo nombre de tipo String
        @return nombre del empleado/jefe**/
    public String getNombre(){
        return this.nombre;
    }
     /**getImporte: obtiene el valor del atributo importe de tipo double
        @return sueldo del empleado/jefe**/
    public double getImporte(){
        return this.sueldoBasico;
    }
     /**getAnio: obtiene el valor del atributo año de tipo int
        @return año de ingreso del empleado/jefe**/
    public int getAnio(){
        return this.anioIngreso;
    }
    
    /**getFechaIngreso: obtiene el valor de tipo Calendar del atributo fechaIngreso
       @return fecha completa del ingreso del empleado**/
    public Calendar getFechaIngreso (){
        return fechaIngreso; 
    }
    
    /**getE_Jefe: obtiene el valor del atributo e_jefe de clase EmpleadoConJefe 
       @return datos del jefe**/
    public EmpleadoConJefe getE_Jefe(){
        return e_jefe; 
    }
    
    /**METODO nomYAPE(): metodo publico que Concatena nombre y apelido
       @return un string con dicha concatenacion**/
    public String nomYApe(){
        return this.getNombre()+ ", " +this.getApellido();
    }
    
    /**METODO apeYNom (): metodo publico que concatena aprllido y nombre
       @return un string con dicha concatenacion**/
    public String apeYNom(){
        return this.getApellido()+ ", " +this.getNombre();
    }
    
     /**METODO ANTIGUEDAD: metodo publico que devuelve un int y permite calcular la antiguedad de los empleados
        @return antiguedad en años del empleado**/
    public int antiguedad() {
        Calendar fechaHoy = new GregorianCalendar();/**Nueva variable fecha de hoy*/
        int anioHoy = fechaHoy.get(Calendar.YEAR);
        int anioIngreso = fechaIngreso.get(Calendar.YEAR); 
        return anioHoy - anioIngreso ;/**Resto al año actual el de ingreso*/
    }
    
    /**METODO DESCUENTO (): metodo privado que permite calcular al 2% del sueldo básico en concepto de obra social, mas $1500 de seguro de 
    vida
    @return sueldo del emppleado**/
    private double descuento(){
        return ((this.getImporte() * 0.02) + 1500);  
    }
    
    /**METODO ADICIONAL (): metodo privado que devuelve un valor double y permite calcular la asignacion realizada segun la antiguedad al sueldo basico
       @return importe total con la suma de la asignacion correspondiente segun la antiguedad**/

    private double adicional(){
        int anti = antiguedad();
        double sb = this.getImporte();
        if(anti < 2){
            return sb * 0.02;
        }
        if (anti >= 2 && anti < 10){
            return sb * 0.04;
        }else{
            return sb * 0.06;
        }
    }
    
    /**METODO NETO (): metodo publico que devuelve un valor double y permite calcular la suma del sueldo básico más el adicional, menos el descuento. 
        @returns el sueldo final luego de aplicarse el adicional y el descuento**/
    public double neto(){
        double suelbas = this.getImporte();
        return (suelbas + adicional() - descuento());
    }
    
    /**mostrar(): imprime por pantalla*/
    public void mostrarPantalla (){
        System.out.println ("Nombre y Apellido: "+nomYApe() );
        System.out.println ("CUIL: "+this.getCuil()+ "\tAntiguedad: " +antiguedad() + "\taños de Servicio"); 
        System.out.println ("Sueldo Neto: " +neto()); 
 
    }
    
    /**METODO MOSTRARLINEA (): muestra por pantalla el valor del cuil, el apellido y nombre y el valor neto
       @returns un string con la concatenacion de los valores del cuil, el apellido y nombre y el valor neto**/
    public String mostrarLinea() {
        return(this.getCuil()+ " " +apeYNom()+ " ..........$" +neto());
    }
}
