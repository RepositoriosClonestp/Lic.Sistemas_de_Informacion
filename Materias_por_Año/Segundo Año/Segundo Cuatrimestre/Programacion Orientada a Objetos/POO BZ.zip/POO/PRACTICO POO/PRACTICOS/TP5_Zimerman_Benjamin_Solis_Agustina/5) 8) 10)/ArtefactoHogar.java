
/**
 * Write a description of class ArtefactoHogar here: 
 * 
 * @author (Solis Agustina, Zimerman Benjamin) 
 * @version (10/10724)
 */
public abstract class ArtefactoHogar{
    private int stock; 
    private float precio; 
    private String marca; 

    /**CONSTRUCTORES: crea e inicializa objetos de la clase ArtefactoHogar
       @param: p_marca: marca del electrodomedisto
       @param p_stock. stock disponible
       @param p_precio: precio del equipo**/
    public ArtefactoHogar(String p_marca, int p_stock, float p_precio){
        this.setMarca(p_marca);
        this.setStock(p_stock); 
        this.setPrecio(p_precio); 
    }

    /**ACCESORS**/
    /**setters**/
    protected void setMarca(String p_marca){
        this.marca = p_marca; 
    }

    protected void setPrecio (float p_precio){
        this.precio = p_precio;
    }

    protected void setStock(int p_stock){
        this.stock = p_stock;
    } 

    /**getters*/
    public String getMarca() {
        return this.marca; 
    }

    public float getPrecio () {
        return this.precio;
    }

    public int getStock (){
        return this.stock; 
    }
    
    /**METODOS**/
    /**public float cuotaCredito (int p_cuotas, float p_interes): 
       @return el valor de cada cuota calculado de acuerdo a la cantidad de cuotas y el interes ingresados como parametro**/
    public float cuotaCredito (int p_cuotas, float p_interes) {
        return ((this.getPrecio() + (this.getPrecio() *  p_interes)/100)) / p_cuotas;
    }
        
    protected abstract float creditoConAdicional (int p_cuotas, float p_interes); 
    
    /**public void imprimir(): imprime por pantalla la marca, stock y precio del producto**/
    public void imprimir () {
        System.out.println ("Marca: " + this.getMarca() + "\t-"+ "Precio: " + this.getPrecio() + "\t-" + "Stock: " + this.getStock());
    }

}
