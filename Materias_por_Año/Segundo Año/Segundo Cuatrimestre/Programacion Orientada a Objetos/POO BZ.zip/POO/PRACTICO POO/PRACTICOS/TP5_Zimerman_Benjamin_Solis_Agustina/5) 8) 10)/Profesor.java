
/**
 * Write a description of class Profesor here.
 * 
 * @author (Solis Agustina, Zimerman Benjamin) 
 * @version (02/10/24)
 */
import java.util.*; 

public class Profesor extends Persona{
    /**ATRIBUTOS PROPIOS DE LA CLASE(NO HEREDADOS)**/
    private String titulo; 
    private ArrayList <Cargo> cargos; 
    
    /**Metodo Costructor: permite crear objetosde la clase Profesor
     * @param p_titulo: titulo del prof.
     * @param p_cargo: cargo del profesor
     * @param p_nombre: nombre del profesor. 
     * @param p_apellido: herencia de clase Persona;apellido del profesor. 
     * @param p_dni: herencia de clase Persona; dni del profesor. 
     * @param p_anio: herencia de clase Persona; año de nacimiento del profesor. 
    **/
    
    public Profesor (String p_titulo,Cargo p_cargo, String p_nombre, int  p_dni, String p_apellido,int p_anio) {
        super(p_dni, p_nombre, p_apellido,p_anio); 
        this.setTitulo(p_titulo); 
        this.setCargos(new ArrayList <Cargo>());
        this.agregarCargo(p_cargo); 
        this.quitarCargo(p_cargo); 
    }
    
    /**Metodo Costructor: permite crear objetosde la clase Profesor
     * @param p_titulo: titulo del prof.
     * @param p_cargos:arraylist de objetos Cargo del profesor
     * @param p_nombre: nombre del profesor. 
     * @param p_apellido: herencia de clase Persona;apellido del profesor. 
     * @param p_dni: herencia de clase Persona; dni del profesor. 
     * @param p_anio: herencia de clase Persona; año de nacimiento del profesor. 
    **/
    public Profesor (String p_titulo, ArrayList <Cargo> p_cargos,String p_nombre, int  p_dni, String p_apellido,int p_anio){ 
        super(p_dni, p_nombre, p_apellido,p_anio);
        this.setTitulo(p_titulo); 
        this.setCargos(p_cargos); 
    }
    
    
    /**ACCESORS**/
    /**setters**/
    private void setTitulo(String p_titulo) {
        this.titulo = p_titulo;
    }
    
    private void setCargos(ArrayList <Cargo> p_cargos) {
        this.cargos = p_cargos; 
    }
    
    /**getters**/
    public String getTitulo(){
        return this.titulo; 
    }
    
    public ArrayList <Cargo> getCargos() {
        return this.cargos; 
    }
    
    /**METODOS**/
    
    /**agregarCargo (Cargo p_cargo): permite ingresar un objeto Cargo al arraylist
       @return el arraylist con el objeto Cargo ingresado como parametro**/
    public boolean agregarCargo (Cargo p_cargo) {
        return this.getCargos().add(p_cargo); 
    }
    
    /**quitarCargo(Cargo p_cargo): permite quitar un objeto Cargo del arraylist
       @return: el arraylist sin el objeto Cargo ingresado como parametro**/
    public boolean quitarCargo (Cargo p_cargo){
        return this.getCargos().remove(p_cargo); 
    }
    
    /**public double sueldoTotal(): metodo publico que permite calcular el sueldo total del profesor al sumar los 
       atributos suedo de cada objeto dentro del arraylist de Cargos
       @return sueldo total**/
    public double sueldoTotal(){
       double suma = 0; 
       for (int i=0; i<this.getCargos().size();i++){
           suma += ((Cargo)this.getCargos().get(i)).sueldoDelCargo();
       }
       return suma; 
    }
    
    /**public void listarCargos(): lista todos los cargos de un profesor**/
    public void listarCargos() {
        System.out.println ("**** CARGOS ASIGNADOS ****");
        //System.out.println ("----------------------------");
        for (Cargo cargos:this.getCargos()){
            cargos.mostrarCargo();
       }
    }
    
    /**public String mostrarLinea(): 
       @return un String con el Nombre, DNI y suleldo total de un profesor**/
    public String mostrarLinea() {
         return "DNI: " + super.getDni()+ "\t-" + "Nombre: "+ super.getNombre() + "\t" + "Sueldo Total: " + sueldoTotal();
    }
    
    /**public void mostrar(): imprime por pantalla**/
    public void mostrar() {
        super.mostrar(); 
        System.out.println("Titulo: "+ this.getTitulo());
        this.listarCargos(); 
        System.out.println("** Sueldo Total: $"+this.sueldoTotal());
    }
}
    

