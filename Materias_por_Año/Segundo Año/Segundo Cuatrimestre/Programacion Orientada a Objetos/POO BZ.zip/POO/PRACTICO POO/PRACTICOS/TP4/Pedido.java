/**
 * Ejercicio 2 Clase Pedido
 * @author Zimerman Benjamin, Solis Agustina Aylen 
 * @version (11/9/24)
 */
import java.util.*;
import java.util.Calendar;
import java.text.DateFormat;
public class Pedido{
    private Calendar fecha;
    private Cliente cliente;
    private ArrayList <Producto> productos;

    public Pedido(Calendar p_fecha, Cliente p_cliente, ArrayList p_productos){
        this.setFecha(p_fecha);
        this.setCliente(p_cliente);
        this.setProductos(p_productos);        
    }

    public Pedido(Calendar p_fecha, Cliente p_cliente, Producto p_producto){
        this.setFecha(p_fecha);
        this.setCliente(p_cliente);
        this.setProductos(new ArrayList());
        this.agregarProducto(p_producto);
        this.quitarProducto(p_producto);
    }

    private void setFecha(Calendar p_fecha){
        this.fecha = p_fecha;
    }

    private void setCliente (Cliente p_cliente){
        this.cliente = p_cliente;
    }

    private void setProductos(ArrayList<Producto> p_productos){
        this.productos = p_productos ;
    }

    public Calendar getFecha(){
        return this.fecha;
    }

    public Cliente getCliente(){
        return this.cliente;
    }

    public ArrayList <Producto> getProductos(){
        return this.productos;
    }

    public boolean agregarProducto(Producto p_producto){
        return this.getProductos().add(p_producto);
    }

    public boolean quitarProducto(Producto p_producto){
        return this.getProductos().remove(p_producto);
    }

    /** */
    public double totalAlContado(){
        double sum = 0; 
        for(int i=0; i<this.getProductos().size();i++){
            sum += ((Producto)this.getProductos().get(i)).precioContado();
        }
        return sum;
    }

    public double totalFinanciado(){
        double sum = 0; 
        for(int i=0; i<this.getProductos().size();i++){
            sum += ((Producto)this.getProductos().get(i)).precioLista();
        }
        return sum;
    }

    public void mostrarPedido() {
       DateFormat formatoFecha = DateFormat.getDateInstance(DateFormat.FULL); 
        String fechaFormateada = formatoFecha.format(this.getFecha().getTime());
        System.out.println("****** Detalle del pedido ******\t Fecha: " + fechaFormateada);
        cliente.mostrar();
        System.out.println("Producto    Precio Lista    Precio Contado\n--------------------------------------------------------");

        for (Producto unProducto : this.getProductos()) {
            unProducto.mostrarLinea();
        }
        System.out.println("--------------------------------------------------------");
        System.out.println("***Total------- $" + this.totalFinanciado() + "\t\t$" + this.totalAlContado());
    }

}
