
/**
 * Write a description of class EjecutableFacultad here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EjecutableFacultad
{
    public static void main (String [] args){
        //Instanciacion objetos cargos: hasta 3 por profesor, se instanciaran 3 profesores
        // public SemiExclusivo(int p_horasI, String p_nombreC, double p_sueldoB, int p_anioI, int p_horas)
        //public Exclusivo(int p_horasI, int p_horasE, String p_nombreC, double p_sueldoB, int p_anioI, int p_horas )
        // public Cargo (String p_nombreC, double p_sueldoB, int p_anioI, int p_horas)
        Cargo c1 = new Cargo ("JTP-PROGRAMACION OO",5000.0, 2000, 10);
        Cargo c2 = new Exclusivo (20, 10, "JTP-LOGICA Y MC", 2500.5, 2010, 4);
        Cargo c3 = new SemiExclusivo(8, "JTP-Algebra", 3000, 2015, 10); 
        
        //public Profesor (String p_titulo, ArrayList <Cargo> p_cargos,String p_nombre, int  p_dni, String p_apellido,int p_anio)
        Profesor profe1 = new Profesor("Ing. en Sistemas de Informacion",c1, "Juan", 41252293, "Perez", 1984);
        profe1.agregarCargo(c2); 
        profe1.agregarCargo(c3); 
        profe1.mostrarLinea();
        profe1.mostrar(); 
        
        Cargo c4 = new Cargo ("JTP-Ingenieria de Software II",6500.0, 1999, 12);
        Cargo c5 = new Exclusivo (30, 10, "JTP-Algoritmos I", 4500, 2020, 8);
        
        Profesor profe2 = new Profesor ("Lic. en Sistemas de Informacion", c4, "Mirta",39145369, "Lopez", 1980);
        profe2.agregarCargo(c5); 
        profe2.mostrar(); 
        
        
        Cargo c7 = new SemiExclusivo(25, "TITULAR-Sistemas Operativos", 7000, 2004, 15); 
        Profesor profe3 = new Profesor ("Lic. en Sistemas de Informacion", c7 ,"Sofia", 40785123, "Gomez", 1990);
        profe3.agregarCargo(c7); 
        profe3.mostrar(); 
         
         Facultad facu = new Facultad ("FACENA", profe1);
         facu.agregarProfe(profe1); 
         facu.agregarProfe(profe2); 
         facu.agregarProfe(profe3); 
        
         facu.nominaProfesores(); 
        
        
        
        
        
        
        
    }
}
