/**
 * Clase abstracta FiguraGeometrica la cual se define sus metodos
 * en las subclases.
 * 
 * @author Zimerman Benjamin, Solis Agustina Aylen 
 * @version (9/10/24)
 */
public abstract class FiguraGeometrica{
    /**Atributo
       Colaborador entre FigruaGeometrica y la clase Punto*/
    private Punto origen;
    
    /**Constructor: crea e inicializa objetos de la clase FigruaGeometrica
       @param p_origen: origen de la figura.*/
    public FiguraGeometrica(Punto p_origen){
        this.setOrigen(p_origen);
    }
    
    /**ACCESORS
       SETTER*/
    protected void setOrigen(Punto p_origen){
        this.origen = p_origen;
    }
    /**GETTER*/
    public Punto getOrigen(){
        return this.origen;
    }
    
    /**Metodo abstracto nombreFigura().
       @return nombre de la figura que especializa el metodo*/
    public abstract String nombreFigura();

    /**Metodo abstracto  superficie()
       @return superficie de la clase figura que lo invoque y especialice*/
    public abstract double superficie();
    
    /**Metodo mostrar Superficie()
       @return imprime la superficie de la figura que haya invocado*/
    public void mostrarSuperficie(){
        System.out.println("Supeficie: " +this.superficie());
    }
    
    /**Metodo coordenadas()
       @return coordenadas correspondientes del objeto que lo invoque*/
    public String coordenadas(){
        return this.origen.coordenadas();
    }
}
