/**
 *CLASE EJECUTBLE EMPRESA.
 * 
 * @author (Zimerman Benjamin, Solis Agustina) 
 * @version (30/09/24)
 */
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class Empresa {
    public static void main(String[] args) {

        Persona a1 = new Persona(34567898, "Dario", "Perez", 2000);
        Persona a2 = new Persona(10245896, "Armando", "Mendoza", 1998);

        Empleado emp1 = new Empleado(34567898, "Dario", "Perez", 200000, 1990,45023458, 2008);
        Empleado emp2 = new Empleado(10245896, "Armando", "Mendoza", 300000, 1999,45023458, 2010);

        a1.mostrar();
        System.out.println("--------------------------------------------------");
        a2.mostrar();
        System.out.println("--------------------------------------------------");
        emp1.mostrar();
        System.out.println("--------------------------------------------------");
        emp2.mostrar();

    }
}
