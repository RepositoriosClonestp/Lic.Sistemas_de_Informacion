/**. Crear una clase denominada OrdenVector, que permita ingresar por teclado (Scanner) 4 elementos de tipo 
doble, y almacenarlos en un array. Determinar el menor elemento y mostrarlo. Ordenar los elementos del 
vector de menor a mayor. Mostrar los elementos ordenados, separados por un tabulador. Usar instrucción
FOR para el ingreso de datos. Utilizar método de la Burbuja.*/
import java.util.Scanner;
public class OperarVector9{
  public static void main (String [] args){
      Scanner scanner = new Scanner (System.in);
      double [] notas = new double[4];
      double elMenor = Double.MAX_VALUE; 
      int i;
      for(i=0; i < notas.length; i++ ){
        System.out.println("Ingrese nota del alumno "+(i+1)+ ":");
        notas[i] = scanner.nextDouble();
        if(notas [i] < elMenor){
            elMenor = notas[i];
        }
    }
      for(i= 0; i< notas.length; i++){
        System.out.println(+notas[i]+"\t");
    }

    System.out.println("Menor nota: "+elMenor);
    /**METODO BURBUJA*/
    for(i = 0; i < notas.length-1; i++){
            for(int j = 0; j < notas.length-1; j++){
        if(notas [j] > notas[j+1]){
            double aux = notas[j];
            notas[j] = notas[j+1];
            notas[j+1] = aux;
        }
        }
    }
    
        System.out.println("Array ordenado de menor a mayor:");
        for(i = 0; i < notas.length; i++){
            System.out.println("\t "+notas[i]);
        }
    scanner.close();
}
}