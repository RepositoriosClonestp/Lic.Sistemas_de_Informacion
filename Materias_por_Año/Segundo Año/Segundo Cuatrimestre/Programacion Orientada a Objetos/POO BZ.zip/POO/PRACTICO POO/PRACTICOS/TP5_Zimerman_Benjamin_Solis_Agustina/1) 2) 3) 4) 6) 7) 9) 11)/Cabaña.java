import java.util.*;

/**
 * Clase Cabaña.
 * 
 * <p>La clase Cabaña representa una cabaña con un número específico de habitaciones.</p>
 * 
 * @author Zimerman Benjamin
 * @autor Solis Agustina A.
 * @version 28/8/24
 */
public class Cabaña extends Alojamiento {
    
    /**
     * Número de habitaciones en la cabaña.
     */
    private int nroHabitaciones;

    /**
     * Constructor de la clase Cabaña.
     * 
     * @param p_nroHab el número de habitaciones
     * @param p_nombre el nombre de la cabaña
     * @param p_precio el precio base del alquiler
     * @param p_dAlq la cantidad de días de alquiler
     * @param p_servicios los servicios asociados
     */
    public Cabaña(int p_nroHab, String p_nombre, double p_precio, int p_dAlq, Servicio p_servicios) {
        super(p_nombre, p_precio, p_dAlq, p_servicios);
        this.setNroHabit(p_nroHab);
    }

    /**
     * Establece el número de habitaciones de la cabaña.
     * 
     * @param p_nroHab el nuevo número de habitaciones
     */
    private void setNroHabit(int p_nroHab) {
        this.nroHabitaciones = p_nroHab;
    }

    /**
     * Obtiene el número de habitaciones de la cabaña.
     * 
     * @return el número de habitaciones
     */
    public int getNroHabit() {
        return this.nroHabitaciones;
    }

    /**
     * Calcula el costo del alquiler de la cabaña.
     * 
     * @return el costo del alquiler
     */
    @Override
    public double costo() {
        return super.costo() + this.getNroHabit() * 30;
    }

    /**
     * Cuenta la cantidad de días alquilados para la cabaña.
     * 
     * @param p_alojamiento el tipo de alojamiento
     * @return la cantidad de días alquilados
     */
    @Override
    public int contar(String p_alojamiento) {
        return this.getDiasAlqui();
    }

    /**
     * Realiza la liquidación de la cabaña.
     */
    @Override
    public void liquidar() {
        System.out.println("Cabaña con " + this.getNroHabit() + " habitaciones");
        System.out.println("Total: ------> $" + (this.costo() + this.costoServicios()));
    }
}
