import java.util.Calendar;
import java.util.GregorianCalendar;
/**Paquetes de Java importados para el calculo del año**/
/**DEFINICION CLASE EMPLEADO**/
public class Empleado
{
    /**ATRIBUTOS DE LA CLASE**/
    private long cuil;
    private String apellido;
    private String nombre;
    private double sueldoBasico;
    private int anioIngreso;

    /**METODO CONSTRUCTOR: crea e inicializa objetos de la clase EMPLEADO*/

    public Empleado(long p_cuil, String p_apellido, String p_nombre, double p_importe, int p_anio){
        this.setCuil(p_cuil);
        this.setApe(p_apellido);
        this.setNom(p_nombre);
        this.setImporte(p_importe);
        this.setAnio(p_anio);        
    }

    /**SETTERS**/
    /**SetCuil (long p_cuil): modifica el valor del atributo Cuil de tipo long**/
    private void setCuil(long p_cuil){
        this.cuil = p_cuil;
    }

    /**setApe (String p_apellido): modifica el valor del atributo apellido de tipo String**/
    private void setApe(String p_apellido){
        this.apellido = p_apellido;
    }

    /**setNom (String p_nombre): modifica el valor del atributo nombre de tipo String**/
    private void setNom(String p_nombre){
        this.nombre = p_nombre;
    }

    /**setImporte (double p_importe): modifica el valor el atributo importe de tipo double**/
    private void setImporte(double p_importe){
        this.sueldoBasico = p_importe;
    }

    /**setAnio (in p_anio): modifica el valor del atributo año de tipo int **/
    private void setAnio(int p_anio){
        this.anioIngreso = p_anio;
    }

    /**GETTERS*/
    /**getCuil: obtiene el valor del atributo cuil de tipo long **/
    public long getCuil(){
        return cuil;
    }

    /**getApellido: obtiene el valor del atributo apellido de tipo String**/
    public String getApellido(){
        return apellido;
    }

    /**getNombre: obtiene el valor del atributo nombre de tipo String**/
    public String getNombre(){
        return nombre;
    }

    /**getImporte: obtiene el valor del atributo importe de tipo double**/
    public double getImporte(){
        return sueldoBasico;
    }

    /**getAnio: obtiene el valor del atributo año de tipo int**/
    public int getAnio(){
        return anioIngreso;
    }

    /**METODO nomYAPE(): metodo publico que Concatena nombre y apelido**/
    public String nomYApe(){
        return this.getNombre()+ ", " +this.getApellido();
    }

    /**METODO apeYNom (): metodo publico que concatena aprllido y nombre**/
    public String apeYNom(){
        return this.getApellido()+ ", " +this.getNombre();
    }

    /**METODO DESCUENTO (): metodo privado que permite calcular al 2% del sueldo básico en concepto de obra social, mas $1500 de seguro de 
    vida**/
    private double descuento(){
        return ((this.getImporte() * 0.02) + 1500);  
    }

    /**METODO ADICIONAL (): metodo privado que devuelve un valor double y permite calcular la asignacion realizada segun la antiguedad al sueldo basico**/
    private double adicional(){
        int anti = antiguedad();
        double sb = this.getImporte();
        if(anti < 2){
            return sb * 0.02;
        }
        if (anti >= 2 && anti < 10){
            return sb * 0.04;
        }else{
            return sb * 0.06;
        }
    }

    /**METODO NETO (): metodo publico que devuelve un valor double y permite calcular la suma del sueldo básico más el adicional, menos el descuento. **/
    public double neto(){
        double suelbas = this.getImporte();
        return (suelbas + adicional() - descuento());
    }

    /**METODO ANTIGUEDAD: metodo publico que devuelve un int y permite calcular la antiguedad de los empleados**/
    public int antiguedad() {
        Calendar fechaHoy = new GregorianCalendar();/**Nueva variable fecha de hoy*/
        int anioHoy = fechaHoy.get(Calendar.YEAR);/**Asigno valor entero a la fecha*/
        return anioHoy - this.getAnio();/**Resto al año actual el de nacimiento*/
    }

    /**METODO MOSTRAR (): muestra por pantalla**/
    public void mostrar(){
        System.out.println("Nombre y Apellido: "+nomYApe());
        System.out.println("CUIL: "+this.getCuil()+" Antiguedad: "+antiguedad()+ " años de servicio");
        System.out.println("Sueldo neto: $" +neto()); 
    }

    /**METODO MOSTRARLINEA (): muestra por pantalla el valor del cuil, el apellido y nombre y el valor neto**/
    public String mostrarLinea(){
        return(this.getCuil()+ " " +apeYNom()+ " ..........$" +neto());
    }
}