
/**
 * Ejercicio 10.CLASE MUJER.
 * 
 * @author (Zimerman Benjamin, Solis Agustina) 
 * @version (6/09/24)
 */
public class Mujer
{   
    /**ATRIBUTOS**/
    private String nombre;
    private String apellido;
    private int edad;
    private String estadoCivil;
    private Hombre esposo;
    
    /**METODO CONSTRUCTOR: permite crear e instanciar objetos de la clase mujer
     * @param p_nombre: nombre de la mujer.
     * @param p_apellido: apellido de la mujer.
     * @param p_edad: edad de la mujer. 
    */
    public Mujer(String p_nombre, String p_apellido, int p_edad){
        this.setNombre(p_nombre);
        this.setApellido(p_apellido);
        this.setEdad(p_edad);
        this.setEstCiv("Soltera");
    }
    
    /**METODO CONSTRUCTOR: permite crear e instanciar objetos de la clase mujer
     * @param p_nombre: nombre de la mujer.
     * @param p_apellido: apellido de la mujer.
     * @param p_edad: edad de la mujer. 
     * @param p_esposo: objeto de la clase Hombre
    */
    public Mujer(String p_nombre, String p_apellido, int p_edad, Hombre p_esposo){
        this.setNombre(p_nombre);
        this.setApellido(p_apellido);
        this.setEdad(p_edad);
        this.setEsposo(p_esposo);
    }

    /**ACCESORS*/
    /**setNombre(String p_nombre): actualiza el estado del atributo nombre
     * @param p_nombre: nombre de la mujer
    */
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    /**setApellido(String p_apellido):actualiza el estado del atributo apellido
     * @param p_apellido: apellido de la mujer
    */
    private void setApellido(String p_apellido){
        this.apellido = p_apellido;
    }
    
    /**setEdad(int p_edad): actualiza el estado del atributo edad
     * @param p_edad: edad de la mujer
    */
    private void setEdad(int p_edad){
        this.edad = p_edad;
    }

    /**setEstCiv(String p_estCiv): actualiza el estado del atributo estadoCivil.
     * @param p_estCiv: estado civil de la mujer
    */
    private void setEstCiv(String p_estCiv){
        this.estadoCivil = p_estCiv;
    }
    
    /**setEsposo(Hombre p_esposo): actualiza el estado del atributo esposo
     * @param p_esposo: esposo de la mujer
    */
    private void setEsposo(Hombre p_esposo){
        this.esposo = p_esposo;
    }

    /**GETTERS*/
    /**getNombre(): obtiene el estado del atributo nombre
       @return: nombre
    */
    public String getNombre(){
        return this.nombre;
    }
    
    /**getApellido():obtiene el estado del atributo apellido.
     * @return apellido;
    */
    public String getApellido(){
        return this.apellido;
    }

    /**getEdad(): obtiene el estado del atributo edad
     * @return edad.
    **/
    public int getEdad(){
        return this.edad;
    }

    /**getEstCiv(): obtiene el estado del atributo estadoCivil
     * @return estadoCivil
    */
    public String getEstCiv(){
        return this.estadoCivil;
    }
    
    /**getEsposo(): obtiene el estado del atributo esposo
     * @return esposo
    */
    public Hombre getEsposo(){
        return this.esposo;
    }
    
    /**Metodo divorcio(): actualiza el estado civil de la mujer: si esta casada, lo modifica a soltera y setea el 
       atributo esposo a null*/
    public void divorcio(){
        if(this.getEstCiv() == "Casada"){
            this.setEstCiv("Soltera");
            this.esposo.divorcio();
            this.setEsposo(null);
        }
    }
    
    /** metodo casarseCon(Hombre p_hombre): asigna el objeto hombre al atributo esposo de la mujer y modifica 
       su atributo EstCiv a casada 
       @param p_hombre: objeto hombre temporal.
       */
    public void casarseCon(Hombre p_hombre) {
        if (this.getEsposo() == null) {
            this.setEstCiv("Casada");
            this.setEsposo(p_hombre);
            p_hombre.casarseCon(this);
    }
}
    
    /**metodo datos(): concatena en un string los estados de los atributos nombre, apellido y edad
     * @return un srting con dicha concatenacion
    */
    public String datos(){
        return this.getNombre()+ " " +this.getApellido()+ " de " +this.getEdad()+ " años";
    }
    
    /**mostrarEstadoCivil(): imprime por pantalla el estado del atributo EstCiv**/
    public void mostrarEstadoCivil(){
        System.out.println("Estado civil: "+this.getEstCiv());
    }
    
    /**casadaCon(): imprime por pantalla el estado del atributo datos y Esposo*/
    public void casadaCon(){
        System.out.println(this.datos()+ " esta casada con "+this.getEsposo().datos());
    }
}

