
/**
 * Write a description of class Comercio here.
 * 
 * @author (Solis Agustina, Zimerman Benjamin) 
 * @version (10/10/24)
 */
import java.util.Scanner; 

public class Comercio {
    public static void main(String[] args){
         Scanner scan = new Scanner(System.in);
         System.out.println ("***BIENVENIDOS***");
         /**Ingreso por teclado de los atributos de la clase Cocina**/
         //public Cocina(int p_hornallas, String p_dimensiones, int p_calorias)
         System.out.println("------------------------------------");
         System.out.println ("PRODUCTO: COCINA");
         System.out.println ("Cantidad de hornallas: ");
         int hornallas =scan.nextInt(); 
         System.out.println("Dimensiones: CM-CM-CM");
         String dimensiones = scan.next(); 
         scan.nextLine(); 
         System.out.println ("Calorias: ");
         int calorias = scan.nextInt(); 
         System.out.println("Ingrese la marca del producto: ");
         String marca1= scan.next(); 
         System.out.println ("El stock disponible es de: ");
         int stock1 = scan.nextInt(); 
         System.out.println ("El precio del producto es: ");
         float precio1 = scan.nextFloat(); 
         System.out.println("Cantidad de cuotas a cotizar: ");
         int cuota1 = scan.nextInt(); 
         System.out.println ("Interes de las cuotas: ");
         float interes1 = scan.nextFloat(); 
         
         /**Ingreso por teclado de los atributos de la clase Heladera **/
         //public Heladera(int p_pies, int p_puertas, boolean p_compresor
         System.out.println("------------------------------------");
         System.out.println ("PRODUCTO: HELADERA");
         System.out.println ("Pies: ");
         int pies = scan.nextInt();
         scan.nextLine();
         System.out.println ("Puertas: ");
         int puertas = scan.nextInt(); 
         System.out.println ("¿Tiene compresor el modelo?");
         boolean compresor = scan.nextBoolean();
         System.out.println("Ingrese la marca del producto: ");
         String marca2= scan.next(); 
         System.out.println ("El stock disponible es de: ");
         int stock2 = scan.nextInt(); 
         System.out.println ("El precio del producto es: ");
         float precio2 = scan.nextFloat(); 
         System.out.println("Cantidad de cuotas a cotizar: ");
         int cuota2 = scan.nextInt(); 
         System.out.println ("Interes de las cuotas: ");
         float interes2 = scan.nextFloat(); 
         
         /**Ingreso por teclado de los atributos de la clase Lavarropas*/
         System.out.println("------------------------------------");
         System.out.println ("PRODUCTO: LAVARROPAS");
         //public Lavarropas(int p_programas, float p_kilos, boolean p_auto,
         System.out.println("Programas: ");
         int programas = scan.nextInt();
         System.out.println("Kilos: ");
         float kilos = scan.nextFloat(); 
         System.out.println("¿El modelo de lavarropas es automatico?: ");
         boolean auto = scan.nextBoolean(); 
         
         System.out.println("Ingrese la marca del producto: ");
         String marca3= scan.next(); 
         System.out.println ("El stock disponible es de: ");
         int stock3 = scan.nextInt(); 
         System.out.println ("El precio del producto es: ");
         float precio3 = scan.nextFloat(); 
         System.out.println("Cantidad de cuotas a cotizar: ");
         int cuota3 = scan.nextInt(); 
         System.out.println ("Interes de las cuotas: ");
         float interes3 = scan.nextFloat(); 
         
         /**Instanciacion objetos: Lavarropas, Cocina, Heladera*/
         Lavarropas lv = new Lavarropas (programas, kilos, auto, marca1, stock1, precio1);
         lv.creditoConAdicional(cuota1,interes1);
          
         
         Cocina coc = new Cocina(hornallas, dimensiones, calorias, marca2, stock2, precio2);
         coc.creditoConAdicional (cuota2, interes2); 
         
         Heladera hel = new Heladera (pies, puertas, compresor, marca3, stock3, precio3);
         hel.creditoConAdicional(cuota3, interes3); 
         
         lv.imprimir(cuota1, interes1); 
         System.out.println("------------------------------------");
         coc.imprimir ();
         System.out.println("------------------------------------");
         hel.imprimir(cuota3, interes3); 
         
         
         
         
         
         
         
         
         
         
        
                 
         
    }
}
