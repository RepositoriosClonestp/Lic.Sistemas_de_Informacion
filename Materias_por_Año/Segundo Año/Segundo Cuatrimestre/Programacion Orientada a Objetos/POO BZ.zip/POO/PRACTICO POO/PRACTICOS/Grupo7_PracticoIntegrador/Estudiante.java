import java.util.ArrayList;

/**
 * La Clase Estudiante proporciona métodos para verificar si un Socio Estudiante puede pedir un libro prestado y de retorno de String informando a qué 
 * clase de Socio pertenece.
 * 
 * @author X, Ingrid Noelí.
 * @version (7/11/24).
 */
public class Estudiante extends Socio
{
    private String carrera;
    
     /**
     * Constructor que inicializa los atributos por parametro.
     * @param p_dniSocio      DNI del Socio.
     * @param p_nombre        Nombre del Socio.
     * @param p_diasPrestamo  Días máximo de prestamo para el Socio.
     * @param p_carrera       Carrera a la que pertenece el Estudiante.
     */
    public Estudiante(int p_dniSocio, String p_nombre, int p_diasPrestamo, String p_carrera){
        super(p_dniSocio,p_nombre,p_diasPrestamo);
        this.setCarrera(p_carrera);
    }

    //getters y setters.
    private void setCarrera(String p_carrera){
        this.carrera = p_carrera;
    }

    public String getCarrera(){
        return this.carrera;
    }
    
    /**
     * Verifica si el Estudiante no tiene más de la cantidad de libros permitidos prestados y un préstamo vencido.
     * @return boolean devolverá true en caso de que cumpla los requisitos, false en caso contrario.
     */
    public boolean puedePedir(){
        boolean condi = super.puedePedir();

        if(condi == true && super.cantLibrosPrestados() <= 3){
            return true;
        }else{
            return false;
        }
    }
    
    /**
     * Especificación del método abstracto soyDeLaClase(), heredado de la Clase Socio.
     * @return string de la clase de Socio.
     */
    public String soyDeLaClase(){
        return ("Estudiante");
    }
}
