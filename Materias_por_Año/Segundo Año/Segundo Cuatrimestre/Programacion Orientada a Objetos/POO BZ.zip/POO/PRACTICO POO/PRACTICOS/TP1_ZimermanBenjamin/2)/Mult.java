
public class Mult
{
    private static int i=0;
    public static void main (String [] args){
    
     for (i = 42; i <= 150; i++) {
        
        if (i % 4 == 0){
            System.out.println(i);
        }
    }
    }
}