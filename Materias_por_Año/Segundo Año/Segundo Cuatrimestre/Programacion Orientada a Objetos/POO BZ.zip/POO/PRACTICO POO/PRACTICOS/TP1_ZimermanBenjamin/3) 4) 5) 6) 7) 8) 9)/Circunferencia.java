public class Circunferencia {
    
    public static void main(String[] args) {
       int r = Integer.valueOf(args [0]);
       double perimetro = 2*Math.PI*r;
       System.out.println("Perimetro de Circunferencia: "+perimetro);
    }
}