
/**
 * Write a description of class Cocina here.
 * 
 * @author (Solis Agustina Aylen, Zimerman Benjamin) 
 * @version (10/10/24)
 */
public class Cocina extends ArtefactoHogar {
    private int hornallas;
    private int calorias; 
    private String dimensiones; 
    
    private int cuotas; 
    private float interes;
    /**
     * Constructor for objects of class Cocina: crea e inicializa objetos de la clase Cocina: 
     * @param p_hornallas: cantidad de hornallas
     * @param p_dimensiones: tamaño de la cocina
     * @param p_calorias: calorias de la cocina
     * @param: p_marca: marca del electrodomedisto
       @param p_stock. stock disponible
       @param p_precio: precio del equipo
     */
    public Cocina(int p_hornallas, String p_dimensiones, int p_calorias, String p_marca, int p_stock, float p_precio ){
        super(p_marca, p_stock, p_precio); 
        this.setHornallas(p_hornallas); 
        this.setDimensiones(p_dimensiones);
        this.setCalorias(p_calorias);
    }

    /**ACCESORS*/
    /**setters*/
    private void setHornallas(int p_hornallas) {
        this.hornallas = p_hornallas; 
    }
    
    private void setCalorias (int p_calorias){
        this.calorias = p_calorias; 
    }
    
    private void setDimensiones (String p_dimensiones){
        this.dimensiones = p_dimensiones; 
    }
    
     private void setCuotas(int p_cuotas){
        this.cuotas = p_cuotas; 
    }
    
    private void setInteres(float p_interes) {
        this.interes = p_interes; 
    }
    /**getters*/
    private int getHornallas(){
        return this.hornallas; 
    }
    
    private int getCalorias() {
        return this.calorias;
    }
    
    private String getDimensiones(){
        return this.dimensiones; 
    }
    
    public int getCuotas(){
        return this.cuotas; 
    }
    
    public float getInteres(){
        return this.interes; 
    }
    
    /**METODOS*/
    /**public float creditoConAdicional(int p_cuotas, float p_interes): 
       calcula el valor total de las cuotas de una cocina
       @return precio final de cada cuota**/
    public float creditoConAdicional(int p_cuotas, float p_interes) {
        float adicional=0; 
        adicional = super.cuotaCredito (p_cuotas, p_interes); 
        return adicional; 
    }
    /**public void imprimir(): imprime por pantalla la marca, stock y precio del producto, 
        asi como tambien eñ estado de sus atributos dimensiones, calorias y hornallas**/
    public void mostrar(int p_cuotas, float p_interes) {
        System.out.println ("***COCINA***");
        super.imprimir(); 
        System.out.println ("Hornallas: "+this.getHornallas());
        System.out.println("Calorias: "+this.getCalorias());
        System.out.println("Dimensiones: "+this.getDimensiones());
        System.out.println("Cuotas: "+this.getCuotas()+ "\t" + "Interes: "+this.getInteres());
        System.out.println("Valor Cuota:"+ super.cuotaCredito(p_cuotas, p_interes));
        System.out.println("Valor Cuota con Adicionales: "+this.creditoConAdicional(p_cuotas,p_interes));
    }
}











