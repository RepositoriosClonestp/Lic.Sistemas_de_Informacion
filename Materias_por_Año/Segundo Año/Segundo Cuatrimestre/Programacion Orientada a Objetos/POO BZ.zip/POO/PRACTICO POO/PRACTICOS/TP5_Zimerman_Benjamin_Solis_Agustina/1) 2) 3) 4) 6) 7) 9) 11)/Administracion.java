import java.util.*;
import java.util.Scanner;

/**
 * Clase Administracion.
 * 
 * <p>La clase Administracion se encarga de ejecutar el programa principal que maneja un jardín con diferentes figuras geométricas.</p>
 * 
 * @autor Zimerman Benjamin
 * @autor Solis Agustina Aylen
 * @version 28/8/24
 */
public class Administracion {

    /**
     * Método principal para la ejecución del programa.
     * 
     * @param args los argumentos de la línea de comandos
     */
    public static void main(String[] args) {
        Jardin j1 = new Jardin("La gotita traviesa");
        j1.setFiguras(new ArrayList<>());

        /**
         * Se instancia un nuevo objeto de la clase Punto con coordenadas (1, 2).
         */
        Punto p1 = new Punto(1, 2);

        /**
         * Se instancia un nuevo objeto de la clase Circulo.
         */
        Circulo cir1 = new Circulo(p1, 5);
        j1.agregarFigura(cir1);

        /**
         * Se instancia un nuevo objeto de la clase Punto con coordenadas (3, 4).
         */
        Punto p2 = new Punto(3, 4);

        /**
         * Se instancia un nuevo objeto de la clase Cuadrado.
         */
        Cuadrado cua1 = new Cuadrado(p2, 20);
        j1.agregarFigura(cua1);

        /**
         * Se instancia un nuevo objeto de la clase Punto con coordenadas (5, 6).
         */
        Punto p3 = new Punto(5, 6);

        /**
         * Se instancia un nuevo objeto de la clase Rectangulo.
         */
        Rectangulo rec1 = new Rectangulo(p3, 8, 2);
        j1.agregarFigura(rec1);

        /**
         * Se instancia un nuevo objeto de la clase Punto con coordenadas (7, 8).
         */
        Punto p4 = new Punto(7, 8);

        /**
         * Se instancia un nuevo objeto de la clase Elipse.
         */
        Elipse eli1 = new Elipse(p4, 4, 9);
        j1.agregarFigura(eli1);

        /**
         * Muestra los detalles de las figuras en el jardín.
         */
        j1.detalleFiguras();

        System.out.println("----------------------------------------------");

        /**
         * Muestra el total de metros a cubrir en el jardín.
         */
        System.out.println("Total a cubrir: " + j1.cuantosMetros());

        /**
         * Muestra la cantidad de latas de pintura necesarias.
         */
        System.out.println("Comprar " + j1.cuantasLatas() + " latas");
    }
}
