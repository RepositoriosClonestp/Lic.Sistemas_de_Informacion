public class EjecutableAlumno{
    public static void main (String [] args){
        Alumno a1 = new Alumno (123, "Benja", "Zimer");
        a1.setNota1(8);
        a1.setNota2(7);
        a1.mostrar();
    }
}
