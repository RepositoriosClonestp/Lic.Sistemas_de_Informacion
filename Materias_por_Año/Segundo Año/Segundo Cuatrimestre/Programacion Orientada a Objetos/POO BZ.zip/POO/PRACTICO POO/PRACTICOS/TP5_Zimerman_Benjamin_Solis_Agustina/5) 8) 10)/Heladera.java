
/**
 * Write a description of class Heladera here.
 * 
 * @author (Solis Agustina, Zimerman Benjamin) 
 * @version (10/10/24)
 */
public class Heladera extends ArtefactoHogar{
    private int pies;
    private int puertas; 
    private boolean compresor; 
    
    private int cuotas; 
    private float interes; 
 
    /**METODO CONSTRUCTOR: crea e instancia objetos de la clase Heladera.
     * @param: p_marca: marca del electrodomedisto
       @param p_stock. stock disponible
       @param p_precio: precio del equipo
       @param p_pies: pies de altura
       @param p_puertas: cantidad de puertas
       @param p_compresor: true si tiene compresor, false caso contrario
     */
    public Heladera(int p_pies, int p_puertas, boolean p_compresor,String p_marca, int p_stock, float p_precio ){
      super(p_marca, p_stock, p_precio); 
      this.setPies(p_pies); 
      this.setPuertas(p_puertas); 
      this.setCompresor(p_compresor); 
    }

    /**ACCESORS**/
    /**setters**/
    private void setPies(int p_pies) {
        this.pies = p_pies;
    }
    
    private void setPuertas(int p_puertas) {
        this.puertas = p_puertas; 
    }
    
    private void setCompresor (boolean p_compresor){
        this.compresor = p_compresor; 
    }
    
    private void setCuotas(int p_cuotas){
        this.cuotas = p_cuotas; 
    }
    
    private void setInteres(float p_interes) {
        this.interes = p_interes; 
    }
    /**getters*/
    public int getPies () {
        return this.pies;
    }
    
    public int getPuertas () {
        return this.puertas; 
    }
    
    public boolean getCompresor () {
        return this.compresor; 
    }
    
    public int getCuotas(){
        return this.cuotas; 
    }
    
    public float getInteres(){
        return this.interes; 
    }
    /**METODOS*/
    /**public float creditoConAdicional(int p_cuotas, float p_interes): 
       calcula el valor total de las cuotas de una heladera: si tiene compresor, se le suman $50 a cada cuota
       @return precio final de cada cuota**/
    public float creditoConAdicional(int p_cuotas, float p_interes){
        float total=0; 
        if (this.getCompresor() == true) {
            total = super.cuotaCredito(p_cuotas, p_interes) + (50 * p_cuotas); 
        } else {
            total = super.cuotaCredito(p_cuotas, p_interes); 
        }
        return total; 
    }
    
     /**public void imprimir(): imprime por pantalla la marca, stock y precio del producto, 
        asi como tambien eñ estado de sus atributos compresor, pies y puertas**/
    public void imprimir (int p_cuotas, float p_interes) {
        //float valorCuota = super.cuotaCredito(p_cuotas,p_interes); 
        System.out.println ("***HELADERA***");
        super.imprimir(); 
        System.out.println ("Pies: "+this.getPies());
        System.out.println ("Puertas: " +this.getPuertas());
        System.out.println ("Cuotas: "+this.getCuotas() + "\t-" + "Interes: "+this.getInteres());
        if (this.getCompresor() == true) {
            System.out.println ("Compresor: Si");
            System.out.println ("Valor Cuota: "+ super.cuotaCredito(p_cuotas, p_interes));
            System.out.println ("Valor Cuota con Adicional:" +this.creditoConAdicional (p_cuotas, p_interes));
        }else {
            System.out.println ("Compresor: No");
            System.out.println ("Valor Cuota: "+ super.cuotaCredito(p_cuotas, p_interes));
        }
    }
}


