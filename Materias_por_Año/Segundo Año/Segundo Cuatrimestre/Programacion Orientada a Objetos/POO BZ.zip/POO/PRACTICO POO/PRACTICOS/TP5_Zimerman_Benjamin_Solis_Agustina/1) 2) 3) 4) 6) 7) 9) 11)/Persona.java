/**
 * Class Persona.
 * 
 * @author (Zimerman Benjamin, Solis Agustina) 
 * @version (25/9/24)
 */
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Persona {
    private int nroDni;
    private String nombre;
    private String apellido;
    private int anioNacimiento;
    private Calendar fecha; 

    /** METODO CONSTRUCTOR: crea e inicializa objetos de la clase persona. 
     * @param p_dni: dni de la persona
     * @param p_nombre: nombre de la persona. 
     * @param p_apellido: apellido de la persona. 
     * @param p_anio: año de nacimiento de la persona
     */
    public Persona(int p_dni, String p_nombre, String p_apellido, int p_anio) {
        this.setDNI(p_dni);//Doble encapsulamiento, 
        this.setNombre(p_nombre);
        this.setApellido(p_apellido);
        this.setAnio(p_anio);
        this.setFechaN(Calendar.getInstance()); 
        this.getFechaN().set(Calendar.YEAR, p_anio); 

    }

    /** METODO CONSTRUCTOR: crea e inicializa objetos de la clase persona. 
     * @param p_dni: dni de la persona
     * @param p_nombre: nombre de la persona. 
     * @param p_apellido: apellido de la persona.
     * @param p_fechaN: objeto de clase Calendar que descbribe la fecha de nacimiento de la persona (AA/MM/DD)
     */
    public Persona (int p_dni, String p_nombre, String p_apellido, Calendar p_fechaN) {
        this.setDNI(p_dni);//Doble encapsulamiento, 
        this.setNombre(p_nombre);
        this.setApellido(p_apellido);
        this.setFechaN(p_fechaN); 

    }

    /** Seteo de variables */
    private void setDNI(int p_dni) {
        this.nroDni = p_dni;
    }

    private void setNombre(String p_nombre) {
        this.nombre = p_nombre;
    }

    private void setApellido(String p_apellido) {
        this.apellido = p_apellido;
    }

    private void setAnio(int p_anio) {
        this.anioNacimiento = p_anio;
    }

    private void setFechaN (Calendar p_fechaN) {
        this.fecha = p_fechaN; 
    }

    /** GET Devuelve valor de atributo */
    public int getDni() {
        return this.nroDni;
    }

    public String getNombre() {
        return this.nombre;
    }

    public String getApellido() {
        return this.apellido;
    }

    public int getAnio() {
        return this.anioNacimiento;
    }

    public Calendar getFechaN (){
        return this.fecha; 
    }

    /**metodo nomYApe(): Concatena nombre y apelido
     * @return un string con el nombre y el apellido de la persona
     */
    public String nomYApe(){
        return this.getNombre()+ ", " +this.getApellido();
    }

    /**Metodo apeYNom(): concatena el apellido y el nombre de la persona
     * @return un string con el apellido y el nombre de la persona
     */
    public String apeYNom(){
        return this.getApellido()+ ", " +this.getNombre();
    }

    /**Metodo edad(): permite calcular la edad de la persona
     * @return la cantidad de años de la persona
     */
    public int edad() {
        Calendar fechaHoy = new GregorianCalendar();/**Nueva variable fecha de hoy*/
        int anioHoy = fechaHoy.get(Calendar.YEAR);/**Asigno valor entero a la fecha*/
        return anioHoy - this.getAnio();/**Resto al año actual el de nacimiento*/
    }

    /**Metodo mostrar(): imprime por pantalla el estado de los atributor dni, nombre, apellido, edad y fecha de nacimiento*/
    public void mostrar() {
        System.out.println("Nombre y apellido: " +nomYApe());
        System.out.println("DNI: " +this.getDni()+"   Edad: " +this.edad()+ " años");
    }

    /**Metodo esCumpleaños: devuelve true si la fecha del dia de hoy es igual a la fecha de nacimiento de la persona(si es su cumpleaños)*/ 
    public boolean esCumpleaños (){
        Calendar hoy = Calendar.getInstance(); 
        return hoy.get(Calendar.DAY_OF_MONTH) == fecha.get(Calendar.DAY_OF_MONTH) && hoy.get(Calendar.MONTH) == fecha.get(Calendar.MONTH); 
    }
}

