
/**
 * Clase CuentaBancaria.
 * 
 * @author (Zimerman Benjamin-Solis Agustina) 
 * @version (1/09/24)
 */
public class CuentaBancaria
{
    
    private int nroCuenta;
    private double saldo; 
    private Persona titular; 
    private double importe; 

    /*** METODO CONSTRUCTOR para objetos de la clase CuentaBancaria 
     * @param p_nroCuenta: numero de cuenta del usuario.
     * @param p_titular: objeto de la clase Persona que actua como titular.
       */
    public CuentaBancaria(int p_nroCuenta, Persona p_titular) {
        this.setNroCuenta(p_nroCuenta); 
        this.setTitular (p_titular);
        
    }
    
    /*** METODO CONSTRUCTOR para objetos de la clase CuentaBancaria 
     * @param p_nroCuenta: numero de cuenta del usuario.
     * @param p_titular: objeto de la clase Persona que actua como titular.
     * @param p_saldo: saldo actual de la persona en su cuenta bancaria(dinero). 
     * @param p_importe: cantidad de dinero que se desea operar .
       */
    public CuentaBancaria (int p_nroCuenta, Persona p_titular, double p_saldo, double p_importe) {
        this.setNroCuenta(p_nroCuenta);
        this.setTitular (p_titular);
        this.setSaldo (p_saldo);
        this.setImporte(p_importe); 
    }

    /**ACCESORS**/
    /**Setters: permiten modificar los valores de los atributos**/
    private void setImporte (double p_importe) {
        this.importe = p_importe; 
    }
    private void setNroCuenta(int p_nroCuenta){
        this.nroCuenta = p_nroCuenta; 
    }
    private void setTitular (Persona p_titular){
        this.titular = p_titular; 
    }
    private void setSaldo (double p_saldo) {
        this.saldo = p_saldo; 
    }
    
    /**Getters: permiten obtener el valor de los atributos**/
    public int getNroCuenta (){
        return nroCuenta; 
    }
    public Persona getTitular (){
        return titular;
    }
    public double getSaldo () {
        return saldo; 
    }
    public double getImporte () {
        return importe; 
    }
    
    
    /**METODO DEPOSITAR: metodo publico que al valor actual del saldo le incrementa el valor ingresado como parametro *
     * @param p_importe: cantidad de dinero que se desea depositar. 
     * @return: saldo final luego de realizar el deposito
    */
    public double depositar (double p_importe){
        double nuevoSaldo; 
        nuevoSaldo = this.getSaldo() + this.getImporte(); 
        this.setSaldo(nuevoSaldo); 
        return nuevoSaldo; 
    }
    
    /**METODO EXTRAER: metodo publico que al valor actual del saldo le resta el importe ingresado como parametro*
     * @param  p_importe: cantidad de dinero que se desea depositar. 
     * @return saldo final luego de realizada la extraccion. 
    */
    public double extraer (double p_importe) {
        double nuevoSaldo; 
        nuevoSaldo = this.getSaldo () - this.getImporte (); 
        this.setSaldo (nuevoSaldo);
        return nuevoSaldo; 
    }
    
    /**METODO MOSTRAR: metodo publico void queimprime por pantalla los valores de los atributos titular y saldo**/
       public void mostrar () {
           System.out.println ("\n****CUENTA BANCARIA****: " + "\nTitular: "+ this.titular.apeYNom()+"("+this.titular.edad()+ "años)" +  "\nSaldo actual: " +this.getSaldo());
           System.out.println ("\n* CUENTA *: \n"+toStrinf() );
        }
    
       
       /**METODO toStrinf: metodo publico que concatena los valores de los atributos nro. de Cuenta, nombre y saldo*
        * @return un string con los estados de los atributos nro. de Cuenta, nombre y saldo
        */
       public String toStrinf (){
           String unString= "\t"+this.getNroCuenta()+ "\t"+ this.titular.apeYNom()+ "\t"+ "\t"+ this.getSaldo(); 
           return unString; 
       }
       
}
