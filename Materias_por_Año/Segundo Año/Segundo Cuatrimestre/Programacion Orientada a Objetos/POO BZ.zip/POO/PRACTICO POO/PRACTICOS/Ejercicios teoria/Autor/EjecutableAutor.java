public class EjecutableAutor {
    public static void main (String [] args){
    Autor a1 = new Autor ("Juan Perez", "FaCENA", "juanPerez@exa.unne.edu.ar");
    Articulo a2 = new Articulo (1,"AAA","Biologia",a1);
    a2.mostrar();
    }
}