/**
 * Clase Renglon que representa un elemento del pedido.
 */
public class Renglon {
    /**
    Atributos
     */
    private int cantidad;
    private double importe;
    private Etiqueta item;

    /**
     * Constructor de la clase Renglon.
     *
     * @param p_cant la cantidad de ítems
     * @param p_imp el importe del renglón
     * @param p_item el ítem asociado con el renglón
     */
    public Renglon(int p_cant, double p_imp, Etiqueta p_item) {
        this.setCantidad(p_cant);
        this.setItem(p_item);
        this.setImporte(p_imp);
    }

    /**
     * Establece el ítem del renglón.
     *
     * @param p_item el nuevo ítem
     */
    private void setItem(Etiqueta p_item) {
        this.item = p_item;
    }

    /**
     * Establece la cantidad de ítems en el renglón.
     *
     * @param p_cant la nueva cantidad
     */
    private void setCantidad(int p_cant) {
        this.cantidad = p_cant;
    }

    /**
     * Establece el importe del renglón.
     *
     * @param p_imp el nuevo importe
     */
    private void setImporte(double p_imp) {
        this.importe = p_imp;
    }

    /**
     * Obtiene la cantidad de ítems en el renglón.
     *
     * @return la cantidad de ítems
     */
    public int getCantidad() {
        return this.cantidad;
    }

    /**
     * Obtiene el importe del renglón.
     *
     * @return el importe
     */
    public double getImporte() {
        return this.importe;
    }

    /**
     * Obtiene el ítem asociado con el renglón.
     *
     * @return el ítem
     */
    public Etiqueta getItem() {
        return this.item;
    }

    /**
     * Muestra la información del renglón.
     */
    public void mostrar() {
        System.out.println(this.getCantidad() + " de tipo " + this.getItem().tipo() + " - " + this.getItem().toString());
    }
}
