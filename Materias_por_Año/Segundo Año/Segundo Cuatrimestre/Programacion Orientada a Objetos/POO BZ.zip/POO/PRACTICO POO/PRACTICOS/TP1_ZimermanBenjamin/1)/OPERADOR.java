public class OPERADOR
{
    // instance variables - replace the example below with your own
    private static int a;
    private static int b;
    private static int suma;
    private static int resta;
    private static int producto;
    private static int division;
    private static int resto;


    public static void main(String []args)/*main y argumento del main linea que convierte la clase en ejecutable*/
    {
        // initialise instance variables
        a = 3;
        b = 8;
        suma = a+b;
        resta = a-b;
        producto = a*b;
        division = a/b;
        resto = a % b;
        System.out.println ("Resultado suma: "+suma);
        System.out.println ("Resultado resta: "+resta);
        System.out.println ("Resultado producto: "+producto);
        System.out.println ("Resultado division: "+division+ "," +resto);

    }
}    
