/** CLASE LOCALIDAD: describe el lugar de nacimiento y domicilio actual de los pacientes.
 * 
 * @author (Zimerman Benjamin, Solis Agustina A.) 
 * @version (30/8/24)
 */
public class Localidad{
    /**ATRIBUTOS**/
    private String nombre;
    private String provincia;
    
    /**Metodo constructor: permite crear e instanciar objetos de la clase Localidad
     * @param p_nombre: nombre de la localidad. 
     * @param p_ppcia: provincia donde su ubica la localidad
    */
    public Localidad(String p_nombre, String p_pcia){
        this.setNombre(p_nombre);
        this.setProvincia(p_pcia);
    }
    /**ACCESORS**/
    /**setNombre(): permite actualizar el estado del atributo nombre
     * @param p_nombre: nombre de la localidad
    **/
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    /**setProvincia(): permite actualizar el estado del atributo provincia
     * @param p_ppcia: provincia donde su ubica la localidad
    **/
    private void setProvincia(String p_pcia){
        this.provincia = p_pcia;
    }  
    
    /**getNombre(): obtiene el estado del atributo nombre
     * @return el estado del atributo nombre
    */
    public String getNombre(){
        return this.nombre;
    }
    
    /**getProvincia(): obtiene el estado del atributo provincia
     * @return el estado del atributo provincia. 
    */
    public String getProvincia(){
        return  this.provincia;
    }
    
    /**mostrar(): imprime por pantalla los atributos nombre y provincia*/
    public String mostrar(){
        return "Localidad: "+this.getNombre()+ "\tProvincia: "+this.getProvincia();
    }
}

