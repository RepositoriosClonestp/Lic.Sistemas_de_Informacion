/** CLASE EJECUTABLE CARRERA
 * 
 * @author (Zimerman Benjamin, Solis Agustina A.) 
 * @version (11/9/24)
 */
import java.util.*;
import java.util.Scanner;
public class Carrera
{
    public static void main(String [] args){
        Scanner scan = new Scanner(System.in);
        /*5.1.1*/
        Curso c1 = new Curso("POO");

        Alumno a1 = new Alumno(12, "Eustaquio", "Gonzalez");
        Alumno a2 = new Alumno(23, "Flor", "Rodriguez");
        Alumno a3 = new Alumno(34, "Xiomara", "Almendra");
        Alumno a4 = new Alumno(45, "Ramiro", "Quintana");

        /*5.1.2*/
        a1.setNota1(8);
        a1.setNota2(6);
        a2.setNota1(9);
        a2.setNota2(5);
        a3.setNota1(10);
        a3.setNota2(7);
        a4.setNota1(1);
        a4.setNota2(3);       
        /*5.1.3*/
        c1.inscribirAlumno(a1);
        c1.inscribirAlumno(a2);
        c1.inscribirAlumno(a3);
        c1.inscribirAlumno(a4);

        /*5.1.4*/
        System.out.println("****Cantidad de inscriptos: "+c1.cantidadDeAlumnos());
        c1.mostrarInscriptos();

        /*5.1.5*/
        System.out.println("\nDar de baja al alumno: "+a4.nomYApe());
        c1.quitarAlumno(45);
        c1.verif(45,a4);

        /*5.1.6*/
        System.out.println("\n****Cantidad de inscriptos: "+c1.cantidadDeAlumnos());
        c1.mostrarInscriptos();   

        /*5.1.7*/
        System.out.println("\nBuscar al alumno: "+a2.nomYApe());
        c1.buscarAlumno(23);
        c1.verif(23,a2);
        
        /*5.1.8*/
        System.out.println("\n***--Mostrar promedio del alumno: "+a1.getLu()+"--***");
        c1.imprimirPromedioDelAlumno(12);
        //System.out.println("Alumno encontrado: ");
    }
}
