/**ClaseEjecutable Gestion Stock
 * @author Zimerman Benjamin, Solis Agustina Aylen 
 * @version (27/8/24)
 */
public class GestionStock     
{ 
    public static void main(String[] args) {
        Laboratorio l1 = new Laboratorio( "Colgate S.A.", "Scalibrini Ortiz 5524", "3148-562314");
        Producto p1 = new Producto(13, "Perfumeria", "Jabon Deluxe", 5.00, 10.5, 3, l1);
        p1.ajuste(200);
        p1.mostrarLinea();
    }
}