/**
 * Class Escuela.
 * 
 * @author (Zimerman Benjamin, Solis Agustina) 
 * @version (25/9/24)
 */
import java.util.Scanner; 
import java.util.Calendar;
import java.util.GregorianCalendar;
public class Escuela{
    public static void main (String [] args){
        Calendar fecha1 = Calendar.getInstance(); 
        fecha1.set(2004,12,25); 

        Calendar fecha2 = Calendar.getInstance(); 
        fecha2.set(2004,10,18);

        Calendar fecha3 = Calendar.getInstance(); 
        fecha3.set(2000,02,14);

        Persona p1 = new Persona(42135687,"Benja","Zimer", 2005); 
        p1.mostrar();
        System.out.println("--------------------------------------------");

        Alumno a1 = new Alumno(2145,"Augusto","Fleitas", 2003, 43521789);
        Alumno a2 = new Alumno(1345,"Armando","Mendoza", 2005, 43521789);
        Alumno a3 = new Alumno(2145,"Maria","Flores", 2002, 43521789);

        a1.setNota1(8.5);
        a1.setNota2(8.5);
        a2.setNota1(4.5);
        a2.setNota2(9.5);
        a3.setNota1(7.5);
        a3.setNota2(5.0);

        a1.mostrar();
        System.out.println("--------------------------------------------");
        a2.mostrar();
        System.out.println("--------------------------------------------");
        a3.mostrar();
    }
}
