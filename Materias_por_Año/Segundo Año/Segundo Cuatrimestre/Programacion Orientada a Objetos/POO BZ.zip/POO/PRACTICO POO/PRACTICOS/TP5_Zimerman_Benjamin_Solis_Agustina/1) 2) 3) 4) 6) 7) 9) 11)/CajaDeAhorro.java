/**
 * CLASE CAJA DE AHORRO
 * 
 * @author (Zimerman Benjamin, Solis Agustina A.) 
 * @version (5/10/24)
 */
public class CajaDeAhorro extends CuentaBancaria {
    /**ATRIBUTOS**/
    private int extraccionesPosibles = 10;

    /**METODO CONSTRUCTOR: permite crear e instanciar objetos de la clase CajaDeAhorro
     * @param int p_nroCuenta: numero de la caja de ahorro. 
     * @param p_titular: objeto de la clase persona que contiene la informacion del titular(nombre completo, dni, fecha de nacimiento)
     */
    public CajaDeAhorro(int p_nroCuenta, Persona p_titular) {
        super(p_nroCuenta, p_titular);
        this.setExtraccionesPosibles(10);
    }

    /**METODOS CONSTRUCTORES: permiten crear e instanciar objetos de la clase CajaDeAhorro
     * @param int p_nroCuenta: numero de la caja de ahorro . 
     * @param p_titular: objeto de la clase persona que contiene la informacion del tirular(nombre completo, dni, fecha de nacimiento)
     * @param p_saldo: importe del saldo disponible en la caja de ahorro.
     */
    public CajaDeAhorro(int p_nroCuenta, Persona p_titular, double p_saldo, double p_importe) {
        super(p_nroCuenta, p_titular, p_saldo, p_importe);
        this.setExtraccionesPosibles(10);
    }

    /**ACCESORS**/
    /**SETTERS: permiten modificar el estado de los atributos**/
    private void setExtraccionesPosibles(int p_extPos) {
        this.extraccionesPosibles = p_extPos;
    }

    /**GETTERS: permiten obtener el estado de los atributos y lo duevuelve*/
    public int getExtraccionesPosibles() {
        return this.extraccionesPosibles;
    }

    /**metodo puedeExtraer: devuelve true si el importe a retirar no supera el saldo disponible y si aún no usó todas las  extracciones posibles
    @param p_importe: importe del dinero que se desea extraer. 
    @return: true si el importe a retirar no supera el saldo disponible y si aún no usó todas las  extracciones posibles, false caso contrario
     */
    protected boolean puedeExtraer(double p_importe) {
        if (super.getSaldo() >= p_importe && this.getExtraccionesPosibles() > 0) {
            return true;
        } else {
            return false;
        }
    }

    /**Metodo extraccion(): actualiza el valor del saldo al restarle el valor del importe ingresado como parametro
     * @param p_importe: monto que se desea extraer.
     */
    protected void extraccion(double p_importe) {
        super.setSaldo(super.getSaldo() - p_importe);
        this.setExtraccionesPosibles(this.getExtraccionesPosibles() - 1);
    }

    public String xQueNoPuedeExtraer (double p_importe){
        if (p_importe > super.getSaldo()){
            String s = "No puede extraer mas que el saldo!";
            return s;
        }if(this.getExtraccionesPosibles() <= 0){
            String ss = "No tiene habilitadas mas extracciones!";
            return ss;
        }else{
            return "ERROR";
        }
    }

    /**METODO DEPOSITAR(p_importe): agrega el importe ingresado al saldo actual
     * @param p_importe: importe de dinero que se desea depositar.
     */
    public double depositar(double p_importe) {
        double d = super.depositar(p_importe);
        return d;
    }

    public void mostrar() {
        System.out.println("\t -   Caja de Ahorro   -");
        System.out.println("nNro. Cuenta: " + super.getNroCuenta() + " - Saldo: " + this.getSaldo());
        System.out.println("Titular: " +super.getTitular().apeYNom());
        System.out.println("Extracciones posibles: " + this.getExtraccionesPosibles());
    }  
}    

/**Metodo extraccion(): actualiza el valor del saldo al restarle el valor del importe ingresado como parametro
 * @param p_importe: monto que se desea extraer.

private void extraccion(double p_importe) {
this.setSaldo(this.getSaldo() - p_importe);
this.setExtraccionesPosibles(this.getExtraccionesPosibles() - 1);
}  ----------------*/

/**METODO DEPOSITAR(p_importe): agrega el importe ingresado al saldo actual
 * @param p_importe: importe de dinero que se desea depositar.

public void depositar(double p_importe) {
this.setSaldo(this.getSaldo() + p_importe);
}
---------------------------------------*/

/**extraer(double p_importe): verifica con el importe ingresado como parametro si se cumplen las condiciones para extraer: 
menor al saldo y sin rebasar el limite de extracciones posibles(10). De devolver true, realiza la extraccion
 *@param p_importe: importe que se desea extraer

public void extraer(double p_importe) {
if (puedeExtraer(p_importe)) {
extraccion(p_importe);
} else {
if (p_importe > this.getSaldo()) {
System.out.println("No puede extraer mas que el saldo!");
}
if (this.getExtraccionesPosibles() <= 0) {
System.out.println("No tiene habilitadas mas extracciones!");
}
}
}--------------------------------------*/

/**mostrar(): imprime por pantalla los datos del titular y la cuenta*/

