/**
 * CLASE EMPLEADO.
 * 
 * @author (Zimerman Benjamin, Solis Agustina) 
 * @version (30/09/24)
 */
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Empleado extends Persona {
    /**ATRIBUTOS*/
    private long cuil;
    private double sueldoBasico;
    private int anioIngreso;
    private Calendar fechaIngreso; 

    /** METODO CONSTRUCTOR: permite crear e instanciar objetos de la clase empleado
     * @param p_cuil: cuil del empleado

     * @param p_importe: sueldo del empleado
     * @param p_anio: año de ingreso del empleado.
     */
    public Empleado(long p_cuil, String p_nombre, String p_apellido, double p_importe, int p_anio, int p_dni, int p_anioIngreso) {
        super(p_dni, p_nombre, p_apellido, p_anio);
        this.setCuil(p_cuil);//Doble encapsulamiento, 
        this.setImporte(p_importe);
        this.setAnioIngreso(p_anioIngreso);
    }

    /** METODO CONSTRUCTOR: permite crear e instanciar objetos de la clase empleado
     * @param p_cuil: cuil del empleado
     * @param p_importe: sueldo del empleado
     * @param p_fecha: objeto calendar, define la fecha de ingreso del empleado
     */
    public Empleado(long p_cuil, String p_nombre, String p_apellido, double p_importe, Calendar p_fecha, int p_dni, int p_anioIngreso) {
        super(p_dni, p_nombre, p_apellido, p_fecha);
        this.setCuil(p_cuil);
        this.setImporte(p_importe);
        this.setAnioIngreso(p_anioIngreso);
    }

    /**ACCESORS*/
    /** Seteo de variables */
    /**setCuil(long p_cuil): actualiza los datos del atributo cuil
     * @param p_cuil: cuil del empleado
     */
    private void setCuil(long p_cuil) {
        this.cuil = p_cuil;
    }

    /**setImporte (double p_importe): modifica el valor el atributo importe de tipo double
     * @param p_importe: sueldo del empleado
     **/
    private void setImporte(double p_importe){
        this.sueldoBasico = p_importe;
    }

    /**setAnio(int p_nio): modifica el estado del atributo anio
     * @param p_Anio: año de ingreso del empleado
     */
    private void setAnioIngreso(int p_anioIngreso) {
        this.anioIngreso = p_anioIngreso;
    }

    /** GETTERS: Devuelve valor de atributo */
    /**getCuil(): obtiene el estado del atributo cuil del empleado
    @return estado del atributo cuil del empleado*/
    public long getCuil() {
        return this.cuil;
    }

    /**getImporte: obtiene el valor del atributo importe de tipo double
    @return estado del atributo importe**/
    public double getImporte(){
        return sueldoBasico;
    }

    /**getAnio(): obtiene el estado del atributo anio.
    @returns estado del atributo anio*/
    public int getAnioIngreso() {
        return this.anioIngreso;
    }

    /**getFechaI(): obtiene el estado del atributo fechaIngreso.
    @return valor del atributo fechaIngreso*/
    public Calendar getFechaI (){
        return this.fechaIngreso; 
    }

    /**metodo nomYApe(): Concatena nombre y apelido
    return un string con dicha concatenacion*/
    public String nomYApe(){
        return this.getNombre()+ ", " +this.getApellido();
    }

    /**metodo apeYNom(): Concatena nombre y apelido
    return un string con dicha concatenacion*/
    public String apeYNom(){
        return this.getApellido()+ ", " +this.getNombre();
    }

    /**METODO DESCUENTO (): metodo privado que permite calcular al 2% del sueldo básico en concepto de obra social, mas $1500 de seguro de 
    vida
    @returns importe total **/
    private double descuento(){
        return ((this.getImporte() * 0.02) + 1500);  
    }

    /**METODO ADICIONAL (): metodo privado que devuelve un valor double y permite calcular la asignacion realizada segun la antiguedad al sueldo basico
    @returns importe total con la suma de la asignacion correspondiente segun la antiguedad**/
    private double adicional(){
        int anti = antiguedad();
        double sb = this.getImporte();
        if(anti < 2){
            return sb * 0.02;
        }
        if (anti >= 2 && anti < 10){
            return sb * 0.04;
        }else{
            return sb * 0.06;
        }
    }

    /**METODO NETO (): metodo publico que devuelve un valor double y permite calcular la suma del sueldo básico más el adicional, menos el descuento. 
    @returns el sueldo final luego de aplicarse el adicional y el descuento**/
    public double neto(){
        double suelbas = this.getImporte();
        return (suelbas + adicional() - descuento());
    }

    /**METODO MOSTRARLINEA (): muestra por pantalla el valor del cuil, el apellido y nombre y el valor neto
    @returns un string con la concatenacion de los valores del cuil, el apellido y nombre y el valor neto**/
    public String mostrarLinea(){
        return(this.getCuil()+ " " +apeYNom()+ " ..........$" +neto());
    }

    /**antiguedad(): permite calcular la antiguedad del empleado en la empresa*/
    public int antiguedad() {
        Calendar fechaHoy = new GregorianCalendar();/**Nueva variable fecha de hoy*/
        int anioHoy = fechaHoy.get(Calendar.YEAR);/**Asigno valor entero a la fecha*/
        return anioHoy - this.getAnioIngreso();
    }

    /**mostrar(): imprime por pantalla*/
    public void mostrar() {      
        super.mostrar();
        System.out.println("CUIL: "+this.getCuil());
        System.out.println("Antiguedad: "+antiguedad()+ " años de servicio");
    }

    /**esAniversario(): comprueba y retorna true o false según sea o no el día en que la persona cumple un año 
    más en la empresa.  **/
    public boolean esAniversario() {
        Calendar hoy = Calendar.getInstance();
        return hoy.get(Calendar.DAY_OF_MONTH) == fechaIngreso.get(Calendar.DAY_OF_MONTH) && hoy.get(Calendar.MONTH) == fechaIngreso.get(Calendar.MONTH);
    }
}

