/**Definicion Clase Alumno**/
public class Alumno{
    /**Atributos de la clase: nombre, apellido, nota1, nota2**/
    private int lu;
    private String nombre;
    private String apellido;
    private double nota1 = 0;
    private double nota2 = 0;
    
    /**Metodo Constructor: crea e instancia objetos de la clase Alumno**/
    public Alumno(int p_lu, String p_nombre , String p_apellido ){
        this.setLu(p_lu);
        this.setNombre(p_nombre);
        this.setApellido(p_apellido);
    }
    
    /**GETTERS**/
    /**Get: obtiene el valor del atributo lu de tipo int*/
    private int getLu(){
        return lu;
    }
    /**Get: obtiene el valor del atributo Nombre de tipo String**/
    private String getNombre(){
        return nombre;
    }
     /**Get: obtiene el valor del atributo apellido de tipo String**/
    private String getApellido(){
        return apellido;
    }
     /**Get: obtiene el valor del atributo nota1 de tipo double**/
    public Double getNota1(){
        return nota1;
    }
     /**Get: obtiene el valor del atributo nota2 de tipo double**/
    public Double getNota2(){
        return nota2;
    }

    /**SETTERS*/
     /**setLu: permite modificar el valor del atributo lu de tipo int**/
    private void setLu(int p_lu){
        this.lu = p_lu;
    }
     /**setNombre: permite modificar el valor del atributo nombre de tipo String**/
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
     /**setApellido: permite modificar el valor del atributo apellido de tipo String**/
    private void setApellido(String p_apellido){
        this.apellido = p_apellido;
    }
     /**setNota1: permite modificar el valor del atributo nota1 de tipo int**/
    public void setNota1(double p_nota){
        this.nota1 = p_nota;
    }
     /**setNota2: permite modificar el valor del atributo nota de tipo int**/
    public void setNota2(double p_nota){
        this.nota2 = p_nota;
    }
    
     /**Metodo aprueba (): metodo privado que devuelve un valor booleano TRUE si la variable prom es mayor a 7, nota1 es mayor o igual a 6 y nota2 es mayor o igual a 6**/
    private boolean aprueba(){
        double prom = promedio();
        return (prom > 7.0 && (this.getNota1() >= 6 && this.getNota2() >= 6)); 
    }
     /**Metodo leyendaAprueba ():metodo privado que devuelve el string APROBADO si el valo del metodo aprueba() es TRUE y DESAPROBADO si el valor de aprueba () es FALSE  **/
    private String leyendaAprueba(){
        return aprueba() ? "APROBADO" : "DESAPROBADO";
    }
     /**Metodo promedio (): metodo publico que para calcular el promedio de notas obtiene los valores de las variables nota1 y nota2, los suma y divide por 2 **/
    public double promedio(){
        return ((this.getNota1() + this.getNota2())/2);
    }

    /**Metodo nomYApe (): concatena los valores de las variables nombre y apellido */
    public String nomYApe(){
        return this.getNombre()+ ", " +this.getApellido();
    }
     /**Metodo apeYNom: concatena los valores de las variables apellido y nombre**/
    public String apeYNom(){
        return this.getApellido()+ ", " +this.getNombre();
    }
     /**Metodo Mostrar (): muestra por pntalla los valores finales de las variables nombre, apellido, LU, notas y promedio **/
    public void mostrar(){
        System.out.println("Nombre y Apellido: "+nomYApe());
        System.out.println("LU: "+this.getLu());
        System.out.println("Notas: "+this.getNota1()+ " - " +this.getNota2());
        System.out.println("Promedio: "+promedio()+ " - " +leyendaAprueba());

    }
}
