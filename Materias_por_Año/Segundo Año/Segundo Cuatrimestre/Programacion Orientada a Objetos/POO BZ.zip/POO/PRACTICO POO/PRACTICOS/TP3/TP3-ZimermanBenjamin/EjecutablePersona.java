import java.util.Scanner; 
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.InputMismatchException;

public class EjecutablePersona{
    public static void main(String[] args){
        Calendar fechaN1=Calendar.getInstance(); 
        fechaN1.set(2004,12,25); 
        Persona p1 = new Persona(42135687,"Benja","Zimer", 2003);
        p1.mostrar();
    }
}