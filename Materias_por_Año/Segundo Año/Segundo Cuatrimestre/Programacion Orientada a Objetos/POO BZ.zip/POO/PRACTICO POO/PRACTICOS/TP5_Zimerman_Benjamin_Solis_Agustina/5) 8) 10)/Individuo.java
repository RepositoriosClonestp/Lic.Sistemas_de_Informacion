
/**
 * Write a description of class Individuo here: Para determinar el tipo de visitante, cada clase concreta retornará una cadena de caracteres que indicará el tipo en cada 
caso (“Individuo” ó “Delegación”) 
Ambos tipos de visitantes deben implementar un listado, en una fecha determinada, para cada tipo de visitante en 
particular. Es decir, Individuo permitirá listar los individuos, y Delegación permitirá listar las delegaciones. El formato 
de impresión dependerá del tipo de visitante. En el caso de un solo individuo será: 
 * 
 * @author (Solis Agustina, Zimerman Benjamin) 
 * @version (16/10/24)
 */
import java.util.*;
import java.util.Calendar;

public class Individuo extends Visitante {
    private Persona persona; 

    /**
     * Constructor for objects of class Individuo: crea e inicializa objetos de la clase Individuo
     * @param p_persona: objeto colaborador Persona que aporta los atributos nombre, apellido, dni y año de nacimiento
     * @param p_fecha:fecha de la visita de la delegacion al zoologico

     * @param p_nombre: nombre del individuo
     */
    public Individuo(Persona p_persona, String p_nombre, Calendar p_fecha){
        super(p_nombre, p_fecha); 
        this.setPersona(p_persona); 
    }
    
    /**ACCESORS**/
    /**SETTERS*/
    protected void setPersona (Persona p_persona) {
        this.persona = p_persona; 
    }
    
    /**getters*/
    public Persona getPersona () {
        return this.persona; 
    }
    
    /**METODOS:override*/
    /**@override
     * public String tipoVisitante(): metodo publico que retorna un String con el tipo de Visitante que corresponda
       @return individuo*/
    public String tipoVisitante() {
       return "individuo";  
    }
    /**@override
     * public double entrada(): metodo publico que acumula en una var auxiliar (total) el valor total de las entradas. 
       @return entrada;
       */
    public double entrada(){
       double entrada = 10;
        return entrada; 
    }
   
    /**@override
     * listarPorFecha(Calendar p_fecha, String p_visitante): metodo publico que muestra un listado de los individuos 
     * que visitaron el zoologico en una fecha determinada, 
       **/
    public void listarPorFecha(Calendar p_fecha, String p_visitante) {
        //Calendar fechaHoy = Calendar.getInstance();
        if (this.getFecha().equals(p_fecha) && this.tipoVisitante().equals(p_visitante)) {
            this.mostrar(); 
        }
        
    }
     /** @override
       *public HashSet <Persona> listarPersona(): crea un HashSet con los individuos
       *@return listaV;
       */
    public HashSet <Persona> listarPersona() {
        HashSet<Persona> listaV = new HashSet<>(); 
        listaV.add(this.getPersona()); 
        return listaV; 
    }
    /** @override
     * public void mostrar(): imprime por pantalla los nombres,dni y edad de los individuos
       */
    public void mostrar() {
        System.out.println("INDIVIDUOS");
        System.out.println ("Nombre y apellido: "+ this.persona.nomYApe());
        System.out.println ("DNI:"+ this.persona.getDni() + "\tEdad: "+this.persona.edad());
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
