/**
 * Ejercicio 2 Clase Ejecutable TomaPedido.
 * @author Zimerman Benjamin, Solis Agustina Aylen 
 * @version (11/9/24)
 */
import java.util.Scanner;
import java.util.*;
import java.util.Calendar;
public class TomaPedido{
    public static void main(String [] args){
        Calendar fI = Calendar.getInstance();
        fI.set(2023, Calendar.SEPTEMBER, 14);

        Cliente c1 = new Cliente(44567893,"Juan","Quiroz",100);

        Laboratorio l1 = new Laboratorio( "Colgate S.A.", "Scalibrini Ortiz 5524", "3148-562314");

        Producto p1 = new Producto(13, "Electronica", "Pendrive", 25.00, 10.5, 3, l1);

        Pedido miPedido = new Pedido (fI, c1, p1);
        /**---------------------------------------------*/
        //Cliente c2 = new Cliente(45567493,"Raul","Ramirez",500);

        //Laboratorio l2 = new Laboratorio( "Odol S.A.", "Moreno 1750", "3794-578412");

        Producto p2 = new Producto(14, "Electronica", "Libro-POO", 50, 20, 6, l1);

        Pedido miPedido2 = new Pedido (fI, c1, p2);

        miPedido.agregarProducto(p1);
        miPedido.agregarProducto(p2);

        miPedido.mostrarPedido();
        miPedido.quitarProducto(p1);
        miPedido.mostrarPedido();

    }
}
