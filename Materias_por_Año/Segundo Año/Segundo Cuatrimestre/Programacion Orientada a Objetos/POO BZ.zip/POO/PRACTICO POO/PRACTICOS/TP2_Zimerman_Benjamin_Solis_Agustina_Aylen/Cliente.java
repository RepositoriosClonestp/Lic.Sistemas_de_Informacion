public class Cliente{
    /**ATRIBUTOS DE LA CLASE**/
    private int nroDni;
    private String apellido;
    private String nombre;
    private double saldo;
    /**METODO CONSTRUCTOR: crea e inicializa objetos de la clase CLIENTE*/
    public Cliente(int p_dni, String p_apellido, String p_nombre, double p_importe){
        this.setDni(p_dni);
        this.setApellido(p_apellido);
        this.setNombre(p_nombre);
        this.setSaldo(p_importe);
    }

    /**SETTTERS*/
    /**setDni(int p_dni):modifica el valor del atributo nroDni de tipo int*/
    private void setDni(int p_dni){
        this.nroDni = p_dni;
    }

    /**setApellido():modifica el valor del atributo apellido de tipo String*/
    private void setApellido(String p_apellido){
        this.apellido = p_apellido;
    }

    /**setNombre():modifica el valor del atributo nombre de tipo String*/
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }

    /**setSaldo():modifica el valor del atributo saldo de tipo double*/
    private void setSaldo(double p_saldo){
        this.saldo = p_saldo;
    }

    /**GETTTERS*/
    /**getDni: obtiene el valor del atributo nroDni de tipo int **/
    public int getDni(){
        return nroDni;
    }

    /**getApellido: obtiene el valor del atributo apellido de tipo String  **/
    public String getApellido(){
        return apellido;
    }

    /**getNombre: obtiene el valor del atributo nombre de tipo String **/
    public String getNombre(){
        return nombre;
    }

    /**getSaldo: obtiene el valor del atributo saldo de tipo double **/
    public double getSaldo(){
        return saldo;
    }

    /**Metodo nuevoSaldo(): reemplaza saldo actual por p_importe y 
    devuelve nuevo saldo*/  
    public double nuevoSaldo(double p_importe){
        this.saldo = p_importe;
        return p_importe;
    }

    /**Metodo agregaSaldo: actualiza el saldo actual agregando p_importe y devuelve el nuevo saldo*/
    public double agregaSaldo(double p_importe){
        this.saldo += p_importe;
        return this.saldo;
    }

    /**Metodo nomYApe: concatena los atributos nombre y apelido en una sola cadena de caracteres*/
    public String nomYape(){
        return this.getNombre()+ ", " +this.getApellido();
    }

    /**Metodo apeYNom: concatena los atributos apellido y nombre en una sola cadena de caracteres*/
    public String apeYnom(){
        return this.getApellido()+ ", " +this.getNombre();
    }

    /**Metodo mostrar: imprime por pantalla los valores de los atributos en base al estado del objeto */
    public void mostrar(){
        System.out.println("Nombre y Apellido: "+nomYape()+ " ("+nroDni+")");
        System.out.println("Saldo: $"+this.agregaSaldo(10));
        //System.out.println("Saldo agregado: $"+agregaSaldo(10));

    }
}