import java.util.Scanner;
import java.util.Random;

/**
 * CLASE EJECUTABLE CREA FIGURA, Ejercicio 3 y 4
 * 
 * <p>La clase CreaFigura se encarga de crear y mostrar las características de diferentes figuras geométricas.</p>
 * 
 * @autor Zimerman Benjamin
 * @autor Solis Agustina Aylen
 * @version 28/8/24
 */
public class CreaFigura {

    /**
     * Método principal para la ejecución del programa.
     * 
     * @param args los argumentos de la línea de comandos
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Random rand = new Random();

        /**
         * Se instancia un nuevo objeto de la clase Punto con coordenadas (0, 0).
         */
        Punto o1 = new Punto(0, 0); 
        
        /**
         * Atributo ancho1 inicializado con un valor aleatorio.
         */
        double ancho1 = rand.nextDouble() * 100.0; 
        
        /**
         * Atributo alto1 inicializado con un valor aleatorio.
         */
        double alto1 = rand.nextDouble() * 100.0; 
        
        /**
         * Se instancia un nuevo objeto de la clase Rectangulo.
         */
        Rectangulo rec1 = new Rectangulo(o1, ancho1, alto1); 
        rec1.nombreFigura();
        rec1.caracteristicas(); 
        System.out.println("------------------------------------");

        /**
         * Se instancia un nuevo objeto de la clase Punto con coordenadas (10.0, 20.0).
         */
        Punto oC = new Punto(10.0, 20.0);
        
        /**
         * Atributo lado inicializado con un valor aleatorio.
         */
        double lado = rand.nextDouble() * 100.0;
        
        /**
         * Se instancia un nuevo objeto de la clase Cuadrado.
         */
        Cuadrado cuad1 = new Cuadrado(oC, lado);
        cuad1.nombreFigura();
        cuad1.caracteristicas();

        /**
         * Se instancia un nuevo objeto de la clase Punto con coordenadas (30.0, 50.5).
         */
        Punto oE = new Punto(30.0, 50.5);
        
        /**
         * Atributo sEjeMay inicializado con un valor aleatorio.
         */
        double sEjeMay = rand.nextDouble() * 100.0; 
        
        /**
         * Atributo sEjeMen inicializado con un valor aleatorio.
         */
        double sEjeMen = rand.nextDouble() * 100.0; 
        
        /**
         * Se instancia un nuevo objeto de la clase Elipse.
         */
        Elipse eli1 = new Elipse(oE, sEjeMay, sEjeMen); 
        System.out.println("------------------------------------");
        eli1.nombreFigura();
        eli1.caracteristicas();

        /**
         * Se instancia un nuevo objeto de la clase Punto con coordenadas (40.0, 10.5).
         */
        Punto oCirc = new Punto(40.0, 10.5);
        
        /**
         * Atributo l1 inicializado con un valor aleatorio.
         */
        double l1 = rand.nextDouble() * 100.0; 
        
        /**
         * Atributo l2 inicializado con un valor aleatorio.
         */
        double l2 = rand.nextDouble() * 100.0; 
        
        /**
         * Se instancia un nuevo objeto de la clase Circulo.
         */
        Circulo circ = new Circulo(oCirc, l1); 
        System.out.println("------------------------------------");
        circ.nombreFigura();
        circ.caracteristicas();

        scan.close();
    }
}
