
import java.util.*; 
public class Libro{ 
    private String titulo; 
    private ArrayList<Capitulo> capitulos;   
    public Libro(String p_titulo){ 
        this.setTitulo(p_titulo); 
        this.setCapitulos(new ArrayList()); 
    } 

    public Libro(String p_titulo, ArrayList p_capitulos){ 
        this.setTitulo(p_titulo); 
        this.setCapitulos(p_capitulos); 
    } 

    public void setTitulo(String p_titulo) { 
        this.titulo = p_titulo; 
    } 

    public void setCapitulos(ArrayList<Capitulo> p_capitulos) { 
        this.capitulos = p_capitulos; 
    } 

    public String getTitulo() { 
        return this.titulo; 
    } 

    public ArrayList<Capitulo> getCapitulos() { 
        return this.capitulos; 
    } 

    public boolean agregarCapitulo(Capitulo p_capitulo){ 
        return this.getCapitulos().add(p_capitulo); 
    } 

    public boolean quitarCapitulo(Capitulo p_capitulo){ 
        return this.getCapitulos().remove(p_capitulo); 
    } 

    public void mostrar(){ 
        System.out.println("Titulo: " +this.getTitulo()); 
        for(Capitulo unCapitulo: this.getCapitulos()){ 
            unCapitulo.mostrar(); 
        } 
    } 
}