/**/
/**
 * Modificar la clase Circunferencia para permitir que el usuario pueda calcular
 * el perímetro de muchas circunferencias, utilizando la estructura while.
 * Modificar además el ingreso de datos, utilizando la clase Scanner.
 * 
 * @Insfran, Lucas Anibal Leonel
 * @13/08/2024
 */
import java.util.Scanner;
public class Circunferencia2
{
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int r = 0;
        char respuesta='s';
        
        while(respuesta != 'n'){
            System.out.println("Ingrese el radio: ");
            r = teclado.nextInt();
            System.out.println("El perimetro de una circunferencia de radio "+ r +" es de "+ 2*Math.PI*r);        
            
            System.out.println("Ingresa otro radio (s/n)?: ");
            respuesta = teclado.next().charAt(0);
        }
        
        teclado.close();
        /*Cierra el flujo de datos una vez terminado de usar el objeto
        teclado(Buena practica de programación)*/
    }
}
