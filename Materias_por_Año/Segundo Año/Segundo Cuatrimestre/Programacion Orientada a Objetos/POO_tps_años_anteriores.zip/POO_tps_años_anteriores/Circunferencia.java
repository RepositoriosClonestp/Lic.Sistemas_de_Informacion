
/**
 * Crear una clase ejecutable denominada “Circunferencia”,
 en la que se calcule el perímetro de una
circunferencia, ingresando el radio de tipo entero a través del
argumento del main().
 * 
 * @Insfran, Lucas Anibal Leonel
 * @13/08/2024
 */
public class Circunferencia
{
    public static void main(String[] args) {
        int r = Integer.valueOf(args[0]);
        System.out.println("El perimetro de una circunferencia de radio "+ r +" es de "+ 2*Math.PI*r);
        
    }
}
