
/**
 * Crear clase ejecutable “Triangulo”, declarar las variables
 a, b y c de tipo double, que corresponden a los lados
de un triángulo. Los valores deben ser ingresados por teclado
como argumentos del método main(). Calcular y
mostrar el semiperímetro y el área del triángulo.
 semiperimetro= (a+b+c)/2
 area= raíz cuadrada(semiperimetro*(semiperimetro-a)*(semiperimetro-b)*(semiperimetro-c))
Nota: probar con a=2, b=2.7, c=3.5
 * 
 * @Insfran, Lucas Anibal Leonel
 * @13/08/2024
 */
public class Triangulo
{
    public static void main(String[] args) {
        double a = Double.valueOf(args[0]);
        double b = Double.valueOf(args[1]);
        double c = Double.valueOf(args[2]);
        
        double semiper = (a+b+c)/2;
        double area = Math.sqrt(semiper*(semiper-a) *(semiper-b) * (semiper-c));
        
        System.out.println("El semiperimetro del triangulo con lados "+a+" "+b+" "+c+" es de "+semiper);
        System.out.println("Y su area es de "+area);
    }
}
