
/**
 * Crear una clase denominada “Ecuación” que calcule las raíces
 reales de una ecuación de segundo grado. Los
valores de los coeficientes a, b y c se ingresarán por teclado
como argumentos del método main(). Considerar
que si el discriminante > 0 se deben calcular las 2 raíces, si
el discriminante = 0 se debe calcular una sola raíz,
especificando por pantalla que x1 = x2. En caso de ser negativo
 mostrar un mensaje indicando que se
encuentra frente a una solución compleja (numero imaginario).
Nota: probar con a= -1; b=500; c=-62500;
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ecuacion
{
    public static void main(String[] args){
        double a = Double.valueOf(args[0]);
        double b = Double.valueOf(args[1]);
        double c = Double.valueOf(args[2]);
        
        double discriminante =0;
        
        discriminante = Math.sqrt(Math.pow(b,2)-a*c);
        
        if(discriminante < 0) {
            System.out.println("La raices son complejas");
 
        }else {
            if(discriminante > 0) {
                double x1, x2;
                x1 = ((-1)*b + discriminante)/2*a;
                x2 = ((-1)*b - discriminante)/2*a;
                System.out.println("Las raices son "+x1+"y"+x2);
            }
            
            if(discriminante == 0) {
                double x;
                x = ((-1)*b)/2*a;
                System.out.println("Las raiz es "+x);
            }
        }
    }
    
}
