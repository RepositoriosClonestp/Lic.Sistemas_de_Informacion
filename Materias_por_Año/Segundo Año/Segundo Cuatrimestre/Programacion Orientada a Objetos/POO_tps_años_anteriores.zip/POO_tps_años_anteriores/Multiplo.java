
/**
 * Crear la clase “Multiplo”, que contenga el método main(),
 en el que se determinen y muestren por pantalla los
números múltiplos de 4 a partir de 42 y hasta el 150 inclusive.
Usar la instrucción iterativa más apropiada.
 * 
 * @Insrfran, Lucas Anibal Leonel 
 * @13/08/2024
 */
public class Multiplo
{
    // instance variables - replace the example below with your own
    public static void main(String[] args) {
        for(int i=42; i<=150;i++) {
            if(i == 42 || i == 150 || i % 4 == 0) {
                System.out.println(i);
            }
        }
    }
}
