
/**
 * Crear la clase ejecutable “Operador”, que contenga el método
main(). En él declarar las variables a y b de tipo
entero. Inicializarlas con los valores 8 y 3 respectivamente.
Realizar y mostrar por pantalla las siguientes
operaciones aritméticas: suma, resta, multiplicación, división
y resto.
 * 
 * @Insfran, Lucas Anibal Leonel 
 * @13/08/2024
 */
public class Operador
{
    public static void main(String[] args) {
        int a=8;
        int b=3;
        
        System.out.println(a+"+"+b+"="+(a+b));
        System.out.println(a+"-"+b+"="+(a-b));
        System.out.println(a+"*"+b+"="+(a*b));
        System.out.println(a+"/"+b+"="+((double)a/(double)b));
        System.out.println(a+"%"+b+"="+(a%b));
    }
}
