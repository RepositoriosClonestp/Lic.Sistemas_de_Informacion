
/**
 * Crear una clase denominada TrianguloRectangulo, en la que se
 determine si un triangulo es rectángulo
(Teorema de Pitágoras → h^2 = cateto1^2 + cateto2^2).
Los lados se deben ingresar por teclado, utilizando el argumento
del main().
Nota: probar con hipotenusa = 5; cateto1 = 3; cateto2 = 4;
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TrianguloRectangulo
{
    public static void main(String[] args) {
        double h = Double.valueOf(args[0]);
        double c1 = Double.valueOf(args[1]);
        double c2 = Double.valueOf(args[2]);
        
        if(Math.pow(h,2) == Math.pow(c1,2) + Math.pow(c2,2)) {
            System.out.println("Es un triangulo rectangulo");
        } else {
            System.out.println("No es un triangulo rectangulo");
        }
    }
}
