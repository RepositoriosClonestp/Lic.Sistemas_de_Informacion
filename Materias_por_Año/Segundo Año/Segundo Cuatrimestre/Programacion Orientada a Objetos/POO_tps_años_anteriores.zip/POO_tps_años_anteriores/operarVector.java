
/**
 *Crear una clase denominada OperarVector que permita ingresar por
 teclado (Scanner) 5 notas de alumnos, las que serán almacenadas en
 un array de enteros. Calcular el promedio y determinar la mayor nota.
 El promedio debe permitir resultado con decimales
 (aplicar cast a los elementos enteros cuando sea necesario para obtener dicho
 resultado). Mostrar los elementos ingresados, separados por un tabulador.
 Mostrar el promedio y la mayor nota con el mensaje respectivo;
 */
import java.util.Scanner;
public class operarVector
{
   public static void main(String [] args){
       Scanner teclado = new Scanner(System.in);
       float[] notas = new float[5];
       float sumarNotas=0,promedio=0,mayor=0;
       for(int i=0;i<5;i++){
          System.out.println("ingrese nota del alumno " + (i+1));
          notas[i]=teclado.nextFloat();
          sumarNotas=sumarNotas+notas[0];
       }
        
       promedio=sumarNotas/5;
        
        for(int j=0;j<5;j++){
            if(j==0){
                mayor=notas[j];
            }else if(notas[j] > mayor){
                mayor=notas[j];
            }
        }
        
        System.out.println("el promedio es " + promedio );
        System.out.println("el numero mayor es " + mayor);
        
    }
 
}
